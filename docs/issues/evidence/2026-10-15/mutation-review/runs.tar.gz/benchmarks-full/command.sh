cd /work/tests/TurboTest.Tests
export DOTNET_ROLL_FORWARD=Major
dotnet /opt/nuget/packages/dotnet-stryker/5.0.0/tools/net10.0/any/Stryker.CLI.dll --config-file /config/TurboTest.Benchmarks.json --output /durable/stryker --skip-version-check
