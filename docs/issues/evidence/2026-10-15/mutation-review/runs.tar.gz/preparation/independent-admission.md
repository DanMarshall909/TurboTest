# Independent read-only mutation admission audit

Reviewer: /root/mutation_diagnosis. Source: 29e974adc59e36ef8622f5f2c176ddb563f8c6d4.

Verdict: PASS for membership and source-range correctness, received before production launch.

Exact raw 267 fast / 434 full / 167 slow TRX-name sets reconcile. Isolated 267 exactly equals host fast. All 257 observed methods resolve to source attributes: 61 theory methods account for 238 rows, plus 196 fact rows. Class-level BasicTests trait contributes 4 slow rows. Source Category=PostgreSQL produces exactly 167 slow rows.

Independently OR-merged Cobertura hits reproduce all lane sets: EFCore 1761 fast / 947 slow-only / 99 neither; benchmark 230 / 396 / 35. All 228 UTF16 ranges (178 EFCore / 50 benchmark) exactly reconstruct contiguous slow-only lines against current source hashes and snapshots. Configs match full wildcards plus exactly those exclusions; fast/shared/neither remain eligible.

All 34 EFCore and 9 benchmark production .cs files are present in the hashed image inventory; configuration hashes match. This audit admits scope; it is not a passing mutation result.
