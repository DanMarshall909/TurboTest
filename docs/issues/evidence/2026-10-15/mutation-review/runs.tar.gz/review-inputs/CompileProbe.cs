using System.Text.Json;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.Text;

var root = "/work/";
var probes = JsonDocument.Parse(File.ReadAllText("/durable/probes.json")).RootElement;
var results = new List<object>();
foreach (var assembly in new[] { "TurboTest.EFCore", "TurboTest.Benchmarks" })
{
    var project = JsonDocument.Parse(File.ReadAllText($"/durable/{assembly}-inputs.json")).RootElement;
    var properties = project.GetProperty("Properties");
    LanguageVersionFacts.TryParse(properties.GetProperty("LangVersion").GetString(), out var language);
    var options = CSharpParseOptions.Default.WithLanguageVersion(language)
        .WithPreprocessorSymbols(properties.GetProperty("DefineConstants").GetString()!.Split(';', StringSplitOptions.RemoveEmptyEntries));
    var trees = new Dictionary<string, SyntaxTree>();
    foreach (var item in project.GetProperty("Items").GetProperty("Compile").EnumerateArray())
    {
        var path = item.GetProperty("FullPath").GetString()!;
        trees[path] = CSharpSyntaxTree.ParseText(File.ReadAllText(path), options, path);
    }
    var references = project.GetProperty("Items").GetProperty("ReferencePath").EnumerateArray()
        .Select(item => MetadataReference.CreateFromFile(item.GetProperty("FullPath").GetString()!)).ToArray();
    var compilation = CSharpCompilation.Create(assembly, trees.Values, references,
        new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary, nullableContextOptions: NullableContextOptions.Enable, allowUnsafe: true));
    var baseline = compilation.GetDiagnostics().Where(d => d.Severity == DiagnosticSeverity.Error).ToArray();
    File.WriteAllText($"/durable/{assembly}-baseline.json", JsonSerializer.Serialize(new { errors = baseline.Select(d => d.ToString()), sourceCount = trees.Count, referenceCount = references.Length, parseLanguage = options.LanguageVersion.ToString(), constants = options.PreprocessorSymbolNames }));
    if (baseline.Length != 0) throw new Exception($"Baseline compilation invalid: {assembly}: {string.Join("; ", baseline.Select(d => d.ToString()))}");
    foreach (var probe in probes.EnumerateArray().Where(p => p.GetProperty("assembly").GetString() == assembly))
    {
        var path = root + probe.GetProperty("file").GetString();
        var original = trees[path]; var text = original.GetText(); var loc = probe.GetProperty("location");
        int Offset(JsonElement pos) => text.Lines[pos.GetProperty("line").GetInt32() - 1].Start + pos.GetProperty("column").GetInt32() - 1;
        var start = Offset(loc.GetProperty("start")); var end = Offset(loc.GetProperty("end"));
        var changed = text.WithChanges(new TextChange(new TextSpan(start, end - start), probe.GetProperty("replacement").GetString()));
        var tree = CSharpSyntaxTree.ParseText(changed, options, path);
        var diagnostics = compilation.ReplaceSyntaxTree(original, tree).GetDiagnostics().Where(d => d.Severity == DiagnosticSeverity.Error).ToArray();
        results.Add(new { assembly, id = probe.GetProperty("id").GetString(), original = text.ToString(new TextSpan(start, end - start)), replacement = probe.GetProperty("replacement").GetString(), errors = diagnostics.Select(d => new { code = d.Id, message = d.GetMessage(), location = d.Location.GetLineSpan().ToString() }), warnings = compilation.ReplaceSyntaxTree(original, tree).GetDiagnostics().Where(d => d.Severity == DiagnosticSeverity.Warning).Select(d => new { code = d.Id, message = d.GetMessage(), location = d.Location.GetLineSpan().ToString() }) });
        Console.WriteLine($"{assembly}:{probe.GetProperty("id").GetString()} errors={diagnostics.Length}");
        File.WriteAllText("/durable/compile-results.json", JsonSerializer.Serialize(results));
    }
}
