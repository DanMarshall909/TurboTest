using TurboTest.Benchmarks;
namespace TurboTest.Tests;
public class MutationReviewProbe
{
    [Fact] public void Three_blocks_preserve_all_expected_cases()
    {
        var plan = BenchmarkSchedule.Create(17, 3, 2, 1234);
        Assert.Equal(24, plan.Length);
    }
}
