from pathlib import Path
import json,collections
out=Path('artifacts/mutation-review');inventory=json.loads((out/'inventory.json').read_text())['mutants'];groups=[]
compileResults=json.loads(Path('artifacts/tt-009/mutation/attempts/review-compile-all-final/compile-results.json').read_text())
for kind,c,reason in [
('semantic','direct-semantic-error','Single-fault variant has compiler errors with pinned Roslyn5,C#14, exact MSBuild source/reference/define inputs. Definite assignment, invalid operators/member use, impossible patterns, missing returns/required members and overflow are generated-mutant invalidity, not production build failures.'),
('clean','compile-rollback-candidate','Single-fault variant has no semantic compiler errors or unsuppressed warnings. Stryker nevertheless reported CompileError; whole-member/co-rollback leaves candidate executable faults untested. CE223 was independently built with zero warnings/errors and rejected by its named test. Other variants have not been executed or promoted to kills.'),
('warning','compile-warning-sensitive','Single-fault variant has no semantic errors but has compiler warnings beyond NoWarn1701/1702. Ordinary project TreatWarningsAsErrors=true matters; Stryker instrumentation/rollback policy must be resolved before calling this executable or invalid. No tested outcome is inferred.')]:
 for assembly in ['TurboTest.EFCore','TurboTest.Benchmarks']:
  ids=[]
  for r in compileResults:
   if r['assembly']!=assembly:continue
   warnings=[w for w in r['warnings'] if w['code'] not in ['CS1701','CS1702']];k='semantic' if r['errors'] else ('warning' if warnings else 'clean')
   if k==kind:ids.append(r['id'])
  groups.append({'group':'C-'+assembly+'-'+kind,'assembly':assembly,'ids':ids,'classification':c,'reason':reason,'issueKey':None if kind=='semantic' else 'compile-recovery','evidence':'review-compile-all-final/{compile-results.json,*-baseline.json,*-inputs.json}; exact SDK probes review-valid-ce and review-invalid-ce; package-pinned CSharpRollbackProcess source.'})
expected={x['key'] for x in inventory if x['status']=='Timeout'};assigned=set()
def add(group,assembly,ids,c,reason):
 keys={assembly+':'+str(i) for i in ids};assert keys<=expected and not keys&assigned,(group,keys-expected,keys&assigned);assigned.update(keys);groups.append({'group':group,'assembly':assembly,'ids':[str(i) for i in ids],'classification':c,'reason':reason,'issueKey':'timeout-diagnostics','evidence':'Full terminal report and source/test links; unchanged ordinary fast267 pass; exact startup-signal probe review-timeout exits124 after10s of named test, build0warning/error. Only this representative runtime cause is independently reproduced; remaining mechanism classifications use source inspection, not a timing score.'})
ef='TurboTest.EFCore';bm='TurboTest.Benchmarks'
add('T01',ef,[197,1161,1346,1394,1412,1438,1454,1488,1543,1563,1574,1641,1663,1666,1674,1676,1689,1874,1921,2003,2206],'timeout-completion-publication','Removing a start/completion/cancellation/Ready publication signal leaves a task or queued caller unable to settle.197 is reproduced: named monitor test hits its2s observation deadline then hangs in unbounded finally Join; external10s deadline stops it. A Timeout is retained as liveness evidence, not an asserted kill or original-source regression.')
add('T02',ef,[1329,1330,1337,1344,1345,1389,1391,1399,1401,1402,1403,1410,1411,1484,1497,1545,1552,1556,1565,1572,1573],'timeout-permit-corruption','Removing acquisition/release or corrupting permitHeld violates shared maintenance/preparation/reset ownership. Later work can block or fail before compensating publication; inspect bounded named failure and final cleanup separately before crediting a kill.')
add('T03',ef,[1443,1444,1445],'timeout-retry-progress','Retry comparison/increment mutation skips the candidate protocol or prevents retry budget progress. The source fault violates candidate/waiter settlement; report Timeout is not an independent assertion on its retry bound.')
add('T04',ef,[2108,2109,2126],'timeout-secondary-exception','Changes make lifecycle diagnostic construction call Diagnostic(null) when no cleanupFailure exists. Diagnostic default dereferences error.GetType(), replacing the expected safe exception with NullReferenceException; interrupted failure-publication/cleanup can strand waiting jobs. This is a mutation-induced secondary error, not proof of a slow original test.')
add('T05',ef,[467,1962,1963],'timeout-provider-diversion','Inverted source/provider identity or ordinary/prepared AutoMigrate branching diverts fast stand-ins into rejected ownership/real provider work. Exact per-case timeout causality needs bounded runner diagnostics; do not interpret these as stronger assertion evidence or bring slow boundary tests into mutation.')
add('T06',bm,[14,37,531],'timeout-index-progress','CLI argument index and schedule block increments become decrements. They revisit arguments or fail to reach a finite upper bound; generated mutant progress failure is expected from source, separate from normal-source latency.')
# Remaining cases are separated by actual owning file, preserving exact source locations in the manifest.
remaining=[x for x in inventory if x['status']=='Timeout' and x['key'] not in assigned]
for file,rows in __import__('itertools').groupby(sorted(remaining,key=lambda x:x['file']),key=lambda x:x['file']):
 rows=list(rows);ids=[r['id'] for r in rows];assembly=rows[0]['assembly'];name=Path(file).stem
 reasons={
 'TtSlotPool':'Mutated count/guard/state, candidate choice, queue removal, terminal failure transfer or shutdown/cancellation transition violates the ledger protocol. A waiting acquisition, claimed maintenance or final drain can lose progress; retain each exact location/replacement and bounded diagnostic follow-up rather than equating Timeout with an assertion kill.',
 'TtCapacityMonitor':'Returning early from Stop before publishing cancellation prevents the reader/tick join from settling; repeated shutdown ordering needs a bounded oracle.',
 'Tt':'Changed interruption classification or removed cleanup failure throw can leave startup/cleanup observers awaiting the wrong owned job; requires per-case bounded diagnostic attribution.',
 'TtFactory':'Changed completion short-circuit can read Task.Result before completion, while removed actual maintenance join can start teardown early. Both can strand later ownership/cleanup; preserve Timeout separately from failed assertions.'}
 add('T07-'+name,assembly,ids,'timeout-protocol-transition',reasons[name])
assert assigned==expected
allIds=[g['assembly']+':'+i for g in groups for i in g['ids']];expectedAll={m['key'] for m in inventory if m['status'] in ['CompileError','Timeout']};assert set(allIds)==expectedAll and len(allIds)==len(set(allIds))==376
(out/'runtime-groups.json').write_text(json.dumps(groups,indent=2)+'\n');print('376 exact runtime classifications persisted',collections.Counter(g['classification'] for g in groups));print('compiler',collections.Counter('semantic' if r['errors'] else 'warnings' if any(w['code'] not in ['CS1701','CS1702'] for w in r['warnings']) else 'clean' for r in compileResults))
