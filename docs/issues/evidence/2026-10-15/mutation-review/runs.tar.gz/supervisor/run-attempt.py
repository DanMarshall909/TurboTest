from pathlib import Path
import subprocess,json,uuid,time,os,signal,sys,fcntl,hashlib
root=Path.cwd();base=root/'artifacts/tt-009/mutation';name=sys.argv[1];script=Path(sys.argv[2]).read_text();dest=base/'attempts'/name;assert not dest.exists();dest.mkdir(parents=True)
lock=(base/'active.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
docker=['docker','-H','unix:///var/run/docker.sock'];label='com.turbotest.mutation.repo='+str(root)
def call(*args,check=True):return subprocess.run(docker+list(args),check=check,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
assert not call('ps','-aq','--filter','label='+label).stdout.strip(),'An owned layer requires completion/recovery before another attempt.'
inv=json.loads((base/'source-inventory.json').read_text());image=inv['sourceImage'];assert call('image','inspect',image,'--format','{{.Id}}').stdout.strip()==image
assert os.statvfs(dest).f_bavail*os.statvfs(dest).f_frsize>20*1024**3
(dest/'command.sh').write_text(script);cid=None;stopped=False;interrupted=False;exit_code=None;start=time.monotonic();samples=[]
def interrupt(signum,frame):
 global interrupted
 interrupted=True
signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt)
try:
 cname='tt-mut-'+name+'-'+uuid.uuid4().hex[:12]
 cid=call('create','--name',cname,'--label',label,'--label','com.turbotest.mutation.attempt='+name,'--network','none','--cap-drop','ALL','--security-opt','no-new-privileges','--user','1000:1000','--memory','4g','--memory-swap','4g','--cpus','2','--pids-limit','512','--mount','type=bind,src='+str(dest)+',dst=/durable',image,'/bin/bash','-euc',script).stdout.strip()
 owner={'id':cid,'name':cname,'image':image,'sourceCommit':inv['sourceCommit'],'output':str(dest),'label':label,'commandSha256':hashlib.sha256(script.encode()).hexdigest(),'diskFloorBytes':20*1024**3,'maximumWritableBytes':12*1024**3,'supervisorPid':os.getpid(),'startedUtc':time.time()};(dest/'owner.json').write_text(json.dumps(owner,indent=2)+'\n')
 details=json.loads(call('inspect',cid).stdout)[0];(dest/'created.json').write_text(json.dumps(details,indent=2)+'\n')
 assert details['Image']==image and not details['HostConfig']['Privileged'] and details['HostConfig']['NetworkMode']=='none'
 assert len(details['Mounts'])==1 and details['Mounts'][0]['Source']==str(dest) and details['Mounts'][0]['Destination']=='/durable'
 with (dest/'run.log').open('w') as log:
  process=subprocess.Popen(docker+['start','--attach',cid],stdout=log,stderr=subprocess.STDOUT)
  sampled=0
  while process.poll() is None:
   now=time.monotonic()
   if now-sampled>=30:
    free=os.statvfs(dest).f_bavail*os.statvfs(dest).f_frsize
    sized=json.loads(call('inspect','--size',cid).stdout)[0];size=sized.get('SizeRw',0)
    disk=call('exec',cid,'df','--output=avail','-B1','/',check=False)
    avail=int(disk.stdout.splitlines()[-1]) if disk.returncode==0 else None
    samples.append({'seconds':now-start,'outputFreeBytes':free,'daemonFreeBytes':avail,'writableBytes':size});(dest/'resources.json').write_text(json.dumps(samples,indent=2)+'\n');sampled=now
    if free<owner['diskFloorBytes'] or avail is not None and avail<owner['diskFloorBytes'] or size>owner['maximumWritableBytes']:interrupted=True
   if interrupted:call('stop','--time','10',cid,check=False)
   time.sleep(2)
  process.wait();exit_code=process.returncode
 details=json.loads(call('inspect','--size',cid).stdout)[0];(dest/'terminal.json').write_text(json.dumps(details,indent=2)+'\n');assert not details['State']['Running'];stopped=True
 (dest/'diff.txt').write_text(call('diff',cid).stdout)
 assert call('image','inspect',image,'--format','{{.Id}}').stdout.strip()==image
 for f in inv['files']:assert hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
 receipt={'id':cid,'sourceCommit':inv['sourceCommit'],'image':image,'exitCode':details['State']['ExitCode'],'attachExitCode':exit_code,'oomKilled':details['State']['OOMKilled'],'interrupted':interrupted,'elapsedSeconds':time.monotonic()-start,'baseImageUnchanged':True,'hostSourcesUnchanged':True,'writableBytes':details.get('SizeRw'),'log':str(dest/'run.log')};(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
finally:
 if cid:
  details=json.loads(call('inspect',cid).stdout)[0]
  assert details['Config']['Labels']['com.turbotest.mutation.repo']==str(root) and details['Config']['Labels']['com.turbotest.mutation.attempt']==name
  if details['State']['Running']:call('stop','--time','10',cid);details=json.loads(call('inspect','--size',cid).stdout)[0]
  assert not details['State']['Running']
  (dest/'cleanup-terminal.json').write_text(json.dumps(details,indent=2)+'\n')
  if not (dest/'diff.txt').exists():(dest/'diff.txt').write_text(call('diff',cid).stdout)
  call('rm',cid);(dest/'cleanup.json').write_text(json.dumps({'id':cid,'removed':True,'reclaimedWritableBytes':details.get('SizeRw'),'imageRetained':image,'outputFreeBytes':os.statvfs(dest).f_bavail*os.statvfs(dest).f_frsize},indent=2)+'\n')
if exit_code is None:sys.exit(2)
sys.exit(exit_code)
