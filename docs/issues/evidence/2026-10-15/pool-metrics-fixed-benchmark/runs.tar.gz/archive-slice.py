from pathlib import Path
import gzip, hashlib, json, subprocess, tarfile, io, xml.etree.ElementTree as ET

root = Path.cwd()
source = root / 'artifacts/tt-010'
target = root / 'docs/issues/evidence/2026-10-15/pool-metrics-fixed-benchmark'
sha = lambda data: hashlib.sha256(data).hexdigest()
final_runs = ['tt010-post-audit-fast', 'tt010-full-suite', 'tt010-solution-build', 'tt010-example-build']
for name in final_runs:
    receipt = json.loads((source / (name + '-receipt.json')).read_text())
    assert receipt['exitCode'] == 0, receipt
    for item in json.loads(Path(receipt['sourceBinding']).read_text())['files']:
        assert sha(Path(item['path']).read_bytes()) == item['sha256'], item['path']
target.mkdir(parents=True, exist_ok=True)
entries, results = [], []
archive = target / 'runs.tar.gz'
with archive.open('wb') as raw_stream, gzip.GzipFile(fileobj=raw_stream, mode='wb', mtime=0, filename='') as compressed, tarfile.open(fileobj=compressed, mode='w|') as tar:
    for original in sorted(source.rglob('*'), key=lambda path: str(path).encode()):
        if not original.is_file() or {'review', 'bin', 'obj'}.intersection(original.relative_to(source).parts):
            continue
        if original.suffix not in ('.log', '.trx', '.xml', '.txt', '.json', '.md', '.cs', '.py'):
            continue
        member = original.relative_to(source).as_posix()
        data = original.read_bytes()
        info = tarfile.TarInfo(member)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        tar.addfile(info, io.BytesIO(data))
        entries.append({'member': member, 'sha256': sha(data), 'bytes': len(data), 'original': original.relative_to(root).as_posix()})
        if original.suffix == '.trx':
            doc = ET.fromstring(data)
            ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
            summary = doc.find('t:ResultSummary', ns)
            results.append({'member': member, 'outcome': summary.get('outcome'), 'counters': summary.find('t:Counters', ns).attrib,
                            'times': doc.find('t:Times', ns).attrib,
                            'failures': [test.get('testName') for test in doc.findall('t:Results/t:UnitTestResult', ns) if test.get('outcome') != 'Passed']})
with tarfile.open(archive, 'r:gz') as tar:
    actual = tar.getmembers()
    assert len(actual) == len(entries)
    for info, entry in zip(actual, entries):
        assert info.name == entry['member'] and info.isfile()
        assert sha(tar.extractfile(info).read()) == entry['sha256'], info.name
manifest = {
    'sourceBase': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(),
    'status': 'Metrics and fixed/parking benchmark slice candidate; TT-010 and TT-009 remain Open.',
    'cwd': str(root), 'archive': {'path': archive.name, 'sha256': sha(archive.read_bytes()), 'bytes': archive.stat().st_size},
    'files': entries, 'results': results, 'finalRuns': final_runs,
    'qualifications': [
        'Current terminal full-suite/build receipts bind the same compiler inputs. Earlier RED/GREEN/coverage results remain historical source cuts, not a composite whole-suite pass.',
        'The first factory timing RED failed compilation/setup; corrected factory-timing-red-r2 records the expected three empty-event failures.',
        'Initial validation oracle assumed one preparation; a two-slot fixture correctly emits two preparation validations. The corrected oracle is explicitly retained.',
        'The fixed-parking-experiment-r1 is a frozen pre-audit-guard Release source cut. All16 cases and2544 cycles pass. Generated plans avoid the later empty-plan and timing-equality guard findings; snapshots are not relabelled as repaired source.',
        'Independent verification checks all4000 copied benchmark source hashes, equal per-block plans, reversed profile order,53 samples per row size per case and zero owned resources.',
        'Native empty/idle-only REDs reproduce false success with no timed samples. Six schedule REDs reproduce accepted unequal/invalid delays. Both repairs have separate GREEN/coverage/refactor records.',
        'Resource observations are sampled process working set and raw Docker cgroup usage including cache. Peaks are lower bounds; monitoring stops before final host deletion. They do not measure whole-worktree/build reserve or normalized CPU.',
        'Loaded assembly hashes and source snapshots capture identities; the supported dotnet run command and outer compiler-input receipt establish the recorded build invocation. Standalone snapshots are not independent compiler provenance proof.',
        'No remote/upstream is configured; the authoritative tracker declares local-only work. CI/performance workflow source is validated locally, but hosted execution is unavailable in this checkout.',
        'This slice implements metrics and fixed/parking measurements. Scale reasons, adaptive implementation/comparisons and evidence-selected adaptive defaults remain TT-009/TT-010 work.',
        'Whole coding-session mutation remains pending the final immutable committed snapshot; no pending job is passing evidence.',
        'Read-only harness investigation is not independent completion approval. Candidate publication requires an exact independent review PASS.',
        'Preserve unrelated container0a95e88a68d8, existing stash and reusable build/dependency caches.'
    ]
}
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'members': len(entries), 'rawBytes': sum(entry['bytes'] for entry in entries), 'archiveBytes': archive.stat().st_size, 'trxReports': len(results)}))
