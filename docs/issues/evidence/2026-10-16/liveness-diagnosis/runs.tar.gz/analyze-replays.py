"""Retain independent diagnostic dimensions; never rewrite original Timeout."""
from pathlib import Path
import json, re, collections, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'exact-replays'
plan = json.loads((RUN / 'plan.json').read_text())
classified = {r['key']:r for r in json.loads((ROOT.parent.parent/'docs/issues/evidence/2026-10-15/mutation-review/classifications.json').read_text())['mutants']}
baseline = json.loads((RUN/'baseline/receipt.json').read_text())['runs']['selected']['rows']
baseline_names = {r['name'] for r in baseline}
assert len(baseline)==len(baseline_names)==268 and all(r['outcome']=='Passed' for r in baseline)
rows = []
for item in plan:
    directory = item['key'].replace('TurboTest.', '').replace(':', '-')
    dest = RUN / directory
    if not (dest / 'receipt.json').exists() or not (dest / 'cleanup.json').exists(): continue
    receipt = json.loads((dest / 'receipt.json').read_text())
    cleanup = json.loads((dest / 'cleanup.json').read_text())
    assert cleanup['namespaceStopped'] and cleanup['removed']
    observations = []
    for lane, result in receipt['runs'].items():
        log = (dest / (lane + '.log')).read_text()
        console_failures = []
        for match in re.finditer(r'^  Failed (.+) \[([^\]\n]+)\]\r?$', log, re.MULTILINE):
            following = log[match.end():].splitlines()
            excerpt = []
            for line in following[:60]:
                if re.match(r'^  (?:Passed|Failed|Skipped) ',line): break
                excerpt.append(line)
            console_failures.append({'name':match.group(1),'duration':match.group(2),'followingDiagnostic':'\n'.join(excerpt),'log':directory+'/'+lane+'.log','utf8ByteOffset':len(log[:match.start()].encode()),'qualification':'VSTest console reports a named failure; a cutoff may prevent final TRX. Not a completed-run claim.'})
        sequence = []
        for path in sorted((dest/lane).glob('*/Sequence*.xml')):
            sequence.extend({'name':r.get('Name'),'displayName':r.get('DisplayName'),'completed':r.get('Completed')=='True'} for r in ET.parse(path).getroot())
        summary = None
        counters = None
        if result['trx']:
            trx = ET.parse(RUN / result['trx'])
            node = trx.find('.//{*}ResultSummary')
            summary = node.get('outcome') if node is not None else None
            node = trx.find('.//{*}Counters')
            counters = node.attrib if node is not None else None
        expected = baseline_names if lane=='full-fast' else {n for n in baseline_names if n.split('(')[0] in item['methods']}
        observed = {r['name'] for r in result['rows']}
        console_rows = [{'outcome':m.group(1),'name':m.group(2),'duration':m.group(3)} for m in re.finditer(r'^  (Passed|Failed|Skipped) (.+) \[([^\]\n]+)\]\r?$',log,re.MULTILINE)]
        console_names = {r['name'] for r in console_rows}
        observations.append({'lane':lane,'exitCode':result['exitCode'],'seconds':result['seconds'],'trxOutcome':summary,'counters':counters,'failures':result['failures'],'consoleFailures':console_failures,'consoleReportedRows':console_rows,'consoleUnreportedRows':sorted(expected-console_names),'consoleUnexpectedRows':sorted(console_names-expected),'consoleQualification':'Unreported means not reported complete; it does not establish which test started or stalled.','rowCount':len(result['rows']),'expectedRowCount':len(expected),'missingRows':sorted(expected-observed),'unexpectedRows':sorted(observed-expected),'duplicateRows':len(observed)!=len(result['rows']),'allRowsPassed':bool(result['rows']) and all(r['outcome']=='Passed' for r in result['rows']),'inactivityAbort':'The specified inactivity time of 5 seconds has elapsed' in log,'externalDeadline':result['exitCode']==124,'unfinishedTests':[r for r in sequence if not r['completed']],'sequence':sequence,'otherCrash':'host process exited unexpectedly' in log and 'The specified inactivity time of 5 seconds has elapsed' not in log})
    named = any(o['failures'] or o['consoleFailures'] for o in observations)
    inactivity = any(o['inactivityAbort'] for o in observations)
    deadline = any(o['externalDeadline'] for o in observations)
    complete = len(observations)==2 and all(o['exitCode']==0 and o['trxOutcome']=='Completed' and o['rowCount']>0 and o['allRowsPassed'] and not o['unfinishedTests'] and not o['missingRows'] and not o['unexpectedRows'] and not o['duplicateRows'] and o['counters'] and int(o['counters']['passed'])==o['rowCount'] and int(o['counters']['total'])==o['rowCount'] for o in observations)
    if receipt['buildExitCode'] != 0:
        codes = sorted(set(re.findall(r'error (CS\d+|\w+\d+)',(dest/'build.log').read_text())))
        attribution = 'standalone compilation limitation: ' + ', '.join(codes)
    elif inactivity or deadline:
        prefix = 'named assertion failures and ' if named else ''
        if any(o['unfinishedTests'] for o in observations):
            attribution = prefix + 'named unfinished tests at diagnostic cutoff'
        else:
            attribution = prefix + 'external cutoff before runner emitted an unfinished-test sequence'
    elif named: attribution = 'named assertion failures; selected run completed' if all(o['trxOutcome']=='Failed' for o in observations) else 'named assertion failures; inspect per-run completion'
    elif complete: attribution = 'original Stryker Timeout not reproduced by standalone selected/full-fast execution'
    else: attribution = 'runner/selection limitation; inspect retained log and TRX'
    original_item = classified[item['key']]
    start = original_item['location']['start']['line']
    end = original_item['location']['end']['line']
    source_lines = (ROOT.parent.parent/item['file']).read_text().splitlines()
    context = [{'line':n+1,'text':source_lines[n]} for n in range(max(0,start-3),min(len(source_lines),end+2))]
    additional = []
    if item['key'] in {'TurboTest.EFCore:2108','TurboTest.EFCore:2109','TurboTest.EFCore:2126'} and (ROOT/'constructor-native/runtime-construction.json').exists():
        additional.append({'path':'constructor-native/runtime-construction.json','scope':'pinned native Stryker diagnostic; same replacement/location; named direct-probe NullReferenceException; standalone compiler outcome unchanged'})
    if item['key'] in {'TurboTest.EFCore:1962','TurboTest.EFCore:1963'} and (ROOT/('supplemental-r2/provider-'+item['key'].split(':')[1]+'/receipt.json')).exists():
        additional.append({'path':'supplemental-r2/provider-'+item['key'].split(':')[1]+'/receipt.json','scope':'intercepted provider open before network; actual cleanup settled; named failure; passing unchanged control'})
    if item['key']=='TurboTest.EFCore:1445' and (ROOT/'supplemental-r2/retry-1445/receipt.json').exists():
        additional.append({'path':'supplemental-r2/retry-1445/receipt.json','scope':'revised finite fake guard; named Expected4Actual5; all5 independently recorded resource identities deleted before owner scope settles'})
    rows.append({**item,'location':original_item['location'],'sourceContext':context,'sourceBefore':item['original'],'attribution':attribution,'observations':observations,'additionalDiagnostics':additional,'standaloneBuildExitCode':receipt['buildExitCode'],'buildSeconds':receipt['buildSeconds'],'namespaceStoppedAndRemoved':True,'applicationSettlement':'not inferred from process exit; monitor-specific phase evidence retained separately','rawStatus':'Timeout','receipt':directory+'/receipt.json','cleanup':directory+'/cleanup.json'})

summary = {'completed':len(rows),'expected':111,'attributionCounts':dict(collections.Counter(r['attribution'] for r in rows)),'namedAssertionCases':sum(any(o['failures'] or o['consoleFailures'] for o in r['observations']) for r in rows),'namedTrxAssertionCases':sum(any(o['failures'] for o in r['observations']) for r in rows),'namedConsoleAssertionCases':sum(any(o['consoleFailures'] for o in r['observations']) for r in rows),'boundedNoncompletionCases':sum(any(o['inactivityAbort'] or o['externalDeadline'] for o in r['observations']) for r in rows),'qualification':'These dimensions overlap. All original statuses remain Timeout. Console failures can survive cutoff without completed TRX; neither proves full-run completion. Inactivity abort/external deadline proves bounded observed noncompletion, not mathematical infinite execution or application resource settlement. Source mechanism, named unfinished tests and limitations require review.'}
(ROOT/'exact-analysis.json').write_text(json.dumps({'summary':summary,'mutants':rows},indent=2)+'\n')
print(json.dumps(summary,indent=2))
