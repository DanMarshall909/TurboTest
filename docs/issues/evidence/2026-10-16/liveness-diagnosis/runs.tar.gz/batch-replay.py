"""One-off TT-012 diagnostic experiment. Not a replacement mutation runner."""
from pathlib import Path
import subprocess, json, hashlib, sys, os, shlex, time, fcntl, signal, tarfile
import xml.etree.ElementTree as ET

ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-012/exact-replays'
ARCHIVE = ROOT / 'docs/issues/evidence/2026-10-15/mutation-review/runs.tar.gz'
CLASS = ARCHIVE.parent / 'classifications.json'
IMAGE = 'sha256:135233b24b3c97a3bf46bca4c1bfb1f3eb98ce4eb6555116fcbb3462fd781cbf'
D = ['docker', '--host', 'unix:///var/run/docker.sock']
LABEL = 'com.turbotest.mutation.repo=' + str(ROOT)
sys.path.insert(0, str(ROOT / 'scripts'))
import verify

def sha(data): return hashlib.sha256(data).hexdigest()
def save(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.replace(path)
def docker(*args, check=True):
    return subprocess.run(D + list(args), capture_output=True, text=True, check=check)
def interrupt(signum, frame): raise KeyboardInterrupt(f'signal {signum}')
signal.signal(signal.SIGTERM, interrupt)

lock = (ROOT / 'artifacts/tt-009/mutation/active.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not docker('ps', '-aq', '--filter', 'label=' + LABEL).stdout.strip()
assert sha(ARCHIVE.read_bytes()) == '910f3d01043e9b64be33c2b71b9726469dc0ba79bb46318b62fb57070776002d'
assert docker('image', 'inspect', IMAGE, '--format', '{{.Id}}').stdout.strip() == IMAGE
assert docker('info', '--format', '{{.Driver}}').stdout.strip() == 'overlay2'
OUT.mkdir(exist_ok=False)
host = verify.source_identity()['files']
save(OUT / 'identity.json', {'head': subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip(), 'image': IMAGE, 'hostFiles': host, 'archiveSha256': sha(ARCHIVE.read_bytes()), 'storage': 'overlay2; immutable image; independent writable layer per fault', 'testDeadlineSeconds': 10, 'inactivityDiagnosticSeconds': 5, 'outerDeadlineSeconds': 90, 'parallelism': 1, 'resourceLimits': {'memoryBytes': 4*1024**3, 'cpus': 2, 'pids': 512, 'maxWritableBytes': 12*1024**3, 'minFreeBytes': 20*1024**3}})
classification = json.loads(CLASS.read_text())
reports = {}
with tarfile.open(ARCHIVE) as archive:
    for assembly, info in classification['reports'].items():
        raw = archive.extractfile(info['path']).read()
        assert sha(raw) == info['sha256']
        reports[assembly] = json.loads(raw)

def offset(source, point):
    lines = source.splitlines(keepends=True)
    line = lines[point['line']-1]
    prefix = line.encode('utf-16-le')[:2*(point['column']-1)].decode('utf-16-le')
    return sum(map(len, lines[:point['line']-1])) + len(prefix)

cases = []
for item in classification['mutants']:
    if item['status'] != 'Timeout': continue
    report = reports[item['assembly']]
    file = report['files']['/work/' + item['file']]
    mutant = next(m for m in file['mutants'] if m['id'] == item['id'])
    assert mutant['status'] == 'Timeout' and mutant['location'] == item['location']
    original = file['source']
    current = (ROOT / item['file']).read_text()
    a, b = offset(original, mutant['location']['start']), offset(original, mutant['location']['end'])
    assert original[:b] == current[:b], item['key']
    assert a < b
    names = {test['id']: test['name'] for f in report['testFiles'].values() for test in f['tests']}
    methods = sorted({names[tid].split('(')[0] for tid in mutant.get('coveredBy', []) if tid in names})
    unknown = sorted(set(mutant.get('coveredBy', [])) - names.keys())
    cases.append((item, current[:a] + mutant['replacement'] + current[b:], original[a:b], methods, unknown))
assert len(cases) == 111 and len({c[0]['key'] for c in cases}) == 111
save(OUT / 'plan.json', [{'key': i['key'], 'file': i['file'], 'group': i['group'], 'rawStatus': 'Timeout', 'original': old, 'replacement': i['replacement'], 'methods': methods, 'unknownCoverageLinks': unknown} for i, _, old, methods, unknown in cases])

def results(dest, lane):
    path = dest / lane / 'probe.trx'
    if not path.exists(): return {'trx': None, 'rows': [], 'failures': []}
    tree = ET.parse(path)
    rows = tree.findall('.//{*}UnitTestResult')
    return {'trx': str(path.relative_to(OUT)), 'rows': [{'name': r.get('testName'), 'outcome': r.get('outcome'), 'duration': r.get('duration')} for r in rows], 'failures': [{'name': r.get('testName'), 'text': ''.join(r.itertext())} for r in rows if r.get('outcome') == 'Failed']}

def execute(key, path=None, source=None, methods=(), unknown=()):
    dest = OUT / key
    dest.mkdir()
    inputs = dest / 'inputs'
    inputs.mkdir()
    if source is not None: (inputs / 'fault.cs').write_text(source)
    filt = 'Category!=PostgreSQL'
    if methods: filt += '&(' + '|'.join('FullyQualifiedName=' + n for n in methods) + ')'
    testcmd = 'dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none'
    command = 'set -u\n'
    if source is not None:
        command += 'cp /inputs/fault.cs ' + shlex.quote('/work/' + path) + '\n'
        command += 'sha256sum ' + shlex.quote('/work/' + path) + ' > /durable/applied.sha256\n'
    command += '''date +%s%N > /durable/build-start.ns
dotnet build tests/TurboTest.Tests/TurboTest.Tests.csproj --no-restore -c Release -nr:false -p:UseSharedCompilation=false --verbosity minimal > /durable/build.log 2>&1
rc=$?
echo "$rc" > /durable/build-exit.txt
date +%s%N > /durable/build-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
export TURBOTEST_MONITOR_PHASE_LOG=/durable/phases.jsonl
'''
    for lane, selection in [('selected', filt), ('full-fast', 'Category!=PostgreSQL')]:
        if lane == 'full-fast':
            if not methods: break
            command += 'if [ "$rc" -ne 0 ]; then exit "$rc"; fi\n'
        command += f'date +%s%N > /durable/{lane}-start.ns\n'
        command += f'timeout --signal=TERM --kill-after=3s 10s {testcmd} --filter {shlex.quote(selection)} --results-directory /durable/{lane} > /durable/{lane}.log 2>&1\n'
        command += f'rc=$?\necho "$rc" > /durable/{lane}-exit.txt\ndate +%s%N > /durable/{lane}-end.ns\n'
    command += 'exit "$rc"\n'
    (dest / 'command.sh').write_text(command)
    cid = None
    reason = None
    began = time.monotonic()
    try:
        cid = docker('create', '--label', LABEL, '--label', 'com.turbotest.mutation.attempt=tt012-exact-' + key, '--network', 'none', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--user', '1000:1000', '--memory', '4g', '--memory-swap', '4g', '--cpus', '2', '--pids-limit', '512', '--mount', 'type=bind,src='+str(inputs)+',dst=/inputs,readonly', '--mount', 'type=bind,src='+str(dest)+',dst=/durable', IMAGE, '/bin/bash', '-c', command).stdout.strip()
        owner = {'id': cid, 'image': IMAGE, 'source': path, 'faultSha256': sha(source.encode()) if source is not None else None, 'selectedMethods': methods, 'unknownCoverageLinks': unknown, 'pid': os.getpid(), 'output': str(dest)}
        save(dest / 'owner.json', owner)
        details = json.loads(docker('inspect', cid).stdout)[0]
        assert len(details['Mounts']) == 2 and not next(m for m in details['Mounts'] if m['Destination'] == '/inputs')['RW']
        with (dest / 'attach.log').open('w') as log:
            proc = subprocess.Popen(D + ['start','--attach',cid], stdout=log, stderr=subprocess.STDOUT)
            try:
                while proc.poll() is None:
                    time.sleep(1)
                    details = json.loads(docker('inspect','--size',cid).stdout)[0]
                    free = os.statvfs(OUT).f_bavail * os.statvfs(OUT).f_frsize
                    if time.monotonic()-began > 90: reason = 'outer-deadline'
                    elif free < 20*1024**3: reason = 'disk-headroom'
                    elif details.get('SizeRw',0) > 12*1024**3: reason = 'writable-layer-budget'
                    if reason:
                        docker('stop','--time','3',cid)
                        break
            finally:
                if proc.poll() is None:
                    # Stop the exact recorded namespace before reaping attachment.
                    docker('stop','--time','3',cid,check=False)
                proc.wait(timeout=15)
        details = json.loads(docker('inspect','--size',cid).stdout)[0]
        save(dest / 'terminal.json',details)
        assert not details['State']['Running'] and details['State']['Pid'] == 0
        if source is not None: assert (dest/'applied.sha256').read_text().split()[0] == sha(source.encode())
        phases = [json.loads(line) for line in (dest/'phases.jsonl').read_text().splitlines()] if (dest/'phases.jsonl').exists() else []
        runs = {}
        for lane in ('selected','full-fast'):
            if (dest / (lane+'-exit.txt')).exists():
                runs[lane] = {'exitCode':int((dest/(lane+'-exit.txt')).read_text()), 'seconds':(int((dest/(lane+'-end.ns')).read_text())-int((dest/(lane+'-start.ns')).read_text()))/1e9, **results(dest,lane)}
        build = int((dest/'build-exit.txt').read_text()) if (dest/'build-exit.txt').exists() else None
        if reason: outcome = reason
        elif details['State']['OOMKilled']: outcome = 'resource-limit'
        elif build != 0: outcome = 'standalone-build-limitation'
        elif any(r['failures'] for r in runs.values()): outcome = 'named-test-failure'
        elif any(r['exitCode']==124 for r in runs.values()): outcome = 'external-test-deadline'
        elif any(r['exitCode']!=0 for r in runs.values()): outcome = 'runner-abort-or-other-limitation'
        elif not runs or any(not r['rows'] for r in runs.values()): outcome = 'empty-selection-limitation'
        else: outcome = 'not-reproduced-standalone'
        receipt = {'key':key, 'originalStatus':'Timeout' if path else 'unmutated control', 'outcome':outcome, 'buildExitCode':build, 'buildSeconds':(int((dest/'build-end.ns').read_text())-int((dest/'build-start.ns').read_text()))/1e9 if build is not None else None, 'runs':runs, 'phases':phases, 'state':details['State'], 'elapsedSeconds':time.monotonic()-began, 'actualWorkSettledByTests':None, 'namespaceStopped':True, 'qualification':'A stopped namespace bounds the diagnostic; it does not prove application resources settled. Raw original Timeout remains unchanged.'}
        save(dest/'receipt.json',receipt)
        return receipt
    finally:
        if cid:
            details = json.loads(docker('inspect','--size',cid).stdout)[0]
            assert details['Config']['Labels']['com.turbotest.mutation.repo'] == str(ROOT)
            if details['State']['Running']:
                docker('stop','--time','3',cid)
                details = json.loads(docker('inspect','--size',cid).stdout)[0]
            assert not details['State']['Running'] and details['State']['Pid']==0
            (dest/'diff.txt').write_text(docker('diff',cid).stdout)
            docker('rm',cid)
            assert docker('inspect',cid,check=False).returncode != 0
            save(dest/'cleanup.json',{'id':cid, 'removed':True, 'namespaceStopped':True, 'reclaimedWritableBytes':details.get('SizeRw'), 'baseRetained':IMAGE, 'freeBytes':os.statvfs(OUT).f_bavail*os.statvfs(OUT).f_frsize})

summaries = []
try:
    baseline = execute('baseline')
    assert baseline['outcome'] == 'not-reproduced-standalone', baseline
    assert len(baseline['runs']['selected']['rows']) == 268
    assert all(r['outcome']=='Passed' for r in baseline['runs']['selected']['rows'])
    print(json.dumps({'baseline':'PASS','rows':268,'testSeconds':baseline['runs']['selected']['seconds']}),flush=True)
    for item, source, old, methods, unknown in cases:
        key = item['assembly'].removeprefix('TurboTest.') + '-' + item['id']
        receipt = execute(key,item['file'],source,methods,unknown)
        summaries.append({'key':item['key'],'group':item['group'],'outcome':receipt['outcome'],'receipt':key+'/receipt.json','failures':[f['name'] for r in receipt['runs'].values() for f in r['failures']]})
        save(OUT/'progress.json',{'completed':len(summaries),'expected':111,'results':summaries})
        print(json.dumps({'completed':len(summaries),'key':item['key'],'outcome':receipt['outcome'],'failures':summaries[-1]['failures']}),flush=True)
finally:
    assert verify.source_identity()['files'] == host, 'Host source changed during replay'
    assert docker('image','inspect',IMAGE,'--format','{{.Id}}').stdout.strip() == IMAGE
    assert not docker('ps','-aq','--filter','label='+LABEL).stdout.strip()
    save(OUT/'terminal.json',{'completed':len(summaries),'expected':111,'hostSourcesUnchanged':True,'immutableImageUnchanged':True,'ownedContainersAbsent':True})
