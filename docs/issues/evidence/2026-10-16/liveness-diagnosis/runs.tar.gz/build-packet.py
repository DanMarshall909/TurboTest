"""Freeze the completed TT012 evidence; do not run before final-all terminates."""
from pathlib import Path
import hashlib,json,subprocess,tarfile,sys,xml.etree.ElementTree as ET
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-012';RUN=OUT/'final-all'
sys.path.insert(0,str(ROOT/'scripts'));import verify
BASE='9f385127c0d29d4d78dc077f0b75a2cadd00644e'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).decode()
assert git('rev-parse','HEAD').strip()==BASE and git('branch','--show-current').strip()=='master'
assert not git('remote').strip(), 'Project policy is local source commits'
result=json.loads((RUN/'verification.json').read_text());assert result['result']=='PASS'
assert result['tests']['fast']['passed']==268 and result['tests']['slow']['passed']==167
assert not result['resourceSettlement']['after'] and not result['resourceSettlement']['before']
binding=json.loads((RUN/'source-identity.json').read_text());assert binding['files']==verify.source_identity()['files']
for name,sha in binding['files'].items():assert digest(ROOT/name)==sha,name
catalog=json.loads((RUN/'test-catalog.json').read_text());allids={r['id'] for r in catalog['all']};fastids={r['id'] for r in catalog['fast']};slowids={r['id'] for r in catalog['slow']}
assert len(allids)==435 and len(fastids)==268 and len(slowids)==167 and not fastids&slowids and fastids|slowids==allids
owning=[r for r in catalog['fast'] if r['name'].startswith(('TurboTest.Tests.CapacityMonitorTests.','TurboTest.Tests.SlotRecoveryTests.'))]
coverage_rows=ET.parse(OUT/'retry-coverage/owning.trx').findall('.//{*}UnitTestResult')
assert len(owning)==len(coverage_rows)==13 and {r['id'] for r in owning}=={r.get('testId') for r in coverage_rows} and all(r.get('outcome')=='Passed' for r in coverage_rows)
assert json.loads((OUT/'retry-source-before.json').read_text())['files']==binding['files']
assert json.loads((OUT/'retry-source-after.json').read_text())['files']==binding['files']
analysis=json.loads((OUT/'exact-analysis.json').read_text());assert analysis['summary']['completed']==111
assert len({r['key'] for r in analysis['mutants']})==111 and all(r['rawStatus']=='Timeout' and r['namespaceStoppedAndRemoved'] for r in analysis['mutants'])
assert json.loads((OUT/'exact-replays/terminal.json').read_text())['completed']==111
assert json.loads((OUT/'supplemental-r2/terminal.json').read_text())['completed']==9
runtime=json.loads((OUT/'constructor-native/runtime-construction.json').read_text());assert set(runtime['nativeResults'])=={'2108','2109','2126'}
assert json.loads((OUT/'continuation-terminal.json').read_text())['result']=='PASS'
for name in ['src/TurboTest.EFCore/Internal/TtCapacityMonitor.cs','tests/TurboTest.Tests/CapacityMonitorTests.cs','tests/TurboTest.Tests/SlotRecoveryTests.cs']:
 p=OUT/'candidate-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
for name,sha in binding['resolvedDependencies'].items():
 assert digest(ROOT/name)==sha,name
 p=OUT/'resolved-dependencies'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
retain=ROOT/'docs/issues/evidence/2026-10-16/liveness-diagnosis';retain.mkdir(parents=True,exist_ok=False)
excluded={'candidate.json','candidate.sha256','packet.json','packet-build.log','envelope-completion.json','envelope-issue.json','envelope-investigation.md','envelope-readme.md'}
items=sorted((p for p in OUT.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts),key=lambda p:str(p.relative_to(OUT)).encode())
assert all(not p.is_symlink() and p.resolve().is_relative_to(OUT.resolve()) for p in items)
archive=retain/'runs.tar.gz';entries=[]
with tarfile.open(archive,'w:gz') as tar:
 for p in items:
  name=str(p.relative_to(OUT));tar.add(p,arcname=name,recursive=False);entries.append({'path':name,'sha256':digest(p),'bytes':p.stat().st_size})
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(entries)
 for entry in entries:assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest()==entry['sha256']
manifest={'schemaVersion':1,'ticket':'TT-012','issue':'https://github.com/DanMarshall909/TurboTest/issues/2','baseCommit':BASE,'candidateSource':{n:binding['files'][n] for n in ['src/TurboTest.EFCore/Internal/TtCapacityMonitor.cs','tests/TurboTest.Tests/CapacityMonitorTests.cs','tests/TurboTest.Tests/SlotRecoveryTests.cs']},'archive':{'path':'runs.tar.gz','sha256':digest(archive),'bytes':archive.stat().st_size},'files':entries,'verification':result,'diagnosticSummary':analysis['summary'],'publication':'local commits only; no code remote; GitHub owns live issues/project','limits':['Original111 Timeout statuses unchanged; direct standalone versus native Stryker diagnostic outcomes are separate.','111-fault batch uses recorded pre-retry-guard snapshot; final retry guard has its own fault/control identity evidence and final435-row ordinary gate.','Compiler limits and incomplete test runs are not assertion kills or application resource settlement.','Native constructor diagnostic uses Debug and pinned Stryker5 instrumentation, one replay-only fast probe; not whole-assembly mutation adequacy.','Whole-session full mutation remains queued for final source after coding session; TT030 owns final robustness gate.','Existing clean TT029 validation worktree and immutable images retained as authorized reusable caches.']}
save(retain/'manifest.json',manifest)
text=(OUT/'results-draft.md').read_text()
text=text.replace('Draft: final exact-fault totals, ordinary native result and independent completion\nreview are still pending. Do not use this draft as a completion claim.','Final source verification passed; independent completion review is recorded in\n`completion.json` after its verdict. GitHub owns live workflow status.')
text=text.replace('investigation applies every exact reported replacement independently against\nthe candidate, with source locations verified against the original report.','investigation applies every exact reported replacement independently against\nthe recorded pre-retry-guard snapshot, with source locations verified against\nthe original report. The later guard has its own precise fault/control evidence.')
text+='''
## Final diagnosis and verification

All111 exact standalone attempts have retained source/build/test/cleanup receipts.
The disjoint standalone outcome partition is:20 compiler-policy limits,
89 noncompleting attempts, one completed selected-test failure (197), and one
nonreproduction after complete selected and268-row full-fast runs (1469).
Of the noncompleting attempts,68 retain named unfinished sequence entries;
17 others retain console-reported named failures before external cutoff;
four retain an explicit runner limitation: no unfinished sequence or named
failure was emitted before cutoff (1545,1674,1675,1677). Expected and console-
reported row sets identify the exact unreported selection; no test start,
nontermination or settlement is inferred. Named failures occur in27 standalone
cases overall, overlapping the noncompletion categories. The per-case analysis
and raw logs, including console byte offsets, are in `exact-analysis.json`.

The retry fake's old over-budget exception was swallowed by the owner. The
maintained test now returns a fifth candidate, asserts the independent four-
attempt contract first, and returns any unexpectedly successful reservation in
finally before owner disposal. Original terminal diagnostic, distinct deletion,
empty ledger and repeated-acquisition assertions remain. Exact attempt--1445
fails Expected4Actual5 in0.349s body time; independently logged identities show
all5 resources deleted and the actual await-using scope settled. The unchanged
control passes in0.252s with exactly4 resources deleted.

Provider1962/1963 each reaches exactly one intercepted connection-open attempt
before network access; the unchanged control reaches zero. Each named failure
is reported only after actual factory/source cleanup, reserved0/deleted1.

Construction2108/2109/2126 each fails strict standalone CS8604 compilation.
That limitation remains. A separate44.836s pinned-Stryker5 diagnostic uses the
same constructor probe in Debug, no maintained warning-policy change, and
matches each exact original location/replacement to Killed by the sole test.
Each hashed native host trace binds its single active mutant ID to the named
NullReferenceException in Diagnostic/constructor (2126 via FormatMessage).
The source control passes; no application resources are allocated by this probe.
This narrow-file diagnostic's survivors/uncovered/compiler errors remain in its
report; its score is not a whole-suite result. Full mutation remains pending.

All13 final owning monitor/recovery checks pass under coverage collection.
Coverage executes the changed production await. Earlier narrow monitor coverage
leaves existing lines52 and93 unexecuted; no whole-monitor100% claim is made.
The direct fault probes separately exercise cancellation/cleanup and the guard.
Production refactor: keep cancellation at the existing monitor admission point,
without a new public seam or ownership abstraction. Test refactor: retain the
private optional phase writer; make the existing recovery fake finitely settle
and keep every original contract assertion. No general tracing framework or
suite-wide rewrite is introduced.

The first supplemental diagnostic script stopped honestly on the strict CS8604
build before runtime. Its failure and exact cleanup are retained. The corrected
attempt records those compiler outcomes explicitly; the native tool replay then
supplies actual construction runtime evidence. Earlier BuildKit/local-image and
one-off output-path setup failures remain distinguishable from test failures.
'''
text+=f'\nFinal ordinary gate: **268 fast +167 native =435 passed**, no failures/skips, exact discovery/execution partition. Wall time:{result["elapsedSeconds"]:.3f}s. Builds pass without warnings/errors. Before/after labelled-container inventories are empty. The earlier pre-guard435-row checkpoint remains separate historical evidence.\n'
(retain/'results.md').write_text(text)
old='docs/issues/open/testing/TT-012-bound-mutation-liveness-diagnosis-and-failed-test-cleanup.md';new=old.replace('/open/','/resolved/')
investigation=(ROOT/old).read_text()+f'\n- **2026-10-16 — Archive decision:** Independent completion review accepted the bounded diagnosis and initial cleanup/finite-retry repair. All111 historical timeouts retain their original status. [Evidence](../../evidence/2026-10-16/liveness-diagnosis/manifest.json) binds exact faults, limitations, actual representative settlement and the435-row final ordinary gate. This archives the investigation; GitHub owns live status and later lifecycle work.\n'
(OUT/'envelope-investigation.md').write_text(investigation)
readme=(ROOT/'docs/issues/README.md').read_text().replace('Current status — 2026-10-15','Current status — 2026-10-16').replace('**434 tests**','**435 tests**').replace('**267 fast checks**','**268 fast checks**').replace('open/testing/TT-012-bound-mutation-liveness-diagnosis-and-failed-test-cleanup.md','resolved/testing/TT-012-bound-mutation-liveness-diagnosis-and-failed-test-cleanup.md')
(OUT/'envelope-readme.md').write_text(readme)
subprocess.run(['git','add','src/TurboTest.EFCore/Internal/TtCapacityMonitor.cs','tests/TurboTest.Tests/CapacityMonitorTests.cs','tests/TurboTest.Tests/SlotRecoveryTests.cs',str(retain.relative_to(ROOT))],cwd=ROOT,check=True)
index={}
for entry in git('ls-files','--stage','-z').split('\0'):
 if not entry:continue
 meta,name=entry.split('\t',1);mode,oid,stage=meta.split();assert stage=='0';index[name]=(mode,oid)
statuses={item[3:]:item[:2] for item in git('status','--porcelain=v1','-z').split('\0') if item}
paths=[p for p in git('diff','--name-only','-z',BASE).split('\0') if p];records=[]
for name in sorted(paths,key=lambda s:s.encode()):
 mode,oid=index[name];records.append({'path':name,'change':'M' if subprocess.run(['git','cat-file','-e',BASE+':'+name],cwd=ROOT,capture_output=True).returncode==0 else 'A','status':statuses[name],'mode':mode,'sha256':digest(ROOT/name),'stagedObject':oid})
candidate={'schemaVersion':1,'base':BASE,'current':BASE,'branch':'master','upstream':None,'integrationBase':BASE,'paths':records,'excludedUnrelated':[]}
raw=(json.dumps(candidate,sort_keys=True,indent=2)+'\n').encode();(OUT/'candidate.json').write_bytes(raw);fingerprint=hashlib.sha256(raw).hexdigest();(OUT/'candidate.sha256').write_text(fingerprint+'\n')
completion={'ticket':'TT-012','independentVerdict':'PASS','reviewedCandidateSha256':fingerprint,'baseCommit':BASE,'ordinaryTests':435,'historicalTimeouts':111,'rawTimeoutStatusUnchanged':True,'fullMutation':'pending after whole coding session on final immutable source','publication':'local source commits only'};save(OUT/'envelope-completion.json',completion)
issue=json.loads((OUT/'issue-before.json').read_text());body=issue['body'].replace('## Outcome','## Original finding',1).replace('- [ ]','- [x]').replace(old,new)
body+=f'\n## Verification — 2026-10-16\n\nAll111 exact historical Timeout faults have bounded source-bound diagnostics; their original status is retained. Standalone results include20 compiler limitations,89 noncompleting attempts, one completed selected-test failure and one complete268-row nonreproduction. Named assertions, unfinished tests, external cutoffs and runner limits are distinct. Focused probes establish actual monitor/retry/provider settlement and native-Stryker constructor failures. No whole-suite mutation adequacy is claimed.\n\nFinal local ordinary verification passes268 fast +167 native =435 tests, no failures/skips; labelled resources return to empty. Candidate `{fingerprint}` binds the source and evidence. Local source-checkout evidence: `docs/issues/evidence/2026-10-16/liveness-diagnosis/manifest.json`, `results.md`, `runs.tar.gz`, `completion.json`. Source and evidence remain local; no source remote or hosted CI pass is claimed. Whole-session full mutation and final robustness remain tracked by TT-030.\n'
save(OUT/'envelope-issue.json',{'repository_full_name':'DanMarshall909/TurboTest','issue_number':2,'body':body,'state':'closed','state_reason':'completed'})
writes=[{'from':'artifacts/tt-012/envelope-completion.json','to':str((retain/'completion.json').relative_to(ROOT)),'sha256':digest(OUT/'envelope-completion.json'),'mode':'100644'},{'from':'artifacts/tt-012/envelope-investigation.md','to':new,'sha256':digest(OUT/'envelope-investigation.md'),'mode':'100644'},{'from':'artifacts/tt-012/envelope-readme.md','to':'docs/issues/README.md','sha256':digest(OUT/'envelope-readme.md'),'mode':'100644'}]
packet={'ticket':'TT-012','issue':'https://github.com/DanMarshall909/TurboTest/issues/2','acceptedCriteria':'artifacts/tt-012/issue-before.json','criterionMap':'artifacts/tt-012/criteria-draft.md','candidate':'artifacts/tt-012/candidate.json','candidateSha256':fingerprint,'evidence':str(retain.relative_to(ROOT)),'base':BASE,'upstream':None,'integrationPolicy':'docs/issues/README.md declares local source commits and no configured code remote; no pull/push claimed','evidenceQualification':manifest['limits'],'postSessionMutation':'queued for whole-session final source; no new full-run PASS claimed','envelope':{'write':writes,'delete':[{'path':old,'sha256Before':digest(ROOT/old),'reason':'archive investigation at exact resolved path'}],'trackerUpdate':'exact artifacts/tt-012/envelope-issue.json after successful local commit','validation':['reconstruct candidate manifest','reread archive member hashes','git diff --check','match final tree to reviewed candidate plus envelope'],'commit':'Bound liveness diagnostics and preserve failed-test cleanup','push':'none: project local-source policy','cleanup':'Inspect processes/containers/worktrees. Retain clean TT029 validation worktree, warm caches, pinned immutable images and raw diagnostic evidence through TT030; no deletion of unknown/reusable state.'}}
save(OUT/'packet.json',packet)
print(json.dumps({'candidateSha256':fingerprint,'archiveBytes':archive.stat().st_size,'archivedFiles':len(entries),'candidatePaths':len(records)}))
