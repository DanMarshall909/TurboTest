"""Bounded pinned-Stryker diagnostic of the small failure-construction owner."""
from pathlib import Path
import os,sys,json,hashlib,subprocess,fcntl,signal
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-012/constructor-native';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'scripts'));import verify
D=['docker','--host','unix:///var/run/docker.sock'];IMAGE='sha256:135233b24b3c97a3bf46bca4c1bfb1f3eb98ce4eb6555116fcbb3462fd781cbf'
LABEL='com.turbotest.mutation.repo='+str(ROOT)
def call(*args,check=True):return subprocess.run(D+list(args),capture_output=True,text=True,check=check)
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def stop(signum,frame):raise KeyboardInterrupt(signum)
signal.signal(signal.SIGTERM,stop)
lock=(ROOT/'artifacts/tt-009/mutation/active.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not call('ps','-aq','--filter','label='+LABEL).stdout.strip()
host=verify.source_identity()['files']
inputs=OUT/'inputs';inputs.mkdir()
(inputs/'fixture.cs').write_bytes((ROOT/'artifacts/tt-012/supplemental-r2/diagnostic-control/inputs/fixture.cs').read_bytes())
test='TurboTest.Tests.FactoryBackpressureTests.Diagnostic_null_cleanup_failure_constructs_a_safe_lifecycle_failure'
config={'stryker-config':{'project':'TurboTest.EFCore.csproj','test-case-filter':'Category!=PostgreSQL&FullyQualifiedName='+test,'coverage-analysis':'perTest','mutate':['**/TtLifecycleException.cs'],'reporters':['json','cleartext'],'concurrency':1}}
save(inputs/'config.json',config)
command='''set -u
cp /inputs/fixture.cs /work/tests/TurboTest.Tests/FactoryBackpressureTests.cs
sha256sum /work/src/TurboTest.EFCore/TtLifecycleException.cs /work/tests/TurboTest.Tests/FactoryBackpressureTests.cs > /durable/inputs.sha256
dotnet --info > /durable/sdk.log
cd /work/tests/TurboTest.Tests
export DOTNET_ROLL_FORWARD=Major
date +%s%N > /durable/start.ns
timeout --signal=TERM --kill-after=3s 120s dotnet /opt/nuget/packages/dotnet-stryker/5.0.0/tools/net10.0/any/Stryker.CLI.dll --config-file /inputs/config.json --output /durable/stryker --skip-version-check --log-to-file > /durable/stryker.log 2>&1
rc=$?
echo "$rc" > /durable/exit.txt
date +%s%N > /durable/end.ns
exit "$rc"
'''
(OUT/'command.sh').write_text(command);cid=None
try:
 cid=call('create','--label',LABEL,'--label','com.turbotest.mutation.attempt=tt012-constructor-native','--network','none','--cap-drop','ALL','--security-opt','no-new-privileges','--user','1000:1000','--memory','4g','--memory-swap','4g','--cpus','2','--pids-limit','512','--mount','type=bind,src='+str(inputs)+',dst=/inputs,readonly','--mount','type=bind,src='+str(OUT)+',dst=/durable',IMAGE,'/bin/bash','-c',command).stdout.strip()
 save(OUT/'owner.json',{'id':cid,'image':IMAGE,'sourceScope':'TtLifecycleException.cs only','selectedTest':test,'purpose':'diagnostic only; not final full mutation adequacy','hostFiles':host,'testDeadlineSeconds':120,'warningPolicy':'unchanged; pinned native Stryker instrumentation/compiler pipeline'})
 try:verify.run_phase('constructor-native',D+['start','--attach',cid],ROOT/'artifacts/tt-012',180)
 except verify.VerificationError:pass
 details=json.loads(call('inspect','--size',cid).stdout)[0];save(OUT/'terminal.json',details)
 assert not details['State']['Running'] and details['State']['Pid']==0 and not details['State']['OOMKilled']
 assert verify.source_identity()['files']==host
 save(OUT/'receipt.json',{'exitCode':details['State']['ExitCode'],'seconds':(int((OUT/'end.ns').read_text())-int((OUT/'start.ns').read_text()))/1e9,'originalStatuses':'Timeout unchanged; native report retained separately','hostSourceUnchanged':True,'namespaceStopped':True,'readReportBeforeClaimingRuntimeFault':True})
finally:
 if cid:
  details=json.loads(call('inspect','--size',cid).stdout)[0]
  if details['State']['Running']:call('stop','--time','3',cid);details=json.loads(call('inspect','--size',cid).stdout)[0]
  assert not details['State']['Running'] and details['State']['Pid']==0
  (OUT/'diff.txt').write_text(call('diff',cid).stdout);call('rm',cid)
  assert call('inspect',cid,check=False).returncode!=0
  save(OUT/'cleanup.json',{'id':cid,'removed':True,'namespaceStopped':True,'reclaimedWritableBytes':details.get('SizeRw'),'imageRetained':IMAGE})
assert call('image','inspect',IMAGE,'--format','{{.Id}}').stdout.strip()==IMAGE
print(json.dumps(json.loads((OUT/'receipt.json').read_text())),flush=True)
