set -u
cp /inputs/fixture.cs /work/tests/TurboTest.Tests/FactoryBackpressureTests.cs
sha256sum /work/src/TurboTest.EFCore/TtLifecycleException.cs /work/tests/TurboTest.Tests/FactoryBackpressureTests.cs > /durable/inputs.sha256
dotnet --info > /durable/sdk.log
cd /work/tests/TurboTest.Tests
export DOTNET_ROLL_FORWARD=Major
date +%s%N > /durable/start.ns
timeout --signal=TERM --kill-after=3s 120s dotnet /opt/nuget/packages/dotnet-stryker/5.0.0/tools/net10.0/any/Stryker.CLI.dll --config-file /inputs/config.json --output /durable/stryker --skip-version-check --log-to-file > /durable/stryker.log 2>&1
rc=$?
echo "$rc" > /durable/exit.txt
date +%s%N > /durable/end.ns
exit "$rc"
