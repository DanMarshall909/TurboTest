"""One-off ordered TT012 work; waits for actual batch process termination."""
from pathlib import Path
import os, sys, time, json, subprocess, hashlib, signal
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-012'
sys.path.insert(0,str(ROOT/'scripts'));import verify
def interrupted(signum,frame):raise KeyboardInterrupt(signum)
signal.signal(signal.SIGTERM,interrupted)
pid=int(sys.argv[1]);cmdline=Path(f'/proc/{pid}/cmdline')
expected=b'python3\0artifacts/tt-012/batch-replay.py\0'
assert cmdline.read_bytes()==expected, 'Only wait on the observed exact live batch process'
candidate=OUT/'retry-guard-candidate.cs';candidate_bytes=candidate.read_bytes();digest=hashlib.sha256(candidate_bytes).hexdigest()
verify.write_json(OUT/'continuation-owner.json',{'pid':os.getpid(),'waitedPid':pid,'waitedCommand':expected.decode().replace('\0',' '),'candidateSha256':digest,'maintainedWrite':'tests/TurboTest.Tests/SlotRecoveryTests.cs','sequence':['wait actual batch termination','require111 terminal+cleanup','analyze','supplemental controls/faults','adopt byte-bound reviewed retry test','owning build/coverage','canonical all suite']})
while cmdline.exists():
    try:current=cmdline.read_bytes()
    except FileNotFoundError:break
    if current!=expected:break # Never interpret a reused PID as the prior worker.
    time.sleep(5)
terminal=json.loads((OUT/'exact-replays/terminal.json').read_text())
assert terminal['completed']==terminal['expected']==111 and terminal['hostSourcesUnchanged'] and terminal['ownedContainersAbsent']
subprocess.run([sys.executable,str(OUT/'analyze-replays.py')],cwd=ROOT,check=True)
with (OUT/'supplemental.log').open('x') as log:
    subprocess.run([sys.executable,str(OUT/'supplemental-probes.py')],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
assert json.loads((OUT/'supplemental/terminal.json').read_text())['completed']==9
assert verify.source_identity()['files']==json.loads((OUT/'exact-replays/identity.json').read_text())['hostFiles']
assert candidate.read_bytes()==candidate_bytes
target=ROOT/'tests/TurboTest.Tests/SlotRecoveryTests.cs'
before=hashlib.sha256(target.read_bytes()).hexdigest()
target.write_bytes(candidate_bytes)
verify.write_json(OUT/'retry-adoption.json',{'path':str(target.relative_to(ROOT)),'beforeSha256':before,'afterSha256':digest,'source':'retry-guard-candidate.cs','priorProbe':'supplemental/retry-1445/receipt.json','scope':'finite invocation guard and return unexpected successful reservation; no production retry change'})
verify.write_json(OUT/'retry-source-before.json',verify.source_identity())
verify.run_phase('retry-build',['dotnet','build','tests/TurboTest.Tests/TurboTest.Tests.csproj','-c','Release','-nr:false','-p:UseSharedCompilation=false','--verbosity','minimal'],OUT,180)
verify.run_phase('retry-coverage',['dotnet','test','tests/TurboTest.Tests/TurboTest.Tests.csproj','--no-build','--no-restore','-c','Release','--filter','Category!=PostgreSQL&(FullyQualifiedName~TurboTest.Tests.CapacityMonitorTests|FullyQualifiedName~TurboTest.Tests.SlotRecoveryTests)','--collect','Code Coverage;Format=cobertura','--results-directory',str(OUT/'retry-coverage'),'--logger','trx;LogFileName=owning.trx','--blame-hang-timeout','10s','--blame-hang-dump-type','none'],OUT,30)
verify.write_json(OUT/'retry-source-after.json',verify.source_identity())
with (OUT/'final-all.log').open('x') as log:
    subprocess.run([sys.executable,'scripts/verify.py','all','--output','artifacts/tt-012/final-all'],cwd=ROOT,env=dict(os.environ,DOCKER_HOST='unix:///var/run/docker.sock'),stdout=log,stderr=subprocess.STDOUT,check=True)
assert json.loads((OUT/'final-all/verification.json').read_text())['result']=='PASS'
verify.write_json(OUT/'continuation-terminal.json',{'result':'PASS','adoptedTestSha256':digest,'finalDriver':'final-all/verification.json','remaining':'freeze evidence packet and independent completion review before commit/archive/issue closure'})
print('TT012 diagnostics, retry guard and final ordinary suite complete; independent completion review pending.',flush=True)
