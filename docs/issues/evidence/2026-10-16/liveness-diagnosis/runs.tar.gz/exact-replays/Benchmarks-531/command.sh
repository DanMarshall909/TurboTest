set -u
cp /inputs/fault.cs /work/benchmarks/TurboTest.Benchmarks/BenchmarkSchedule.cs
sha256sum /work/benchmarks/TurboTest.Benchmarks/BenchmarkSchedule.cs > /durable/applied.sha256
date +%s%N > /durable/build-start.ns
dotnet build tests/TurboTest.Tests/TurboTest.Tests.csproj --no-restore -c Release -nr:false -p:UseSharedCompilation=false --verbosity minimal > /durable/build.log 2>&1
rc=$?
echo "$rc" > /durable/build-exit.txt
date +%s%N > /durable/build-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
export TURBOTEST_MONITOR_PHASE_LOG=/durable/phases.jsonl
date +%s%N > /durable/selected-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL&(FullyQualifiedName=TurboTest.Tests.BenchmarkCommandTests.Adaptive_plan_command_persists_matched_startup_and_default_policy_without_allocating_resources|FullyQualifiedName=TurboTest.Tests.BenchmarkCommandTests.Supported_plan_invocation_validates_and_writes_the_exact_repeated_schedule|FullyQualifiedName=TurboTest.Tests.BenchmarkScheduleTests.A_zero_or_misdistributed_plan_is_rejected_before_any_fixture_starts|FullyQualifiedName=TurboTest.Tests.BenchmarkScheduleTests.Adaptive_comparison_pairs_equal_startup_with_an_already_warm_fixed_control|FullyQualifiedName=TurboTest.Tests.BenchmarkScheduleTests.Adaptive_comparison_requires_a_real_stabilization_idle_and_preserves_matched_startup|FullyQualifiedName=TurboTest.Tests.BenchmarkScheduleTests.Invalid_or_unequal_phase_delays_are_rejected_before_any_fixture_starts|FullyQualifiedName=TurboTest.Tests.BenchmarkScheduleTests.Repeated_configs_have_counterbalanced_order_and_equivalent_real_workloads)' --results-directory /durable/selected > /durable/selected.log 2>&1
rc=$?
echo "$rc" > /durable/selected-exit.txt
date +%s%N > /durable/selected-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
date +%s%N > /durable/full-fast-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL' --results-directory /durable/full-fast > /durable/full-fast.log 2>&1
rc=$?
echo "$rc" > /durable/full-fast-exit.txt
date +%s%N > /durable/full-fast-end.ns
exit "$rc"
