set -u
cp /inputs/fault.cs /work/src/TurboTest.EFCore/Internal/TtScopedLease.cs
sha256sum /work/src/TurboTest.EFCore/Internal/TtScopedLease.cs > /durable/applied.sha256
date +%s%N > /durable/build-start.ns
dotnet build tests/TurboTest.Tests/TurboTest.Tests.csproj --no-restore -c Release -nr:false -p:UseSharedCompilation=false --verbosity minimal > /durable/build.log 2>&1
rc=$?
echo "$rc" > /durable/build-exit.txt
date +%s%N > /durable/build-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
export TURBOTEST_MONITOR_PHASE_LOG=/durable/phases.jsonl
date +%s%N > /durable/selected-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL&(FullyQualifiedName=TurboTest.Tests.DiScopeLifetimeTests.Canceled_initialization_observation_does_not_abandon_the_scope_owned_job|FullyQualifiedName=TurboTest.Tests.DiScopeLifetimeTests.Resolved_scope_ownership_disposes_its_context_exactly_once|FullyQualifiedName=TurboTest.Tests.DiScopeLifetimeTests.Scope_disposal_joins_pending_initialization_and_the_actual_lease_return|FullyQualifiedName=TurboTest.Tests.DiScopeLifetimeTests.Synchronous_disposal_rejects_async_ownership_and_the_captured_owner_can_still_drain)' --results-directory /durable/selected > /durable/selected.log 2>&1
rc=$?
echo "$rc" > /durable/selected-exit.txt
date +%s%N > /durable/selected-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
date +%s%N > /durable/full-fast-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL' --results-directory /durable/full-fast > /durable/full-fast.log 2>&1
rc=$?
echo "$rc" > /durable/full-fast-exit.txt
date +%s%N > /durable/full-fast-end.ns
exit "$rc"
