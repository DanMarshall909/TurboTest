set -u
cp /inputs/fault.cs /work/src/TurboTest.EFCore/Internal/TtSlotPool.cs
sha256sum /work/src/TurboTest.EFCore/Internal/TtSlotPool.cs > /durable/applied.sha256
date +%s%N > /durable/build-start.ns
dotnet build tests/TurboTest.Tests/TurboTest.Tests.csproj --no-restore -c Release -nr:false -p:UseSharedCompilation=false --verbosity minimal > /durable/build.log 2>&1
rc=$?
echo "$rc" > /durable/build-exit.txt
date +%s%N > /durable/build-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
export TURBOTEST_MONITOR_PHASE_LOG=/durable/phases.jsonl
date +%s%N > /durable/selected-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL&(FullyQualifiedName=TurboTest.Tests.AdaptiveSlotTests.A_ready_exhaustion_between_ticks_restarts_the_actual_spare_window|FullyQualifiedName=TurboTest.Tests.AdaptiveSlotTests.Failed_background_growth_retains_its_terminal_error_when_the_queued_caller_cancels|FullyQualifiedName=TurboTest.Tests.AdaptiveSlotTests.Protected_ready_capacity_is_not_spare_and_does_not_age_a_shrink_window|FullyQualifiedName=TurboTest.Tests.AdaptiveSlotTests.Queued_demand_cannot_reserve_above_the_warm_target_until_a_stabilized_atomic_growth_claim|FullyQualifiedName=TurboTest.Tests.AdaptiveSlotTests.Renewed_pressure_rewarms_the_retained_identity_at_a_full_physical_cap|FullyQualifiedName=TurboTest.Tests.AdaptiveSlotTests.Stabilized_shrink_claims_only_one_ready_slot_and_awaits_its_actual_closure|FullyQualifiedName=TurboTest.Tests.CapacityTelemetryTests.Decisions_report_safe_reasons_state_resource_age_and_actual_maintenance_latency|FullyQualifiedName=TurboTest.Tests.CapacityTelemetryTests.Exhausted_growth_reports_failed_realization_and_future_ticks_hold_unavailable_capacity|FullyQualifiedName=TurboTest.Tests.CapacityTelemetryTests.Failed_shrink_reports_actual_failure_and_closure_duration_without_replacing_the_error)' --results-directory /durable/selected > /durable/selected.log 2>&1
rc=$?
echo "$rc" > /durable/selected-exit.txt
date +%s%N > /durable/selected-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
date +%s%N > /durable/full-fast-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL' --results-directory /durable/full-fast > /durable/full-fast.log 2>&1
rc=$?
echo "$rc" > /durable/full-fast-exit.txt
date +%s%N > /durable/full-fast-end.ns
exit "$rc"
