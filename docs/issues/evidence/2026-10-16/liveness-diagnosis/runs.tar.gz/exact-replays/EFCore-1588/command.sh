set -u
cp /inputs/fault.cs /work/src/TurboTest.EFCore/Internal/TtSlotPool.cs
sha256sum /work/src/TurboTest.EFCore/Internal/TtSlotPool.cs > /durable/applied.sha256
date +%s%N > /durable/build-start.ns
dotnet build tests/TurboTest.Tests/TurboTest.Tests.csproj --no-restore -c Release -nr:false -p:UseSharedCompilation=false --verbosity minimal > /durable/build.log 2>&1
rc=$?
echo "$rc" > /durable/build-exit.txt
date +%s%N > /durable/build-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
export TURBOTEST_MONITOR_PHASE_LOG=/durable/phases.jsonl
date +%s%N > /durable/selected-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL&(FullyQualifiedName=TurboTest.Tests.CapacityTelemetryTests.Failed_shrink_reports_actual_failure_and_closure_duration_without_replacing_the_error|FullyQualifiedName=TurboTest.Tests.FactoryRewarmDrainTests.Factory_closure_stops_rewarm_replacement_before_a_different_lease_finishes_cleanup|FullyQualifiedName=TurboTest.Tests.SlotIdleRecoveryTests.Failed_idle_work_keeps_capacity_through_unconfirmed_deletion_then_publishes_one_verified_replacement|FullyQualifiedName=TurboTest.Tests.SlotIdleRecoveryTests.Failed_rewarm_releases_preparation_before_waiting_for_cleanup_held_by_replacement|FullyQualifiedName=TurboTest.Tests.SlotPoolTests.A_failed_reset_keeps_its_execution_permit_until_compensating_cleanup_finishes|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.A_corrupt_recovery_candidate_is_deleted_and_a_verified_retry_restores_capacity|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.A_failed_reset_restores_verified_capacity_even_without_a_waiting_acquisition|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.An_unconfirmed_drop_is_retried_without_releasing_capacity_or_failing_waiting_callers|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.Cleanup_retries_do_not_restart_the_three_candidate_recovery_budget|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.Repeated_drop_failure_exhausts_three_attempts_and_retains_the_owned_resource|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.Shutdown_settles_pending_lifecycle_work_before_deletion_without_publishing_new_capacity|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.Three_failed_recovery_preparations_settle_waiters_with_a_terminal_diagnostic|FullyQualifiedName=TurboTest.Tests.SlotRewarmDrainTests.A_rewarm_failure_delivered_by_exhausted_cleanup_is_not_reported_again_at_drain|FullyQualifiedName=TurboTest.Tests.SlotRewarmDrainTests.Closure_during_recovery_retains_the_live_rewarm_failure_through_confirmed_deletion|FullyQualifiedName=TurboTest.Tests.SlotRewarmDrainTests.Closure_joins_rewarm_and_reports_material_late_failure_once_without_replacement|FullyQualifiedName=TurboTest.Tests.SlotRewarmDrainTests.Shutdown_canceling_the_retry_delay_retains_the_unseen_rewarm_failure|FullyQualifiedName=TurboTest.Tests.SlotTimingTests.Reset_execution_excludes_permit_wait_and_failure_recovery)' --results-directory /durable/selected > /durable/selected.log 2>&1
rc=$?
echo "$rc" > /durable/selected-exit.txt
date +%s%N > /durable/selected-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
date +%s%N > /durable/full-fast-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL' --results-directory /durable/full-fast > /durable/full-fast.log 2>&1
rc=$?
echo "$rc" > /durable/full-fast-exit.txt
date +%s%N > /durable/full-fast-end.ns
exit "$rc"
