set -u
cp /inputs/fault.cs /work/src/TurboTest.EFCore/Internal/TtSlotPool.cs
sha256sum /work/src/TurboTest.EFCore/Internal/TtSlotPool.cs > /durable/applied.sha256
date +%s%N > /durable/build-start.ns
dotnet build tests/TurboTest.Tests/TurboTest.Tests.csproj --no-restore -c Release -nr:false -p:UseSharedCompilation=false --verbosity minimal > /durable/build.log 2>&1
rc=$?
echo "$rc" > /durable/build-exit.txt
date +%s%N > /durable/build-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
export TURBOTEST_MONITOR_PHASE_LOG=/durable/phases.jsonl
date +%s%N > /durable/selected-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL&(FullyQualifiedName=TurboTest.Tests.AdaptiveSlotTests.Failed_background_growth_retains_its_terminal_error_when_the_queued_caller_cancels|FullyQualifiedName=TurboTest.Tests.CapacityTelemetryTests.Exhausted_growth_reports_failed_realization_and_future_ticks_hold_unavailable_capacity|FullyQualifiedName=TurboTest.Tests.SlotPoolTests.Failed_preparations_share_the_cleanup_limit_before_releasing_reservations|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.Cleanup_retries_do_not_restart_the_three_candidate_recovery_budget|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.Three_failed_recovery_preparations_settle_waiters_with_a_terminal_diagnostic)' --results-directory /durable/selected > /durable/selected.log 2>&1
rc=$?
echo "$rc" > /durable/selected-exit.txt
date +%s%N > /durable/selected-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
date +%s%N > /durable/full-fast-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL' --results-directory /durable/full-fast > /durable/full-fast.log 2>&1
rc=$?
echo "$rc" > /durable/full-fast-exit.txt
date +%s%N > /durable/full-fast-end.ns
exit "$rc"
