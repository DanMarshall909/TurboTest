set -u
cp /inputs/fault.cs /work/src/TurboTest.EFCore/Internal/TtSlotPool.cs
sha256sum /work/src/TurboTest.EFCore/Internal/TtSlotPool.cs > /durable/applied.sha256
date +%s%N > /durable/build-start.ns
dotnet build tests/TurboTest.Tests/TurboTest.Tests.csproj --no-restore -c Release -nr:false -p:UseSharedCompilation=false --verbosity minimal > /durable/build.log 2>&1
rc=$?
echo "$rc" > /durable/build-exit.txt
date +%s%N > /durable/build-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
export TURBOTEST_MONITOR_PHASE_LOG=/durable/phases.jsonl
date +%s%N > /durable/selected-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL&(FullyQualifiedName=TurboTest.Tests.FactoryMaintenanceTests.Bulk_maintenance_reports_all_safe_failures_and_does_not_repeat_delivered_faults_on_drain|FullyQualifiedName=TurboTest.Tests.FactoryMaintenanceTests.Canceled_maintenance_preserves_its_actual_work_and_late_failure_through_cleanup|FullyQualifiedName=TurboTest.Tests.FactoryMaintenanceTests.Unseen_maintenance_failure_does_not_hide_a_distinct_first_pool_drain_failure|FullyQualifiedName=TurboTest.Tests.SlotIdleRecoveryTests.Failed_idle_work_keeps_capacity_through_unconfirmed_deletion_then_publishes_one_verified_replacement|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.An_unconfirmed_drop_is_retried_without_releasing_capacity_or_failing_waiting_callers|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.Cleanup_retries_do_not_restart_the_three_candidate_recovery_budget|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.Repeated_drop_failure_exhausts_three_attempts_and_retains_the_owned_resource|FullyQualifiedName=TurboTest.Tests.SlotRecoveryTests.Shutdown_settles_pending_lifecycle_work_before_deletion_without_publishing_new_capacity|FullyQualifiedName=TurboTest.Tests.SlotRetentionTests.Retirement_retry_preserves_capacity_and_replaces_only_for_renewed_demand|FullyQualifiedName=TurboTest.Tests.SlotRewarmDrainTests.A_rewarm_failure_delivered_by_exhausted_cleanup_is_not_reported_again_at_drain|FullyQualifiedName=TurboTest.Tests.SlotRewarmDrainTests.Closure_during_recovery_retains_the_live_rewarm_failure_through_confirmed_deletion|FullyQualifiedName=TurboTest.Tests.SlotRewarmDrainTests.Shutdown_canceling_the_retry_delay_retains_the_unseen_rewarm_failure)' --results-directory /durable/selected > /durable/selected.log 2>&1
rc=$?
echo "$rc" > /durable/selected-exit.txt
date +%s%N > /durable/selected-end.ns
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
date +%s%N > /durable/full-fast-start.ns
timeout --signal=TERM --kill-after=3s 10s dotnet test tests/TurboTest.Tests/TurboTest.Tests.csproj --no-build --no-restore -c Release --logger trx\;LogFileName=probe.trx --verbosity normal --blame-hang-timeout 5s --blame-hang-dump-type none --filter 'Category!=PostgreSQL' --results-directory /durable/full-fast > /durable/full-fast.log 2>&1
rc=$?
echo "$rc" > /durable/full-fast-exit.txt
date +%s%N > /durable/full-fast-end.ns
exit "$rc"
