"""One-off lifetime-slice packet: run only after both final gates terminate."""
from pathlib import Path
import hashlib, json, subprocess, sys, tarfile, xml.etree.ElementTree as ET

ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/lifetimes'
BASE = '7495ccf50da085dbfcbcd9f5a8ebdf85355e37b9'
SOURCE = [
    'src/TurboTest.EFCore/Internal/TtSlotPool.cs',
    'tests/TurboTest.Tests/StartupLateDrainTests.cs',
    'tests/TurboTest.Tests/CapacityMonitorTests.cs',
    'tests/TurboTest.Tests/CleanupRetentionTests.cs',
    'tests/TurboTest.Tests/SlotRegistrationLifetimeTests.cs',
    'tests/TurboTest.Tests/LeaseOwnershipTests.cs',
    'tests/TurboTest.Tests/SlotPoolTests.cs',
]
sys.path.insert(0, str(ROOT / 'scripts'))
import verify

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT).decode()

assert git('rev-parse', 'HEAD').strip() == BASE
assert git('branch', '--show-current').strip() == 'master'
assert not git('remote').strip()
run = OUT / 'final-all'
result = json.loads((run / 'verification.json').read_text())
assert result['result'] == 'PASS'
assert result['tests']['fast']['passed'] == 290
assert result['tests']['slow']['passed'] == 168
assert result['resourceSettlement']['before'] == result['resourceSettlement']['after']
assert not result['resourceSettlement']['added'] and not result['resourceSettlement']['removed']
binding = json.loads((run / 'source-identity.json').read_text())
assert binding == verify.source_identity()
coverage = json.loads((OUT / 'final-owning-coverage.json').read_text())
assert coverage['exitCode'] == 0 and not coverage['deadlineExceeded']
assert json.loads((OUT / 'final-owning-source.json').read_text())== binding
catalog = json.loads((run / 'test-catalog.json').read_text())
owners = ('TurboTest.Tests.StartupLateDrainTests.', 'TurboTest.Tests.CapacityMonitorTests.',
          'TurboTest.Tests.CleanupRetentionTests.', 'TurboTest.Tests.SlotRegistrationLifetimeTests.',
          'TurboTest.Tests.LeaseOwnershipTests.Reentrant_return_observer',
          'TurboTest.Tests.SlotPoolTests.Reentrant_deletion_observes')
expected_rows = {row['id'] for row in catalog['all'] if row['name'].startswith(owners)}
coverage_rows = ET.parse(OUT / 'final-owning-coverage/results.trx').findall('.//{*}UnitTestResult')
assert len(expected_rows) == len(coverage_rows) == 23
assert {row.get('testId') for row in coverage_rows} == expected_rows
assert all(row.get('outcome') == 'Passed' for row in coverage_rows)
for name in SOURCE:
    target = OUT / 'candidate-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
for name, sha in binding['resolvedDependencies'].items():
    assert digest(ROOT / name) == sha
    target = OUT / 'resolved-dependencies' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())

retain = ROOT / 'docs/issues/evidence/2026-10-22/cleanup-lifetimes'
retain.mkdir(parents=True, exist_ok=False)
excluded = {'candidate.json', 'candidate.sha256', 'packet.json', 'envelope-completion.json', 'next-goal-request.json'}
items = sorted((p for p in OUT.rglob('*') if p.is_file() and p.name not in excluded
                and '__pycache__' not in p.parts and 'calibration-build' not in p.parts), key=lambda p: str(p.relative_to(OUT)).encode())
entries = []
archive = retain / 'runs.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in items:
        assert not path.is_symlink() and path.resolve().is_relative_to(OUT.resolve())
        name = str(path.relative_to(OUT))
        tar.add(path, arcname=name, recursive=False)
        entries.append({'path': name, 'sha256': digest(path), 'bytes': path.stat().st_size})
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(entries)
    for entry in entries:
        assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest() == entry['sha256']
limits = [
    'Bounded TT-024/TT-023 lifetime/reentry slice only. Both issues remain open.',
    '15 new characterization rows were green on introduction; compiled faults calibrate their assertions. No new production repair RED is claimed.',
    'Only redundant self-Unregister1439 is removed; pinned runtime/current producer proof is bounded. Pending unregisters and both reentry barriers remain.',
    'Slot1691 proves internal owner/deletion-adapter publication, not established deterministic public-factory reachability. Lease2096 models the legitimate return observer boundary.',
    'Historical original mutation statuses are unchanged. Whole-session mutation remains pending until the final coding-session snapshot.',
    'No timing/deadline/concurrency/lane or PostgreSQL server setting was changed for the final gate. External read-only observer adds a diagnostic connection; not performance/admin-budget evidence.',
    'Source and evidence commits local only, no configured code remote. Unknown pre-existing stopped container preserved; before/after labelled inventories match.',
    'All historical collector/setup/line-attribution qualifications are retained in results.md and raw receipts.',
]
manifest = {'schemaVersion': 1, 'slice': 'TT-024/TT-023 cancellation, lifetime and reentry', 'baseCommit': BASE,
            'candidateSource': {name: binding['files'][name] for name in SOURCE},
            'archive': {'path': 'runs.tar.gz', 'sha256': digest(archive), 'bytes': archive.stat().st_size},
            'files': entries, 'verification': result, 'limits': limits}
save(retain / 'manifest.json', manifest)
results = (OUT / 'results-draft.md').read_text()
results += f'\nFinal ordinary gate: **290 fast + 168 PostgreSQL = 458 passed**, no failures/skips. Total {result["elapsedSeconds"]:.3f}s. Solution and separate example builds pass. Exact discovered/executed IDs and matching before/after labelled Docker inventories are retained. Final 23-row owning coverage binds the same source, binaries and dependencies. Independent verdict will be recorded separately in completion.json after review.\n'
(retain / 'results.md').write_text(results)

investigations = [
    'docs/issues/open/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md',
    'docs/issues/open/api/TT-023-assert-late-failure-ordering-and-safe-diagnostic-identity.md',
]
for name in investigations:
    path = ROOT / name
    path.write_text(path.read_text() + '\n- **2026-10-22 — Lifetime and reentry slice:** [Source-bound evidence](../../evidence/2026-10-22/cleanup-lifetimes/manifest.json) records initializer/monitor cancellation-source lifetime, completed recovery payload release, pending registration release and direct reentrant drain publication. One redundant self-unregister is removed under a bounded producer/runtime proof; useful pending unregisters and reentry barriers remain. Final verification is 458 passing checks with 23 source-bound owning coverage rows. Both issues and the remaining linked questions stay open; the exact independent verdict is recorded in `completion.json`.\n')
readme = ROOT / 'docs/issues/README.md'
readme.write_text(readme.read_text().replace('**443 tests**', '**458 tests**', 1).replace('**275 fast checks**', '**290 fast checks**', 1))
subprocess.run(['git', 'add', *SOURCE, *investigations, 'docs/issues/README.md', str(retain.relative_to(ROOT))], cwd=ROOT, check=True)
index = {}
for row in git('ls-files', '--stage', '-z').split('\0'):
    if not row: continue
    meta, name = row.split('\t', 1)
    mode, oid, stage = meta.split()
    assert stage == '0'
    index[name] = (mode, oid)
statuses = {item[3:]: item[:2] for item in git('status', '--porcelain=v1', '-z').split('\0') if item}
paths = [p for p in git('diff', '--name-only', '-z', BASE).split('\0') if p]
expected = set(SOURCE + investigations + ['docs/issues/README.md'] +
               [str((retain / n).relative_to(ROOT)) for n in ('runs.tar.gz', 'manifest.json', 'results.md')])
assert set(paths) == expected and set(statuses) == expected
records = []
for name in sorted(paths, key=lambda s: s.encode()):
    mode, oid = index[name]
    assert mode == '100644' and not (ROOT / name).is_symlink()
    change = 'M' if subprocess.run(['git', 'cat-file', '-e', BASE + ':' + name], cwd=ROOT, capture_output=True).returncode == 0 else 'A'
    records.append({'path': name, 'change': change, 'status': statuses[name], 'mode': mode,
                    'sha256': digest(ROOT / name), 'stagedObject': oid})
candidate = {'schemaVersion': 1, 'base': BASE, 'current': BASE, 'branch': 'master',
             'upstream': None, 'integrationBase': BASE, 'paths': records, 'excludedUnrelated': []}
raw = (json.dumps(candidate, sort_keys=True, indent=2) + '\n').encode()
(OUT / 'candidate.json').write_bytes(raw)
fingerprint = hashlib.sha256(raw).hexdigest()
(OUT / 'candidate.sha256').write_text(fingerprint + '\n')
completion = {'slice': 'TT-024/TT-023 cancellation, lifetime and reentry', 'independentVerdict': 'PASS', 'reviewer': '/root/tt024_lifetime_review',
              'reviewedCandidateSha256': fingerprint, 'baseCommit': BASE, 'ordinaryTests': 458,
              'issuesRemainOpen': [13, 14], 'wholeSessionMutation': 'pending after final coding-session snapshot',
              'publication': 'local source commit only'}
save(OUT / 'envelope-completion.json', completion)
packet = {'slice': 'TT-024/TT-023 cancellation, lifetime and reentry', 'acceptedScopeAndCriteria': str((retain / 'results.md').relative_to(ROOT)),
          'candidate': 'artifacts/tt-024/lifetimes/candidate.json', 'candidateSha256': fingerprint,
          'base': BASE, 'upstream': None, 'integrationPolicy': 'Local source commits only, docs/issues/README.md',
          'evidence': str(retain.relative_to(ROOT)), 'limits': limits,
          'envelope': {'write': [{'from': 'artifacts/tt-024/lifetimes/envelope-completion.json',
                                  'to': str((retain / 'completion.json').relative_to(ROOT)),
                                  'sha256': digest(OUT / 'envelope-completion.json'), 'mode': '100644'}],
                       'validation': ['reconstruct candidate manifest and archive hashes', 'git diff --check',
                                      'match final tree to candidate plus exact completion write'],
                       'commit': 'Verify cancellation lifetimes and retain shared reentrant drains', 'push': 'none: local source policy',
                       'trackerUpdate': 'none: both issues remain open; no acceptance checklist or archive change',
                       'cleanup': 'Inspect only; retain source/evidence, warm calibration build and immutable images. No deletion of unknown or reusable state.'}}
save(OUT / 'packet.json', packet)
print(json.dumps({'candidateSha256': fingerprint, 'candidatePaths': len(records), 'archiveBytes': archive.stat().st_size, 'archiveMembers': len(entries)}))
