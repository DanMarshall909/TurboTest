"""Bounded source-substitution calibration, outside maintained compiler outputs."""
from pathlib import Path
import hashlib,importlib.util,json,os,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/lifetimes'
spec=importlib.util.spec_from_file_location('verify',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
source=ROOT/'src/TurboTest.EFCore/Tt.cs';original=source.read_text();before=v.source_identity()
fault=OUT/'fault-Tt.cs';targets=OUT/'Fault.targets';build=OUT/'calibration-build'
compiled=OUT/'evaluated-compile-inputs.txt'
targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="Tt.cs" /><Compile Include="{fault}" /></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{compiled}" Lines="@(Compile->'%(FullPath)')" Overwrite="true" /></Target></Project>''')
variants={
 '1769':('var cleanupOwnsCancellation = false;','var cleanupOwnsCancellation = true;'),
 '1777':('cleanupOwnsCancellation = true;','cleanupOwnsCancellation = false;'),
 '1787':('finally { initializationCancellation.Dispose(); }','finally { }'),
 '1839':('if (!cleanupOwnsCancellation) initializationCancellation.Dispose();','if (cleanupOwnsCancellation) initializationCancellation.Dispose();'),
 '1840':('if (!cleanupOwnsCancellation) initializationCancellation.Dispose();',';')}
results=[]
try:
 for i,(old,new) in variants.items():
  assert original.count(old)==1
  text=original.replace(old,new);assert text!=original;fault.write_text(text)
  (OUT/('fault-'+i+'-Tt.cs')).write_text(text)
  command=['dotnet','build','tests/TurboTest.Tests/TurboTest.Tests.csproj','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false','--verbosity','minimal']
  if results:command.append('--no-restore')
  v.run_phase('fault-'+i+'-build',command,OUT,120,os.environ)
  inputs=compiled.read_text().splitlines();assert str(fault) in inputs and str(source) not in inputs
  (OUT/('fault-'+i+'-compile-inputs.txt')).write_text(compiled.read_text())
  dll=build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
  deps={str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*')) if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}
  v.write_json(OUT/('fault-'+i+'-binding.json'),{'originalSourceSha256':hashlib.sha256(original.encode()).hexdigest(),'faultSourceSha256':hashlib.sha256(text.encode()).hexdigest(),'replacement':{'old':old,'new':new},'compiledInputs':deps,'primarySourceUnchanged':before==v.source_identity()})
  try:v.run_phase('fault-'+i+'-test',['dotnet','test',str(dll),'--filter','FullyQualifiedName~Successful_initialization_releases_its_cancellation_handle|FullyQualifiedName~Interrupted_initialization_keeps_its_cancellation_handle','--results-directory',str(OUT/('fault-'+i+'-results')),'--logger','trx;LogFileName=results.trx'],OUT,30,os.environ)
  except v.VerificationError:pass
  receipt=json.loads((OUT/('fault-'+i+'-test.json')).read_text());assert receipt['exitCode']==1 and not receipt['deadlineExceeded']
  rows=E.parse(OUT/('fault-'+i+'-results/results.trx')).findall('.//{*}UnitTestResult');assert len(rows)==5
  failed=[{'name':r.get('testName'),'message':r.findtext('.//{*}Message')} for r in rows if r.get('outcome')=='Failed']
  assert failed and all('Successful_initialization_releases_its_cancellation_handle' in r['name'] or 'Interrupted_initialization_keeps_its_cancellation_handle' in r['name'] for r in failed)
  results.append({'originalQuestion':i,'failedRows':failed,'qualification':'One bounded compiled source fault calibration, not a full mutation run or relabelled original report outcome.'})
  v.write_json(OUT/'initializer-calibration-progress.json',results)
  print('fault',i,'named lifetime assertions failed:',len(failed),flush=True)
finally:
 assert source.read_text()==original and before==v.source_identity()
 v.write_json(OUT/'initializer-calibration-primary-after.json',v.source_identity())
v.write_json(OUT/'initializer-calibration.json',{'baseCommit':'7495ccf50da085dbfcbcd9f5a8ebdf85355e37b9','primaryInputsUnchanged':True,'results':results})
