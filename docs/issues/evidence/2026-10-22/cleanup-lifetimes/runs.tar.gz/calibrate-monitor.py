"""Bounded missing-disposal calibration using a separate compile source item."""
from pathlib import Path
import hashlib,importlib.util,json,os,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/lifetimes/monitor-calibration';OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('verify',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
source=ROOT/'src/TurboTest.EFCore/Internal/TtCapacityMonitor.cs';original=source.read_text();assert original.count('_stop.Dispose();')==1
fault=OUT/'fault-TtCapacityMonitor.cs';text=original.replace('_stop.Dispose();',';');fault.write_text(text)
targets=OUT/'Fault.targets';compiled=OUT/'evaluated-compile-inputs.txt';build=OUT.parent/'calibration-build'
targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="Internal/TtCapacityMonitor.cs" /><Compile Include="{fault}" /></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{compiled}" Lines="@(Compile->'%(FullPath)')" Overwrite="true" /></Target></Project>''')
before=v.source_identity()
try:
 v.run_phase('fault217-build',['dotnet','build','tests/TurboTest.Tests/TurboTest.Tests.csproj','--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false','--verbosity','minimal'],OUT,120,os.environ)
 inputs=compiled.read_text().splitlines();assert str(fault) in inputs and str(source) not in inputs
 dll=build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
 v.write_json(OUT/'binding.json',{'sourceSha256':hashlib.sha256(original.encode()).hexdigest(),'faultSha256':hashlib.sha256(text.encode()).hexdigest(),'compiledInputs':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*')) if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
 try:v.run_phase('fault217-test',['dotnet','test',str(dll),'--filter','FullyQualifiedName~Repeated_stop_and_join_keep_cancellation_alive','--results-directory',str(OUT/'results'),'--logger','trx;LogFileName=results.trx'],OUT,30,os.environ)
 except v.VerificationError:pass
 receipt=json.loads((OUT/'fault217-test.json').read_text());assert receipt['exitCode']==1 and not receipt['deadlineExceeded']
 rows=E.parse(OUT/'results/results.trx').findall('.//{*}UnitTestResult');assert len(rows)==2 and all(r.get('outcome')=='Failed' for r in rows)
 errors=[{'test':r.get('testName'),'message':r.findtext('.//{*}Message')} for r in rows];assert all('Assert.True() Failure' in r['message'] for r in errors)
 v.write_json(OUT/'result.json',{'originalQuestion':'217','primaryInputsUnchanged':before==v.source_identity(),'namedFailures':errors,'qualification':'Bounded missing-disposal fault calibration. Original mutation report status unchanged; not a new full mutation run.'})
 print('fault217: both named rows reject missing handle release',flush=True)
finally:assert before==v.source_identity() and source.read_text()==original
