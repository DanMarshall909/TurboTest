"""Source-bound start-barrier calibration with finite callback reentry."""
from pathlib import Path
import hashlib,importlib.util,json,os,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/lifetimes/reentry-calibration';OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('verify',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
before=v.source_identity();build=OUT.parent/'calibration-build';fault=OUT/'fault.cs';targets=OUT/'Fault.targets';compiled=OUT/'evaluated-compile-inputs.txt'
variants={'2096':('TtLease.cs','Reentrant_return_observer_sees_the_published_pending_lease_drain_even_when_return_completes_inline'),'1691':('Internal/TtSlotPool.cs','Reentrant_deletion_observes_one_published_pending_drain_and_preserves_its_reservation')}
results=[]
try:
 for i,(relative,expected) in variants.items():
  source=ROOT/'src/TurboTest.EFCore'/relative;original=source.read_text();assert original.count('await start;')==1
  text=original.replace('await start;',';');fault.write_text(text);(OUT/(i+'-source.cs')).write_text(text)
  targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="{relative}" /><Compile Include="{fault}" /></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{compiled}" Lines="@(Compile->'%(FullPath)')" Overwrite="true" /></Target></Project>''')
  v.run_phase(i+'-build',['dotnet','build','tests/TurboTest.Tests/TurboTest.Tests.csproj','--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false','--verbosity','minimal'],OUT,120,os.environ)
  inputs=compiled.read_text().splitlines();assert str(fault) in inputs and str(source) not in inputs
  (OUT/(i+'-compile-inputs.txt')).write_text(compiled.read_text())
  dll=build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
  v.write_json(OUT/(i+'-binding.json'),{'source':str(source),'sourceSha256':hashlib.sha256(original.encode()).hexdigest(),'faultSha256':hashlib.sha256(text.encode()).hexdigest(),'removedStatement':'await start;','compiledInputs':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*')) if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
  try:v.run_phase(i+'-test',['dotnet','test',str(dll),'--filter','FullyQualifiedName~Reentrant_return_observer|FullyQualifiedName~Reentrant_deletion_observes','--results-directory',str(OUT/(i+'-results')),'--logger','trx;LogFileName=results.trx'],OUT,30,os.environ)
  except v.VerificationError:pass
  receipt=json.loads((OUT/(i+'-test.json')).read_text());assert receipt['exitCode']==1 and not receipt['deadlineExceeded']
  rows=E.parse(OUT/(i+'-results/results.trx')).findall('.//{*}UnitTestResult');assert len(rows)==2
  failed=[{'name':r.get('testName'),'message':r.findtext('.//{*}Message')} for r in rows if r.get('outcome')=='Failed']
  assert len(failed)==1 and failed[0]['name'].split('.')[-1]==expected and 'Assert.Equal() Failure' in failed[0]['message']
  results.append({'originalQuestion':i,'namedFailure':failed[0],'otherOwnerCasePassed':True});v.write_json(OUT/'progress.json',results)
  print(i,': named reentrant owner rejects repeated callback before task publication',flush=True)
finally:assert before==v.source_identity()
v.write_json(OUT/'result.json',{'primaryInputsUnchanged':True,'results':results,'qualification':'Bounded compiled barrier faults, not new original-report mutation statuses.2096models legitimate completed producer plus actual return-observer/logger responsibility; native public scheduling window is not deterministically reproduced.1691proves internal slot-owner/deletion-adapter law, not an established public-factory counterexample.'})
