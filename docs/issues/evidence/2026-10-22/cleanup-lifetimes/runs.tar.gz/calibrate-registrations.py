"""Distinguish effective pending unregistration from consumed callback self-unregistration."""
from pathlib import Path
import hashlib,importlib.util,json,os,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/lifetimes/registration-calibration';OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('verify',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
source=ROOT/'src/TurboTest.EFCore/Internal/TtSlotPool.cs';original=source.read_text();before=v.source_identity()
fault=OUT/'fault-TtSlotPool.cs';targets=OUT/'Fault.targets';compiled=OUT/'evaluated-compile-inputs.txt';build=OUT.parent/'calibration-build'
targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="Internal/TtSlotPool.cs" /><Compile Include="{fault}" /></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{compiled}" Lines="@(Compile->'%(FullPath)')" Overwrite="true" /></Target></Project>''')
variants={'1439':('Cancel','waiter.Cancellation.Unregister();',None),'1503':('FailWaiters','node.Value.Cancellation.Unregister();','Closed'),'1657':('PublishReady','waiter.Cancellation.Unregister();','Published')}
results=[]
try:
 for i,(method,statement,expectedCase) in variants.items():
  start=original.index('    private void '+method+'(');end=original.find('\n    private ',start+1)
  position=original.index(statement,start);assert end<0 or position<end
  text=original[:position]+original[position:].replace(statement,';',1);assert text!=original
  fault.write_text(text);(OUT/(i+'-source.cs')).write_text(text)
  v.run_phase(i+'-build',['dotnet','build','tests/TurboTest.Tests/TurboTest.Tests.csproj','--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false','--verbosity','minimal'],OUT,120,os.environ)
  inputs=compiled.read_text().splitlines();assert str(fault) in inputs and str(source) not in inputs
  (OUT/(i+'-compile-inputs.txt')).write_text(compiled.read_text())
  dll=build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
  v.write_json(OUT/(i+'-binding.json'),{'sourceSha256':hashlib.sha256(original.encode()).hexdigest(),'faultSha256':hashlib.sha256(text.encode()).hexdigest(),'method':method,'removedStatement':statement,'compiledInputs':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*')) if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
  try:v.run_phase(i+'-test',['dotnet','test',str(dll),'--filter','FullyQualifiedName~SlotRegistrationLifetimeTests','--results-directory',str(OUT/(i+'-results')),'--logger','trx;LogFileName=results.trx'],OUT,30,os.environ)
  except v.VerificationError:pass
  receipt=json.loads((OUT/(i+'-test.json')).read_text());assert not receipt['deadlineExceeded'] and receipt['exitCode']==(1 if expectedCase else 0)
  rows=E.parse(OUT/(i+'-results/results.trx')).findall('.//{*}UnitTestResult');assert len(rows)==3
  failed=[{'name':r.get('testName'),'message':r.findtext('.//{*}Message')} for r in rows if r.get('outcome')=='Failed']
  assert len(failed)==(1 if expectedCase else 0)
  if expectedCase:assert 'completion: "'+expectedCase+'"' in failed[0]['name'] and 'Assert.False() Failure' in failed[0]['message']
  else:assert all(r.get('outcome')=='Passed' for r in rows)
  results.append({'originalQuestion':i,'method':method,'expectedCase':expectedCase,'namedFailures':failed,'passed':3-len(failed)})
  v.write_json(OUT/'progress.json',results);print(i,': expected failures',len(failed),'passes',3-len(failed),flush=True)
finally:assert before==v.source_identity() and source.read_text()==original
v.write_json(OUT/'result.json',{'primaryInputsUnchanged':True,'results':results,'qualification':'Bounded compiled calibrations, not fresh whole-project mutation status.1439 stays green and requires independent pinned-runtime/call-graph reasoning;1503/1657 prove effective pending registration cleanup with live uncanceled caller CTS.'})
