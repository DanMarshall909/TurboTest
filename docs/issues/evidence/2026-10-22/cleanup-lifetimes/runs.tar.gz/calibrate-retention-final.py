"""Bounded retention fault checks with independently compiled source substitution."""
from pathlib import Path
import hashlib,importlib.util,json,os,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/lifetimes/retention-calibration-final';OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('verify',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
source=ROOT/'src/TurboTest.EFCore/TtCleanup.cs';original=source.read_text();before=v.source_identity()
fault=OUT/'fault-TtCleanup.cs';targets=OUT/'Fault.targets';compiled=OUT/'evaluated-compile-inputs.txt';build=OUT.parent/'calibration-build'
targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="TtCleanup.cs" /><Compile Include="{fault}" /></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{compiled}" Lines="@(Compile->'%(FullPath)')" Overwrite="true" /></Target></Project>''')
registry='Repeated_successful_recovery_releases_completed_handles_from_the_live_registry'
payload='Completed_capability_releases_callback_and_resource_payloads_while_the_handle_is_still_held'
composition='Completed_composition_releases_child_handles_while_the_parent_capability_is_still_held'
faults={'1884':('TtCleanupRegistry.Release(this);',{registry}),'callback':('_cleanup = null;',{payload,composition}),'resources':('_resources = null;',{payload,composition}),'members':('_members = null;',{composition})}
results=[]
try:
 for name,(statement,expected) in faults.items():
  assert original.count(statement)==1;text=original.replace(statement,';');fault.write_text(text);(OUT/(name+'-source.cs')).write_text(text)
  v.run_phase(name+'-build',['dotnet','build','tests/TurboTest.Tests/TurboTest.Tests.csproj','--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false','--verbosity','minimal'],OUT,120,os.environ)
  inputs=compiled.read_text().splitlines();assert str(fault) in inputs and str(source) not in inputs
  (OUT/(name+'-compile-inputs.txt')).write_text(compiled.read_text())
  dll=build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
  v.write_json(OUT/(name+'-binding.json'),{'sourceSha256':hashlib.sha256(original.encode()).hexdigest(),'faultSha256':hashlib.sha256(text.encode()).hexdigest(),'removedStatement':statement,'compiledInputs':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*')) if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
  try:v.run_phase(name+'-test',['dotnet','test',str(dll),'--filter','FullyQualifiedName~CleanupRetentionTests','--results-directory',str(OUT/(name+'-results')),'--logger','trx;LogFileName=results.trx'],OUT,30,os.environ)
  except v.VerificationError:pass
  receipt=json.loads((OUT/(name+'-test.json')).read_text());assert receipt['exitCode']==1 and not receipt['deadlineExceeded']
  rows=E.parse(OUT/(name+'-results/results.trx')).findall('.//{*}UnitTestResult');assert len(rows)==3
  failed=[{'name':r.get('testName'),'message':r.findtext('.//{*}Message')} for r in rows if r.get('outcome')=='Failed']
  assert {r['name'].split('.')[-1] for r in failed}==expected
  assert all('Assert.False() Failure' in r['message'] for r in failed)
  results.append({'fault':name,'namedFailures':failed});v.write_json(OUT/'progress.json',results)
  print(name,': exact expected retained-reference failures',len(failed),flush=True)
finally:assert before==v.source_identity() and source.read_text()==original
v.write_json(OUT/'result.json',{'primaryInputsUnchanged':True,'results':results,'qualification':'Four bounded compiled fault calibrations. Only1884 maps to an original question; other faults check current callback/resource/member release promises. Original mutation report statuses unchanged; no full mutation run claimed.'})
