# Next TT-024 / TT-023 criterion

Read-only independent investigation by `/root/tt024_pg_drop_trace` on the current
factory source. No execution proof or removal approval is claimed.

## Dominated fallback versus ownership root

The drain fallback appears empty under actual fresh-wrapper pool producers:
close locks admission/publication, waits admitted acquisitions, then joins all
remaining published leases. Failed/unpublished acquisitions await discard and
remove their database even if discard fails before signalling settlement. Lease
return removes its database before removing the lease. Therefore each database
has already been removed before the final fallback enumeration.

The `_databases` field can still serve a different lifetime role. A public
canceled-after-configuration acquisition registers its context, then awaits the
context's virtual asynchronous disposal during discard. If the caller drops its
task and the context awaits a context-owned TCS held externally only weakly,
the field roots database -> disposal callback -> context -> gate/continuations.
The acquisition ledger contains a separate settled TCS, with no reverse link to
the real acquisition task/context. The slot pool roots its data source rather
than the context. This is a candidate public counterexample to field removal,
not yet an executed proof.

Proposed next criterion: a no-inline helper starts that real acquisition and
returns only weak references to its task, context and disposal gate. An
independent Entered signal proves actual cleanup is held. Keep the factory
strongly alive, force bounded collection, assert the cleanup graph remains
reachable, reacquire/release the gate and join actual acquisition and drain.
Calibrate deletion of the field/add/remove bookkeeping separately from removal
of the dominated fallback body. Preserve physical reservation/error outcomes;
do not use private collection emptiness as the oracle.

Completed acquisition-node and maintenance-node release are different contracts:
the public task/context can collect even when a bare settlement TCS remains in
the ledger. Capture the actual existing node only if needed for bounded weak
reference evidence, with independent successful work/resource outcomes.

For TT-023, add the exact ordering canceled maintenance observer -> actual pool
operation failure settled -> factory drain starts. Current maintenance tests
start drain while the actual deletion is still held. Reuse the real slot ledger
and exact deletion/error oracle; do not replace it with a fake ownership model.
