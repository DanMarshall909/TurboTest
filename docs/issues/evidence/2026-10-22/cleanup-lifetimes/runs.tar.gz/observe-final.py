"""One-off full canonical gate with safe external PostgreSQL wait samples."""
from pathlib import Path
import datetime,importlib.util,json,os,re,subprocess,threading,time
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/lifetimes'
GATE=ROOT/'artifacts/tt-024/lifetimes/final-all'
assert not GATE.exists()
D=['docker','--host','unix:///var/run/docker.sock'];stop=threading.Event()
query="""SET statement_timeout=1500;
SELECT clock_timestamp(),pid,backend_type,datname,state,query_start,
coalesce(wait_event_type,''),coalesce(wait_event,''),
CASE WHEN query ILIKE 'DROP DATABASE%' THEN 'DropDatabase'
WHEN query ILIKE 'CREATE DATABASE%' THEN 'CreateDatabase'
WHEN query ILIKE 'SET statement_timeout%' THEN 'DiagnosticObserver' ELSE 'Other' END,
pg_blocking_pids(pid)::text FROM pg_stat_activity ORDER BY pid;"""
def run(args):return subprocess.run(D+args,capture_output=True,text=True,timeout=4)
def inventory():
    r=run(['ps','--no-trunc','--filter','label=turbotest.reservation','--format','{{.ID}}'])
    return r.stdout.split() if r.returncode==0 else []
baseline=set(inventory()); seen={}
def write(row):
    with (OUT/'lifetime-final-server.jsonl').open('a') as f:f.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**row})+'\n')
def observe():
    while not stop.wait(3):
        try:
            for cid in set(inventory())-baseline:
                first=seen.setdefault(cid,time.monotonic())
                if time.monotonic()-first<12:continue
                activity=run(['exec',cid,'sh','-c','exec psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -A -t -F "|" -c "$1"','diagnostic',query])
                logs=run(['logs','--since','4s',cid])
                barriers=re.findall(r'still waiting for backend with PID [0-9]+ to accept ProcSignalBarrier',logs.stdout+'\n'+logs.stderr)
                write({'containerId':cid,'activityExit':activity.returncode,'activity':activity.stdout.splitlines() if activity.returncode==0 else [],'barrierMessages':barriers,'stderrRetained':False})
        except subprocess.TimeoutExpired:write({'observer':'deadline','seconds':4})
        except Exception as error:write({'observer':'unavailable','kind':type(error).__name__})
(OUT/'lifetime-final-observer-identity.json').write_text(json.dumps({'canonicalCommand':['python3','scripts/verify.py','all','--output',str(GATE)],'baselineRunningIds':sorted(baseline),'observation':'External read-only psql client on newly observed labelled containers after 12s. Does not alter owning admin connection limits. Adds an external diagnostic connection; not a performance or admin budget proof. No raw queries, private errors or passwords logged.'},indent=2)+'\n')
thread=threading.Thread(target=observe,daemon=True);thread.start()
try:
    with (OUT/'lifetime-final-driver.log').open('w') as log:
        result=subprocess.run(['python3','scripts/verify.py','all','--output',str(GATE)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
finally:stop.set();thread.join(12)
assert not thread.is_alive()
print('canonical gate exit',result.returncode,flush=True)
print((GATE/'verification.json').read_text(),flush=True)
