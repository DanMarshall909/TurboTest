"""One-off native cohort with a bounded, read-only server observer after a stall."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys,threading,time,uuid
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/adaptive-diagnostic'
spec=importlib.util.spec_from_file_location('verify',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
name=sys.argv[1];assert name.startswith('cohort-') and name.replace('-','').isalnum()
variant=sys.argv[2] if len(sys.argv)>2 else '3';assert variant in ('2','3')
assert not (OUT/(name+'.json')).exists() and not (OUT/(name+'.phases.jsonl')).exists()
binary=Path('/tmp/tt024-adaptive-diagnostic-build/bin/TurboTest.Tests/release/TurboTest.Tests.dll')
variant_source=OUT/f'variants/probe-{variant}.cs'
assert variant_source.read_bytes()==(OUT/'NativeAdaptiveProbeTests.cs').read_bytes()
compiled_name=name+'-compiled-inputs.json'
v.write_json(OUT/compiled_name,{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(binary.parent.rglob('*')) if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))})
prefix='tt024-drop-observe-'+uuid.uuid4().hex
trace=OUT/(name+'.phases.jsonl');observations=OUT/(name+'.server.jsonl')
env={**os.environ,'DOCKER_HOST':'unix:///var/run/docker.sock','TT024_ADAPTIVE_PREFIX':prefix,'TT024_ADAPTIVE_TRACE':str(trace)}
D=['docker','--host','unix:///var/run/docker.sock']
query="""SET statement_timeout=2000;
SELECT pid,datname,state,coalesce(wait_event_type,''),coalesce(wait_event,''),
CASE WHEN query ILIKE 'DROP DATABASE%' THEN 'DropDatabase'
WHEN query ILIKE 'SELECT datistemplate%' THEN 'TemplateCheck'
WHEN query ILIKE 'CREATE DATABASE%' THEN 'CreateDatabase'
WHEN query ILIKE 'SET statement_timeout%' THEN 'DiagnosticObserver'
ELSE 'Other' END,pg_blocking_pids(pid)::text
FROM pg_stat_activity WHERE backend_type='client backend' ORDER BY pid;"""
stop=threading.Event()
def save_observation(row):
    with observations.open('a') as f:f.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**row})+'\n')
def observe():
    pending_since=None
    while not stop.wait(2):
        if not trace.exists():continue
        rows=[]
        for line in trace.read_text().splitlines():
            try:rows.append(json.loads(line)['row'])
            except (json.JSONDecodeError,KeyError):pass
        pending=bool(rows and any(row['phase'].endswith('.pending') for row in rows[-5:]))
        if not pending:pending_since=None;continue
        if pending_since is None:pending_since=time.monotonic()
        if time.monotonic()-pending_since<5:continue
        try:
            found=subprocess.run(D+['ps','--all','--no-trunc','--filter','label=turbotest.reservation','--filter','name='+prefix,'--format','{{.ID}}'],capture_output=True,text=True,timeout=5)
            ids=found.stdout.split()
            for cid in ids:
                state=subprocess.run(D+['inspect','--format','{{.State.Status}}|{{.State.OOMKilled}}|{{.State.ExitCode}}',cid],capture_output=True,text=True,timeout=5)
                # The server's existing account name is expanded only inside its
                # own container. No password or arbitrary query text is logged.
                activity=subprocess.run(D+['exec',cid,'sh','-c','exec psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -A -t -F "|" -c "$1"','diagnostic',query],capture_output=True,text=True,timeout=5)
                save_observation({'containerId':cid,'state':state.stdout.strip(),'activityExit':activity.returncode,'activity':activity.stdout.splitlines() if activity.returncode==0 else [],'stderrRetained':False})
        except subprocess.TimeoutExpired:save_observation({'observer':'deadline','seconds':5})
        except Exception as error:save_observation({'observer':'unavailable','kind':type(error).__name__})

v.write_json(OUT/(name+'-identity.json'),{'prefix':prefix,'trace':str(trace),'variant':str(variant_source.relative_to(OUT)),'sourceSha256':hashlib.sha256(variant_source.read_bytes()).hexdigest(),'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'compiledInputs':compiled_name,'observer':'After5s of already-recorded pending teardown only; adds one external read-only diagnostic client, not owning-admin-budget evidence.2s SQL and5s process deadlines. No private messages, passwords or query payloads logged.'})
assert not v.docker_inventory(OUT,name+'-before',env)
before=v.source_identity();thread=threading.Thread(target=observe,daemon=True);thread.start()
try:
    v.run_phase(name,['dotnet','test',str(binary),'--filter','FullyQualifiedName~NativeAdaptiveProbeTests.Diagnostic_public_adaptive_lifecycle|FullyQualifiedName~Returning_a_prepared_lease_inside_an_ambient_transaction_restores_it_without_retaining_private_sessions|FullyQualifiedName~User_workload_changes_still_roll_back_with_the_callers_ambient_transaction','--results-directory',str(OUT/(name+'-results')),'--logger','trx;LogFileName=results.trx','--logger','console;verbosity=normal'],OUT,180,env)
except v.VerificationError as error:print(type(error).__name__,str(error),flush=True)
finally:
    stop.set();thread.join(12)
    assert not thread.is_alive(),'Observer did not settle'
    assert before==v.source_identity(),'Primary compiler inputs changed'
    after=v.docker_inventory(OUT,name+'-after',env)
    print('remaining labelled IDs',sorted(after),flush=True)
print((OUT/(name+'.log')).read_text()[-2500:],flush=True)
