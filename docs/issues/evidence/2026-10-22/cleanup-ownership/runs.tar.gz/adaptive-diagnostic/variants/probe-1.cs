using Microsoft.EntityFrameworkCore;
using Npgsql;
using TurboTest.EFCore;
using TurboTest.EFCore.Internal;
using Microsoft.Extensions.Logging;
using System.Text.Json;
namespace TurboTest.Tests;
[Collection("Static lifecycle")]
public class NativeAdaptiveProbeTests
{
    [Fact]
    [Trait("Category", "PostgreSQL")]
    public async Task Diagnostic_public_adaptive_lifecycle()
    {
        var fixture = await Tt.CreateFactoryAsync(
            new TtBaselineDefinition<TestDbContext>("adaptive-public-v1", TtSchemaInitialization.EnsureCreated,
                async (context, token) =>
                {
                    context.Users.Add(new User { Email = "adaptive-seed@example.test" });
                    await context.SaveChangesAsync(token);
                }), options =>
            {
                options.PoolSize = 8;
                options.ContainerPrefix = Prefix;
                options.Logger = new ProbeLogger();
                options.StartupWarmDatabases = 1;
                options.MemoryLimitMb = 512;
                options.EnableDynamicScaling = true;
                options.AdaptivePool = new()
                {
                    MinimumWarmDatabases = 1, MaximumWarmDatabases = 8,
                    GrowthStabilization = TimeSpan.FromMilliseconds(100),
                    ShrinkStabilization = TimeSpan.FromMilliseconds(300),
                    Cooldown = TimeSpan.Zero, CheckInterval = TimeSpan.FromMilliseconds(20)
                };
            });
        Phase("fixture.created", fixture);
        try
        {
            Assert.Equal((8, 1, 1, 1), (fixture.PoolState.SlotLimit, fixture.PoolState.Reserved,
                fixture.PoolState.Ready, fixture.PoolState.WarmTarget));
            var leases = new List<TtLease<TestDbContext>>();
            using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(45));
            Task<TtLease<TestDbContext>>[] acquiring = [];
            try
            {
                leases.Add(await fixture.CreateLeaseAsync(cancellationToken: deadline.Token));
                acquiring = Enumerable.Range(0, 7).Select(_ => fixture.CreateLeaseAsync(cancellationToken: deadline.Token)).ToArray();
                leases.AddRange(await Task.WhenAll(acquiring));
                Phase("eight.acquired", fixture);
                Assert.Equal((8, 8, 8), (fixture.PoolState.WarmTarget, fixture.PoolState.Reserved, fixture.PoolState.Leased));
                var original = new Dictionary<string, uint>();
                for (var i = 0; i < leases.Count; i++)
                {
                    var identity = await PooledResetTests.ReadIdentityAsync(leases[i].Context);
                    original.Add(identity.Database, identity.Oid);
                    Assert.Equal("adaptive-seed@example.test", (await leases[i].Context.Users.SingleAsync()).Email);
                    leases[i].Context.Users.Add(new User { Email = $"private-marker-{i}@example.test" });
                    await leases[i].Context.SaveChangesAsync();
                }
                for (var i = 1; i < leases.Count; i++) await leases[i].DisposeAsync();
                await UntilAsync(() => fixture.PoolState.WarmTarget == 1 && fixture.PoolState.Parked == 7);
                Assert.Equal((1, 0, 8), (fixture.PoolState.Leased, fixture.PoolState.Ready, fixture.PoolState.Reserved));
                await leases[0].DisposeAsync();
                leases.Clear();
                await UntilAsync(() => fixture.PoolState.Ready == 1);
                acquiring = Enumerable.Range(0, 8).Select(_ => fixture.CreateLeaseAsync(cancellationToken: deadline.Token)).ToArray();
                leases.AddRange(await Task.WhenAll(acquiring));
                Phase("eight.acquired", fixture);
                var renewed = new Dictionary<string, uint>();
                foreach (var lease in leases)
                {
                    var identity = await PooledResetTests.ReadIdentityAsync(lease.Context);
                    renewed.Add(identity.Database, identity.Oid);
                    Assert.Equal("adaptive-seed@example.test", (await lease.Context.Users.SingleAsync()).Email);
                    lease.Context.Users.Add(new User { Email = "renewed-marker@example.test" });
                    await lease.Context.SaveChangesAsync();
                    Assert.Equal(2, await lease.Context.Users.MaxAsync(user => user.Id));
                }
                Phase("renewed.identities.read", fixture);
                Assert.Equal(original.OrderBy(pair => pair.Key), renewed.OrderBy(pair => pair.Key));
                Assert.Equal((8, 8, 0), (fixture.PoolState.WarmTarget, fixture.PoolState.Leased, fixture.PoolState.Parked));
            }
            catch (Exception error)
            {
                Phase("body.failure", fixture, error);
                throw;
            }
            finally
            {
                Phase("lease.cleanup.start", fixture);
                deadline.Cancel();
                foreach (var task in acquiring)
                    await Record.ExceptionAsync(async () => { await using var lease = await task; });
                foreach (var lease in leases) await lease.DisposeAsync();
            }
            Phase("explicit.close.start", fixture);
            await fixture.DisposeAsync();
            Phase("explicit.close.complete", fixture);
            Assert.Equal(0, fixture.PoolState.Reserved);
            Assert.Empty(fixture.OwnedResourceIds);
            await Assert.ThrowsAsync<ObjectDisposedException>(() => fixture.CreateLeaseAsync());
    
            async Task UntilAsync(Func<bool> condition)
            {
                while (!condition())
                {
                    Assert.InRange(fixture.PoolState.Reserved, 1, 8);
                    Assert.InRange(fixture.PoolState.WarmTarget, 1, 8);
                    await Task.Delay(20, deadline.Token);
                }
            }
        }
        catch (Exception error)
        {
            Phase("scenario.failure", fixture, error);
            throw;
        }
        finally
        {
            Phase("final.close.start", fixture);
            var failure = await Record.ExceptionAsync(() => fixture.DisposeAsync().AsTask());
            Phase("final.close.observed", fixture, failure);
            var cleanup = (failure as TtLifecycleException)?.Cleanup;
            if (cleanup is not null)
            {
                for (var attempt = 1; attempt <= 3; attempt++)
                {
                    Write(new { phase = "recovery.start", attempt, cleanup.OwnerId, resources = cleanup.OwnedResourceIds });
                    var recovery = await Record.ExceptionAsync(() => cleanup.RetryCleanupAsync());
                    Phase("recovery.observed", fixture, recovery);
                    if (recovery is null) break;
                }
            }
            Phase("final.resources", fixture);
        }
    }

    private static readonly object TraceGate = new();
    private static string Prefix => Environment.GetEnvironmentVariable("TT024_ADAPTIVE_PREFIX") ?? "tt024-adaptive-diagnostic";
    private static void Phase(string phase, TtFactory<TestDbContext> fixture, Exception? error = null) =>
        Write(new { phase, state = fixture.PoolState, resources = fixture.OwnedResourceIds,
            error = error is null ? null : new { kind = error.GetType().FullName,
                stage = (error as TtLifecycleException)?.Stage, sqlState = (error as TtLifecycleException)?.SqlState,
                safeMessage = error is TtLifecycleException safe ? safe.Message : null, stack = error.StackTrace } });
    private static void Write(object row)
    {
        var path = Environment.GetEnvironmentVariable("TT024_ADAPTIVE_TRACE") ?? throw new InvalidOperationException("Diagnostic trace path missing.");
        var line = JsonSerializer.Serialize(new { utc = DateTime.UtcNow, row });
        lock (TraceGate) File.AppendAllText(path, line + "\n");
    }
    private sealed class ProbeLogger : ILogger
    {
        public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;
        public bool IsEnabled(LogLevel level) => true;
        public void Log<TState>(LogLevel level, EventId id, TState state, Exception? error, Func<TState, Exception?, string> format)
        {
            var allowed = new HashSet<string>(StringComparer.Ordinal) { "OwnerId", "Operation", "DurationMilliseconds", "Succeeded", "Outcome", "Reason", "ContainerId", "ContainerName", "PoolId" };
            var fields = (state as IEnumerable<KeyValuePair<string, object?>> ?? [])
                .Where(pair => allowed.Contains(pair.Key)).ToDictionary(pair => pair.Key, pair => pair.Value);
            Write(new { phase = "logger", eventId = id.Id, fields });
        }
    }
}
