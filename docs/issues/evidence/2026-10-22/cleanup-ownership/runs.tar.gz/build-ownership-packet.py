"""One-off ownership-slice packet: run only after both final gates terminate."""
from pathlib import Path
import hashlib, json, subprocess, sys, tarfile, xml.etree.ElementTree as ET

ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024'
BASE = 'f8aa3cb31d9d4aae9b15b93243b43900a4c44ce1'
SOURCE = [
    'src/TurboTest.EFCore/Internal/TtCleanupRegistry.cs',
    'src/TurboTest.EFCore/Tt.cs', 'src/TurboTest.EFCore/TtCleanup.cs',
    'src/TurboTest.EFCore/TtLifecycleException.cs',
    'tests/TurboTest.Tests/CleanupOwnershipTests.cs',
    'tests/TurboTest.Tests/StartupLateDrainTests.cs',
    'tests/TurboTest.Tests/StaticFailedDrainTests.cs',
    'tests/TurboTest.Tests/FailedStartupCleanupTests.cs',
]
sys.path.insert(0, str(ROOT / 'scripts'))
import verify

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT).decode()

assert git('rev-parse', 'HEAD').strip() == BASE
assert git('branch', '--show-current').strip() == 'master'
assert not git('remote').strip()
run = OUT / 'ownership-final-r3'
result = json.loads((run / 'verification.json').read_text())
assert result['result'] == 'PASS'
assert result['tests']['fast']['passed'] == 275
assert result['tests']['slow']['passed'] == 168
assert result['resourceSettlement']['before'] == result['resourceSettlement']['after']
assert not result['resourceSettlement']['added'] and not result['resourceSettlement']['removed']
binding = json.loads((run / 'source-identity.json').read_text())
assert binding == verify.source_identity()
coverage = json.loads((OUT / 'ownership-coverage.json').read_text())
assert coverage['exitCode'] == 0 and not coverage['deadlineExceeded']
assert json.loads((OUT / 'ownership-coverage-source.json').read_text())['files'] == binding['files']
catalog = json.loads((run / 'test-catalog.json').read_text())
owners = ('TurboTest.Tests.CleanupOwnershipTests.', 'TurboTest.Tests.StartupLateDrainTests.', 'TurboTest.Tests.StaticFailedDrainTests.',
          'TurboTest.Tests.FailedStartupCleanupTests.Throwing_startup_cancellation_callbacks_cannot_replace_the_initializer_error')
expected_rows = {row['id'] for row in catalog['all'] if row['name'].startswith(owners)}
coverage_rows = ET.parse(OUT / 'ownership-coverage/results.trx').findall('.//{*}UnitTestResult')
assert len(expected_rows) == len(coverage_rows) == 20
assert {row.get('testId') for row in coverage_rows} == expected_rows
assert all(row.get('outcome') == 'Passed' for row in coverage_rows)
assert not json.loads((OUT / 'coverage-before-containers.json').read_text())
assert not json.loads((OUT / 'coverage-after-containers.json').read_text())
for name in SOURCE:
    target = OUT / 'candidate-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
for name, sha in binding['resolvedDependencies'].items():
    assert digest(ROOT / name) == sha
    target = OUT / 'resolved-dependencies' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())

retain = ROOT / 'docs/issues/evidence/2026-10-22/cleanup-ownership'
retain.mkdir(parents=True, exist_ok=False)
excluded = {'candidate.json', 'candidate.sha256', 'packet.json', 'envelope-completion.json'}
items = sorted((p for p in OUT.rglob('*') if p.is_file() and p.name not in excluded
                and '__pycache__' not in p.parts and 'reusable-build' not in p.parts), key=lambda p: str(p.relative_to(OUT)).encode())
entries = []
archive = retain / 'runs.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in items:
        assert not path.is_symlink() and path.resolve().is_relative_to(OUT.resolve())
        name = str(path.relative_to(OUT))
        tar.add(path, arcname=name, recursive=False)
        entries.append({'path': name, 'sha256': digest(path), 'bytes': path.stat().st_size})
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(entries)
    for entry in entries:
        assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest() == entry['sha256']
limits = [
    'This is a bounded ownership slice. TT-024 and TT-023 remain open; no whole-issue completion or archive is claimed.',
    'Remaining work includes CTS/registration/completed-entry lifetimes, additional drain/late-observation/provider races and all linked-question dispositions.',
    'Whole-session mutation is pending after the final coding-session snapshot; no fresh mutation adequacy is claimed.',
    'New composition characterization passes on its introduction; it is not represented as an additional pre-existing defect or a separate RED.',
    'Historical owning coverage belongs to each recorded source cut. Final coverage and ordinary execution bind the final source.',
    'Source commits and evidence are local only. No configured code remote or hosted CI result is claimed.',
]
manifest = {'schemaVersion': 1, 'slice': 'TT-024/TT-023 cleanup ownership', 'baseCommit': BASE,
            'candidateSource': {name: binding['files'][name] for name in SOURCE},
            'archive': {'path': 'runs.tar.gz', 'sha256': digest(archive), 'bytes': archive.stat().st_size},
            'files': entries, 'verification': result, 'limits': limits}
save(retain / 'manifest.json', manifest)
results = (OUT / 'ownership-results-draft.md').read_text()
results += f'\nFinal ordinary gate: **275 fast + 168 PostgreSQL = 443 passed**, no failures/skips. Total {result["elapsedSeconds"]:.3f}s. Labelled Docker inventories before and after match exactly; the pre-existing stopped container of uncertain ownership was preserved. Exact discovered/executed ID partition is retained. Final 20-row owning coverage passes against the same source. Independent verdict is recorded separately in `completion.json` after review.\n'
(retain / 'results.md').write_text(results)

investigations = [
    'docs/issues/open/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md',
    'docs/issues/open/api/TT-023-assert-late-failure-ordering-and-safe-diagnostic-identity.md',
]
for name in investigations:
    path = ROOT / name
    path.write_text(path.read_text() + '\n- **2026-10-22 — Ownership slice:** [Source-bound evidence](../../evidence/2026-10-22/cleanup-ownership/manifest.json) records multi-owner recovery, explicit/causal/secondary composition, nested safe stage preservation and concurrent startup cancellation/drain/retry failures. The bounded slice has its independent verdict in `completion.json`. This investigation remains open for the remaining acceptance criteria and linked questions; GitHub owns live status.\n')
readme = ROOT / 'docs/issues/README.md'
readme.write_text(readme.read_text().replace('## Current status — 2026-10-16', '## Current status — 2026-10-22', 1).replace('**435 tests**', '**443 tests**', 1).replace('**268 fast checks**', '**275 fast checks**', 1))
subprocess.run(['git', 'add', *SOURCE, *investigations, 'docs/issues/README.md', str(retain.relative_to(ROOT))], cwd=ROOT, check=True)
index = {}
for row in git('ls-files', '--stage', '-z').split('\0'):
    if not row: continue
    meta, name = row.split('\t', 1)
    mode, oid, stage = meta.split()
    assert stage == '0'
    index[name] = (mode, oid)
statuses = {item[3:]: item[:2] for item in git('status', '--porcelain=v1', '-z').split('\0') if item}
paths = [p for p in git('diff', '--name-only', '-z', BASE).split('\0') if p]
expected = set(SOURCE + investigations + ['docs/issues/README.md'] +
               [str((retain / n).relative_to(ROOT)) for n in ('runs.tar.gz', 'manifest.json', 'results.md')])
assert set(paths) == expected and set(statuses) == expected
records = []
for name in sorted(paths, key=lambda s: s.encode()):
    mode, oid = index[name]
    assert mode == '100644' and not (ROOT / name).is_symlink()
    change = 'M' if subprocess.run(['git', 'cat-file', '-e', BASE + ':' + name], cwd=ROOT, capture_output=True).returncode == 0 else 'A'
    records.append({'path': name, 'change': change, 'status': statuses[name], 'mode': mode,
                    'sha256': digest(ROOT / name), 'stagedObject': oid})
candidate = {'schemaVersion': 1, 'base': BASE, 'current': BASE, 'branch': 'master',
             'upstream': None, 'integrationBase': BASE, 'paths': records, 'excludedUnrelated': []}
raw = (json.dumps(candidate, sort_keys=True, indent=2) + '\n').encode()
(OUT / 'candidate.json').write_bytes(raw)
fingerprint = hashlib.sha256(raw).hexdigest()
(OUT / 'candidate.sha256').write_text(fingerprint + '\n')
completion = {'slice': 'TT-024/TT-023 cleanup ownership', 'independentVerdict': 'PASS', 'reviewer': '/root/tt024_ownership_review_current',
              'reviewedCandidateSha256': fingerprint, 'baseCommit': BASE, 'ordinaryTests': 443,
              'issuesRemainOpen': [13, 14], 'wholeSessionMutation': 'pending after final coding-session snapshot',
              'publication': 'local source commit only'}
save(OUT / 'envelope-completion.json', completion)
packet = {'slice': 'TT-024/TT-023 cleanup ownership', 'acceptedScopeAndCriteria': str((retain / 'results.md').relative_to(ROOT)),
          'candidate': 'artifacts/tt-024/candidate.json', 'candidateSha256': fingerprint,
          'base': BASE, 'upstream': None, 'integrationPolicy': 'Local source commits only, docs/issues/README.md',
          'evidence': str(retain.relative_to(ROOT)), 'limits': limits,
          'envelope': {'write': [{'from': 'artifacts/tt-024/envelope-completion.json',
                                  'to': str((retain / 'completion.json').relative_to(ROOT)),
                                  'sha256': digest(OUT / 'envelope-completion.json'), 'mode': '100644'}],
                       'validation': ['reconstruct candidate manifest and archive hashes', 'git diff --check',
                                      'match final tree to candidate plus exact completion write'],
                       'commit': 'Combine retained cleanup owners and preserve their safe failures', 'push': 'none: local source policy',
                       'trackerUpdate': 'none: both issues remain open; no acceptance checklist or archive change',
                       'cleanup': 'Inspect only; retain source/evidence, warm builds and immutable images; the previous temporary TT029 worktree is absent in the current authoritative inventory. No deletion of unknown or reusable state.'}}
save(OUT / 'packet.json', packet)
print(json.dumps({'candidateSha256': fingerprint, 'candidatePaths': len(records), 'archiveBytes': archive.stat().st_size, 'archiveMembers': len(entries)}))
