# Remaining ownership work after bounded slice

Both GitHub issues13/14 remain open. Do not treat this capsule as a new tracker.

## TT024
- CTS lifetime: captured initializer/monitor token WaitHandle stays usable while actual initialization, reader and cancellation callbacks are separately gated; getter throws ObjectDisposedException only after actual settlement. Cover successful initialization and interruption; provider2218 shutdown token is private observer-only, not baseline seed token. Preserve public observability limitation.
- Registry1884: WeakReference of completed cleanup handle returned from no-inline helper must collect with static registry alive. Callback payload collection alone misses a leaked empty handle.
- Registration1657/1503: acquire with long-lived uncanceled caller CTS, publish or fail queued waiter, dispose actual pool, then no-inline WeakReference(pool) should collect while caller CTS stays alive. Do not cancel caller before assertion.1439 callback unregister may be redundant after cancellation runtime consumes callback; calibrate before equivalence claim.
- Completed factory work: public returned Tasks are not the stored TCS nodes. Existing-node weak probes may be necessary; do not mistake public task/context collection for exact node release. Keep factory alive through collection.
- Dominated _databases1941/2065/2067/2068/2069: admission registers acquisition barrier before database; failures/disallowed publication await discard before settlement; published lease returns database before removing lease, including failure; factory closes admission, joins acquisitions then existing leases. Extra database fallback has no supported reachable work. Before removal assert gated concurrent return/drain success/failure and unpublished acquisition settlement, then refactor while green.
- Internal domains: prepared pools supply both park/rewarm; ordinary pools have neither adaptive nor parking. Do not invent public optional-callback combinations.263 standalone Evaluate can start its own stabilization window unless explicitly rejected contract.1202 held target can currently leave post-discard warm deficit unreplenished; define held ticks before mutation classification.1208/1211 can retire expired parked items on HELD ticks if shrink conditional widened, a real production-callback distinction.1265 arithmetic differs with warm commitments above target; absent-park adaptive callback combination currently creates that internal state.1372/1373 caller guard dominance needs bounded argument;1374 parking-only internal ledger can attempt null rewarm under fault.
- Direct slot drain and lease start barriers need gated reentry probes; awaiting a job from its own callback is a cyclic dependency, distinct from retrieving/shared-observing pending ownership.
- Exact48 linked IDs stay undisposed until evidence/accepted bounded decision/narrow tracked item, not broad equivalence labels. Agent inventory in conversation supplies complete ID/source map.

## Coordinated TT023 and future tickets
- Registry observation timeout can let actual cleanup fail late then get replaced on next Retry before diagnostic is delivered. Define delivery bookkeeping and prove gated timeout -> actual failure -> later drain sequence.
- Factory/provider retained wrapper callbacks can early-throw from retry before including delayed diagnostics; retain all meaningful failures in available recovery response and acknowledge only included records.
- Provider AwaitCleanupAsync filters DrainTimeout entries when material errors exist. Do NOT assume physical capability loss: DrainOwnerAsync retains each failure.Cleanup in provider _cleanup; startup entries already came from that collection; provider retained wrapper retries all of it. Determine whether this wrapper dominates the filtered capabilities before claiming a bug. Diagnostic/deadline distinctions still require a real distinct-owner scenario and accepted contract.
- Maintenance observer canceled -> actual failure completes -> drain starts is not established by existing drain-before-release scenarios. Need precise actual-work completion gate.
- Repeated monitor Stop/Join with blocking/throwing cancellation callbacks and once-only material errors.

## Operational state
- Original full ownership-final gate is terminal FAIL (166/168 native); source-bound isolation controls passed. Repaired full r2 gate must pass before packet/review. Poll its exact live handle when launched; never restart on observation timeout.
- No normal full mutation launched. Whole-session mutation waits for final coding snapshot.
- One-off build-ownership-packet.py asserts full443=275+168 gate + source binding + final20-owning coverage + empty resource inventories. Do not run before those receipts exist.
- Independent reviewer /root/tt024_ownership_review is read-only, preliminary no findings, awaiting final exact packet. Do not self-approve.
