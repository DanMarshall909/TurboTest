"""Create a one-off native diagnostic test in separate build output, no source edits."""
from pathlib import Path
import hashlib,json,xml.sax.saxutils
ROOT=Path('/home/dan/code/TurboTest')
OUT=ROOT/'artifacts/tt-024/adaptive-diagnostic'
OUT.mkdir(exist_ok=False)
source=ROOT/'tests/TurboTest.Tests/PreparedAdaptiveTests.cs'
text=source.read_text()
start=text.index('    public async Task Public_adaptive_fixture_grows_one_to_eight_parks_to_one_and_reuses_all_eight_after_idle()')
method=text[start:text.rfind('\n}')].rstrip()
method=method.replace('Public_adaptive_fixture_grows_one_to_eight_parks_to_one_and_reuses_all_eight_after_idle', 'Diagnostic_public_adaptive_lifecycle',1)
method=method.replace('await using var fixture =', 'var fixture =',1)
needle='                options.PoolSize = 8;'
assert method.count(needle)==1
method=method.replace(needle,needle+'\n                options.ContainerPrefix = Prefix;\n                options.Logger = new ProbeLogger();',1)
split=method.index('        Assert.Equal((8, 1, 1, 1)')
setup,body=method[:split],method[split:]
assert body.endswith('    }')
body=body[:-5].rstrip()
needle='        finally\n        {\n            deadline.Cancel();'
assert body.count(needle)==1
body=body.replace(needle,'''        catch (Exception error)
        {
            Phase("body.failure", fixture, error);
            throw;
        }
        finally
        {
            Phase("lease.cleanup.start", fixture);
            deadline.Cancel();''',1)
body=body.replace('        await fixture.DisposeAsync();','        Phase("explicit.close.start", fixture);\n        await fixture.DisposeAsync();\n        Phase("explicit.close.complete", fixture);',1)
body=body.replace('            leases.AddRange(await Task.WhenAll(acquiring));','            leases.AddRange(await Task.WhenAll(acquiring));\n            Phase("eight.acquired", fixture);')
body=body.replace('            Assert.Equal(original.OrderBy(pair => pair.Key), renewed.OrderBy(pair => pair.Key));','            Phase("renewed.identities.read", fixture);\n            Assert.Equal(original.OrderBy(pair => pair.Key), renewed.OrderBy(pair => pair.Key));',1)
wrapped=setup+'''        Phase("fixture.created", fixture);
        try
        {
'''+''.join('    '+line+'\n' for line in body.splitlines())+'''        }
        catch (Exception error)
        {
            Phase("scenario.failure", fixture, error);
            throw;
        }
        finally
        {
            Phase("final.close.start", fixture);
            var failure = await Record.ExceptionAsync(() => fixture.DisposeAsync().AsTask());
            Phase("final.close.observed", fixture, failure);
            var cleanup = (failure as TtLifecycleException)?.Cleanup;
            if (cleanup is not null)
            {
                for (var attempt = 1; attempt <= 3; attempt++)
                {
                    Write(new { phase = "recovery.start", attempt, cleanup.OwnerId, resources = cleanup.OwnedResourceIds });
                    var recovery = await Record.ExceptionAsync(() => cleanup.RetryCleanupAsync());
                    Phase("recovery.observed", fixture, recovery);
                    if (recovery is null) break;
                }
            }
            Phase("final.resources", fixture);
        }
    }
'''
helpers='''
    private static readonly object TraceGate = new();
    private static string Prefix => Environment.GetEnvironmentVariable("TT024_ADAPTIVE_PREFIX") ?? "tt024-adaptive-diagnostic";
    private static void Phase(string phase, TtFactory<TestDbContext> fixture, Exception? error = null) =>
        Write(new { phase, state = fixture.PoolState, resources = fixture.OwnedResourceIds,
            error = error is null ? null : new { kind = error.GetType().FullName,
                stage = (error as TtLifecycleException)?.Stage, sqlState = (error as TtLifecycleException)?.SqlState,
                safeMessage = error is TtLifecycleException safe ? safe.Message : null, stack = error.StackTrace } });
    private static void Write(object row)
    {
        var path = Environment.GetEnvironmentVariable("TT024_ADAPTIVE_TRACE") ?? throw new InvalidOperationException("Diagnostic trace path missing.");
        var line = JsonSerializer.Serialize(new { utc = DateTime.UtcNow, row });
        lock (TraceGate) File.AppendAllText(path, line + "\\n");
    }
    private sealed class ProbeLogger : ILogger
    {
        public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;
        public bool IsEnabled(LogLevel level) => true;
        public void Log<TState>(LogLevel level, EventId id, TState state, Exception? error, Func<TState, Exception?, string> format)
        {
            var allowed = new HashSet<string>(StringComparer.Ordinal) { "OwnerId", "Operation", "DurationMilliseconds", "Succeeded", "Outcome", "Reason", "ContainerId", "ContainerName", "PoolId" };
            var fields = (state as IEnumerable<KeyValuePair<string, object?>> ?? [])
                .Where(pair => allowed.Contains(pair.Key)).ToDictionary(pair => pair.Key, pair => pair.Value);
            Write(new { phase = "logger", eventId = id.Id, fields });
        }
    }
'''
probe='''using Microsoft.EntityFrameworkCore;
using Npgsql;
using TurboTest.EFCore;
using TurboTest.EFCore.Internal;
using Microsoft.Extensions.Logging;
using System.Text.Json;
namespace TurboTest.Tests;
[Collection("Static lifecycle")]
public class NativeAdaptiveProbeTests
{
    [Fact]
    [Trait("Category", "PostgreSQL")]
'''+wrapped+helpers+'}\n'
(OUT/'NativeAdaptiveProbeTests.cs').write_text(probe)
path=xml.sax.saxutils.escape(str(OUT/'NativeAdaptiveProbeTests.cs'))
(OUT/'Probe.targets').write_text('<Project><ItemGroup Condition="\'$(MSBuildProjectName)\' == \'TurboTest.Tests\'"><Compile Include="'+path+'" /></ItemGroup></Project>\n')
meta={'purpose':'One-off observation: preserve/log body failure before await-using teardown can mask it; no production behavior or maintained test edited.',
      'source':str(source.relative_to(ROOT)),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
      'probeSha256':hashlib.sha256(probe.encode()).hexdigest(),'separateBuildOutput':'/tmp/tt024-adaptive-diagnostic-build',
      'differences':['unique host prefix and safe structured logger','phase stamps and body catch that rethrows original failure','explicit final cleanup retries retained capability up to3 times without masking original error'],
      'limits':['Instrumentation can affect scheduling; a passing isolated probe is not whole-cohort proof.','No arbitrary raw exception message or SQL/credential output is emitted by the phase logger.','No mutation fault and no new maintained test is introduced.']}
(OUT/'probe-manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'probe':str(OUT/'NativeAdaptiveProbeTests.cs'),'sourceSha256':meta['sourceSha256'],'probeSha256':meta['probeSha256']}))
