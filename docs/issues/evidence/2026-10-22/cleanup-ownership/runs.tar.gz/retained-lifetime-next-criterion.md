# Next TT024 lifetime criterion after ownership slice integration

The current full gate runs against immutable maintained inputs. Do not edit those inputs until it terminates and the current review boundary is settled.

## Initializer CTS lifetime (1769,1777,1787,1839,1840)

Capture the actual initializer token and obtain its WaitHandle while initialization is active. The handle must stay open while initialization, cancellation callbacks and the admitted first drain are independently held. Complete initialization before releasing the callback, then callback before first deletion; assert the handle stays open at each owned boundary. After actual owned jobs and the first drain attempt settle, require the captured handle to close and the token WaitHandle getter to throw ObjectDisposedException. Keep caller CTS alive so its disposal cannot supply the result. A separate success case requires release when normal initialization returns. Reuse real startup ordering contract evidence from StartupCancellationOwnershipTests; do not replace the owning initialization/drain implementation with a hand-written simulation.

## Monitor CTS lifetime (217)

Capture the actual reader token and allocate its WaitHandle. Register a separately gated cancellation callback, hold reader work independently, and call repeated Stop/Join. Assert no new tick starts and the source is alive until both jobs settle. Once Join completes, require closed handle and disposed getter. Meaningful callback errors must be retained exactly once (TT023 coordination). Release both gates in finally and join the real monitor completion.

## Registry and callback retention (1884)

Use no-inline helper scopes to return WeakReference objects to completed registered handles; retain the static registry and force bounded collections only after actual attempts finish. An empty leaked handle must fail, so callback payload collection alone is insufficient. Separately keep a completed capability alive while checking that its callback/resource payloads can collect, to prove reference release rather than relying on capability collection. Repeat successful operations. GC is evidence of reachability after completed operations, not a timeout-based resource release oracle.

Calibrate each assertion with the corresponding source-bound missing-disposal or missing-release fault before claiming an original question disposed. Preserve original mutation statuses and avoid inventing a new full-mutation result. Source changes still follow one criterion through owning tests, coverage/refactor and canonical fast before next criterion.
