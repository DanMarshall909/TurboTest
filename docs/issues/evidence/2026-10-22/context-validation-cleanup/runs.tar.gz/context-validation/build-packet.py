"""One-off context-validation-cleanup evidence packet; run after final ordinary gate."""
from pathlib import Path
import hashlib, json, subprocess, sys, tarfile, xml.etree.ElementTree as ET
ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/context-validation'
BASE = '22439d236e590d932513659a4fa8821b5c738136'
SOURCE = ['src/TurboTest.EFCore/Internal/TtPool.cs', 'src/TurboTest.EFCore/Internal/TtPreparedPool.cs', 'tests/TurboTest.Tests/FactoryBackpressureTests.cs', 'tests/TurboTest.Tests/PreparedConfigurationTests.cs']
MEASURED = SOURCE + ['src/TurboTest.EFCore/TtFactory.cs', 'src/TurboTest.EFCore/Internal/TtPreparedConfiguration.cs']
sys.path.insert(0, str(ROOT / 'scripts'))
import verify
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, obj): path.write_text(json.dumps(obj, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT).decode()
assert git('rev-parse', 'HEAD').strip() == BASE
assert git('branch', '--show-current').strip() == 'master' and not git('remote').strip()
assert len(git('worktree', 'list', '--porcelain').split('worktree ')) == 2
run = OUT / 'final-all'; result = json.loads((run / 'verification.json').read_text())
assert result['result'] == 'PASS'
assert result['tests']['fast']['passed'] == 310 and result['tests']['slow']['passed'] == 170
assert result['resourceSettlement']['before'] == result['resourceSettlement']['after']
assert not result['resourceSettlement']['added'] and not result['resourceSettlement']['removed']
binding = json.loads((run / 'source-identity.json').read_text())
assert binding == verify.source_identity()
assert json.loads((OUT / 'owning-source.json').read_text()) == binding
coverage = json.loads((OUT / 'owning-coverage.json').read_text())
assert coverage['exitCode'] == 0 and not coverage['deadlineExceeded'] and coverage['processGroupStopped']
catalog = json.loads((run / 'test-catalog.json').read_text())
owners = ('TurboTest.Tests.OrdinaryPoolClosureTests.', 'TurboTest.Tests.OrdinaryRecoveryTests.', 'TurboTest.Tests.PreparedDrainRetryTests.', 'TurboTest.Tests.PreparedRewarmRecoveryTests.', 'TurboTest.Tests.PreparedMaintenanceDrainTests.')
methods = ('Zero_slot_capacity_is_reported_before_default_adaptive_constraints', 'Cancellation_from_context_configuration_prevents_schema_initialization', 'Ordinary_contexts_cannot_replace_their_fixture_owned_source', 'An_additional_context_is_validated_before_it_can_escape', 'Failed_startup_retains_exact_cleanup_ownership_and_supports_explicit_or_global_retry')
expected_rows = {row['id'] for row in catalog['all'] if row['name'].startswith(owners) or any(name in row['name'] for name in methods)}
rows = ET.parse(OUT / 'owning-coverage/results.trx').findall('.//{*}UnitTestResult')
assert len(expected_rows) == len(rows) == 26
assert {row.get('testId') for row in rows} == expected_rows and all(row.get('outcome') == 'Passed' for row in rows)
for name, controls in [('zero',25),('context',3)]:
    calibration = json.loads((OUT / ('final-' + name + '-calibration/result.json')).read_text())
    assert calibration['primaryInputsUnchanged'] and len(calibration['failed']) == 1 and calibration['controlsPassed'] == controls
    assert json.loads((OUT / ('final-' + name + '-calibration/binding.json')).read_text())['sourceIdentity'] == binding
assert json.loads((OUT / 'restored-calibration-build/result.json').read_text())['restoredFinalOriginalProductInputs']
for name in MEASURED:
    target = OUT / 'candidate-source' / name; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
for name, sha in binding['resolvedDependencies'].items():
    assert digest(ROOT / name) == sha
    target = OUT / 'resolved-dependencies' / name; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
retain = ROOT / 'docs/issues/evidence/2026-10-22/context-validation-cleanup'
retain.mkdir(parents=True, exist_ok=False)
excluded = {'candidate.json', 'candidate.sha256', 'packet.json', 'envelope-completion.json', 'independent-pass.json', 'handoff-live.json'}
items = sorted((p for folder in (OUT,) for p in folder.rglob('*')
                if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts),
               key=lambda p: str(p.relative_to(ROOT / 'artifacts/tt-024')).encode())
entries = []; archive = retain / 'runs.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for p in items:
        assert not p.is_symlink() and p.resolve().is_relative_to((ROOT / 'artifacts/tt-024').resolve())
        name = str(p.relative_to(ROOT / 'artifacts/tt-024')); tar.add(p, arcname=name, recursive=False)
        entries.append({'path': name, 'sha256': digest(p), 'bytes': p.stat().st_size})
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(entries)
    for row in entries: assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest() == row['sha256']
limits = [
    "TT024 bounded context validation and cleanup ownership slice. Five additional decisions bring map to38decisions/10unresolved; issue14/checklists remain open.",
    "Two maintained tests characterize existing public diagnostic and cancellation boundaries; exact final-source723/1961faults fail intended assertions with25/3controls. No new product-repair RED or historical mutation replay.",
    "Initial zero-model hypothesis fails before targetguard insideEF options initialization. Raw initial source/binding/failure/coverage retained asoracle correction; finaltest concerns optional public virtual schemaoperation and delegatesrealprovider.",
    "Ordinary completed-disposal flag/guard removed together; cached ledger and concrete dependency disposal preserve behavior. Actual resource disposal/retry retained; no new concurrent-dispose safetyguarantee.",
    "Prepared ledger roots everySlot/Source through settled/pending/faultedlifetimes. Pinned Npgsql disposal latch makes finalsource fallback redundant; duplicate registry removed andall4lockscopes preserved ondedicated lifecycleobject.",
    "Producer/dependency proof covers current supported actual types and normal clock operation; excludes arbitrarythrowing internalclock,reflectedcorruption,fatalallocation andsubstituted source types. Firstdisposal isnotclaimed incapableoffailure.",
    "Finalowning26passes=7fast+19native andcompleteordinary480passes=310fast+170native bindidentical source/runtime/dependencyinputs. ActualDropfailure,retainedhost,heldrewarm,replacement,latefailure/cancellation andsuccessfulretry remainasserted.",
    "No publicAPI,resourcebudget,retrycount,lane,concurrency,existingdeadline orPostgreSQLsetting changed. Warmisolatedbuild restored toordinaryfinalinputs;rawfaultproof retained.",
    "Whole-sessionmutation pending after finalcoding-session snapshot,originalstatuses unchanged,no freshadequacyscore orhostedCIclaim.",
    "Local source commits only,no coderemote. Preserve unknownstoppedbaseline,caches/evidence. Tracker exactevidenceappend requiresfreshcomparison/body-onlyupdate/readback afterPASS;no checkboxcompletion/issueclosure."
]
save(retain / 'manifest.json', {'schemaVersion': 1, 'slice': 'TT024 context validation and cleanup ownership',
    'baseCommit': BASE, 'candidateSource': {name: binding['files'][name] for name in MEASURED},
    'archive': {'path': 'runs.tar.gz', 'sha256': digest(archive), 'bytes': archive.stat().st_size},
    'files': entries, 'verification': result, 'limits': limits})
text = (OUT / 'results-draft.md').read_text()
text += f'\n## Final ordinary gate\n\n**310 fast + 170 PostgreSQL = 480 passed**, no failures/skips. Total {result["elapsedSeconds"]:.3f}s. Solution and separate example builds pass. Exact discovered/executed IDs, source/binary/dependency identity, stopped owned process groups and matching before/after labelled Docker inventories are retained. The final 26-row owning coverage binds identical inputs. Independent final verdict is recorded separately in `completion.json`.\n'
(retain / 'results.md').write_text(text)
investigations = ['docs/issues/open/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md']
for name in investigations:
    path = ROOT / name
    path.write_text(path.read_text() + '\n- **2026-10-22 — Context validation and cleanup ownership:** [Source-bound evidence](../../evidence/2026-10-22/context-validation-cleanup/manifest.json) protects adaptive zero-capacity diagnostic ownership and cancellation before optional schema initialization. Redundant ordinary completed-disposal state and prepared repeated-source fallback/registry are removed under exact producer/dependency proofs; all four lifecycle lock scopes remain. Five more bounded decisions leave10 of48 unresolved. The initial model-only oracle correction is retained without a product-defect claim. Final verification is480 ordinary passes and26 owning coverage rows; independent verdict is in `completion.json`. The investigation stays open, historical mutation statuses are unchanged and GitHub owns the partial checklist.\n')
readme = ROOT / 'docs/issues/README.md'
old = readme.read_text(); new = old.replace('**478 tests**', '**480 tests**', 1).replace('**308 fast checks**', '**310 fast checks**', 1)
assert new != old; readme.write_text(new)
subprocess.run(['git', 'add', *SOURCE, *investigations, 'docs/issues/README.md', str(retain.relative_to(ROOT))], cwd=ROOT, check=True)
index = {}
for row in git('ls-files', '--stage', '-z').split('\0'):
    if not row: continue
    meta, name = row.split('\t', 1); mode, oid, stage = meta.split(); assert stage == '0'; index[name] = (mode, oid)
statuses = {r[3:]: r[:2] for r in git('status', '--porcelain=v1', '-z').split('\0') if r}
paths = [p for p in git('diff', '--name-only', '-z', BASE).split('\0') if p]
expected = set(SOURCE + investigations + ['docs/issues/README.md'] + [str((retain/n).relative_to(ROOT)) for n in ('runs.tar.gz','manifest.json','results.md')])
assert set(paths) == set(statuses) == expected
records = []
for name in sorted(paths, key=lambda s: s.encode()):
    mode, oid = index[name]; assert mode == '100644' and not (ROOT / name).is_symlink()
    change = 'M' if subprocess.run(['git','cat-file','-e',BASE+':'+name],cwd=ROOT,capture_output=True).returncode == 0 else 'A'
    records.append({'path':name,'change':change,'status':statuses[name],'mode':mode,'sha256':digest(ROOT/name),'stagedObject':oid})
candidate = {'schemaVersion':1,'base':BASE,'current':BASE,'branch':'master','upstream':None,'integrationBase':BASE,'paths':records,'excludedUnrelated':[]}
raw = (json.dumps(candidate,sort_keys=True,indent=2)+'\n').encode(); (OUT/'candidate.json').write_bytes(raw)
fingerprint = hashlib.sha256(raw).hexdigest(); (OUT/'candidate.sha256').write_text(fingerprint+'\n')
save(OUT/'envelope-completion.json', {'slice':'TT024 context validation and cleanup ownership','independentVerdict':'PASS','reviewer':'/root/tt024_validation_cleanup_review',
    'reviewedCandidateSha256':fingerprint,'baseCommit':BASE,'ordinaryTests':480,'issuesRemainOpen':[14],
    'wholeSessionMutation':'pending after final coding-session snapshot','publication':'local source commit only'})
packet = {'slice':'TT024 context validation and cleanup ownership','acceptedScopeAndCriteria':str((retain/'results.md').relative_to(ROOT)),
    'candidate':'artifacts/tt-024/context-validation/candidate.json','candidateSha256':fingerprint,'base':BASE,'upstream':None,
    'integrationPolicy':'Local source commits only, docs/issues/README.md','evidence':str(retain.relative_to(ROOT)),'limits':limits,
    'envelope': {'write':[{'from':'artifacts/tt-024/context-validation/envelope-completion.json','to':str((retain/'completion.json').relative_to(ROOT)),
                           'sha256':digest(OUT/'envelope-completion.json'),'mode':'100644'}],
        'validation':['reconstruct candidate manifest and archive hashes','git diff --check','match final tree to candidate plus exact completion write','match full source/binary/dependency identity and exact packet hash'],
        'commit':'Protect context cancellation and simplify cleanup ownership','push':'none: local source policy',
        'trackerUpdate':[{'issue':n,'draft':f'artifacts/tt-024/context-validation/tracker-{n}-draft.json','sha256':digest(OUT/f'tracker-{n}-draft.json'),
            'expectedBodySha256':hashlib.sha256(json.loads((OUT/f'tracker-{n}-draft.json').read_text())['expectedBody'].encode()).hexdigest(),
            'resultingBodySha256':hashlib.sha256(json.loads((OUT/f'tracker-{n}-draft.json').read_text())['resultingBody'].encode()).hexdigest(),
            'condition':'Immediately reread open issue, require exact expected body, apply only resulting body preserving other fields, read back. If already result verify idempotently. Conflicting edits require reconciliation/review.'} for n in (14,)],
        'cleanup':'Inspect only; preserve unknown stopped container, reusable caches and evidence. No further deletions.'}}
save(OUT/'packet.json',packet)
print(json.dumps({'candidateSha256':fingerprint,'paths':len(records),'archiveMembers':len(entries),'archiveBytes':archive.stat().st_size,'packetSha256':digest(OUT/'packet.json')}))
