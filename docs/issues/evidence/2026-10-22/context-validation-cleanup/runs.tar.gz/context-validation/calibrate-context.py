"""One bounded1961 calibration against unchanged primary outputs."""
from pathlib import Path
import hashlib, importlib.util, json, os, xml.etree.ElementTree as E
ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/context-validation/context-calibration'
OUT.mkdir()
spec = importlib.util.spec_from_file_location('verify', ROOT / 'scripts/verify.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
before = v.source_identity()
source = ROOT / 'src/TurboTest.EFCore/TtFactory.cs'
original = source.read_text()
old, new = 'Register(context, acquisitionToken);\n                acquisitionToken.ThrowIfCancellationRequested();\n                if (_preparedOptions is null && _options.AutoMigrate)', 'Register(context, acquisitionToken);\n                if (_preparedOptions is null && _options.AutoMigrate)'
assert original.count(old) == 1
fault = OUT / source.name
fault.write_text(original.replace(old, new))
targets = OUT / 'Fault.targets'
inputs = OUT / 'compile-inputs.txt'
targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="TtFactory.cs"/><Compile Include="{fault}"/></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{inputs}" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
build = ROOT / 'artifacts/tt-024/lifetimes/calibration-build'
v.run_phase('build', ['dotnet', 'build', v.PROJECT, '-c', 'Release', '--no-restore',
    '--artifacts-path', str(build), '-p:CustomBeforeMicrosoftCommonTargets=' + str(targets),
    '-nr:false', '-p:UseSharedCompilation=false'], OUT, 180, os.environ)
compiled = inputs.read_text().splitlines()
assert str(fault) in compiled and str(source) not in compiled
dll = build / 'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
binaries = {str(p.relative_to(build)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in sorted(dll.parent.rglob('*')) if p.is_file() and (p.suffix == '.dll' or p.name.endswith(('.deps.json', '.runtimeconfig.json')))}
v.write_json(OUT / 'binding.json', {'sourceIdentity': before, 'compiledInputs': binaries,
    'originalSourceSha256': hashlib.sha256(original.encode()).hexdigest(),
    'faultSourceSha256': hashlib.sha256(fault.read_bytes()).hexdigest(), 'old': old, 'new': new})
try:
    v.run_phase('test', ['dotnet', 'test', str(dll), '--filter',
        'FullyQualifiedName~Cancellation_from_context_configuration_prevents_schema_initialization|FullyQualifiedName~Ordinary_contexts_cannot_replace_their_fixture_owned_source|FullyQualifiedName~An_additional_context_is_validated_before_it_can_escape',
        '--results-directory', str(OUT / 'results'), '--logger', 'trx;LogFileName=results.trx'], OUT, 30, os.environ)
except v.VerificationError:
    pass
receipt = json.loads((OUT / 'test.json').read_text())
assert receipt['exitCode'] == 1 and not receipt['deadlineExceeded'] and receipt['processGroupStopped']
rows = E.parse(OUT / 'results/results.trx').findall('.//{*}UnitTestResult')
assert len(rows) == 4
failed = [{'name': r.get('testName'), 'message': r.findtext('.//{*}Message')}
    for r in rows if r.get('outcome') == 'Failed']
assert len(failed) == 1 and 'Cancellation_from_context_configuration' in failed[0]['name']
assert 'Schema initialization ran after configuration canceled acquisition.' in failed[0]['message']
assert before == v.source_identity() and source.read_text() == original
v.write_json(OUT / 'result.json', {'question':1961, 'failed':failed, 'controlsPassed':3,
    'primaryInputsUnchanged':True, 'qualification':'Bounded source fault with structured diagnostic failure, not historical mutation replay or new product-defect RED.'})
print(json.dumps({'owningFailed':1, 'controlsPassed':3, 'primaryInputsUnchanged':True}))
