"""One bounded723 calibration against unchanged primary outputs."""
from pathlib import Path
import hashlib, importlib.util, json, os, xml.etree.ElementTree as E
ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/context-validation/zero-calibration'
OUT.mkdir()
spec = importlib.util.spec_from_file_location('verify', ROOT / 'scripts/verify.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
before = v.source_identity()
source = ROOT / 'src/TurboTest.EFCore/Internal/TtPreparedConfiguration.cs'
original = source.read_text()
old, new = 'if (options.PoolSize <= 0)', 'if (options.PoolSize < 0)'
assert original.count(old) == 1
fault = OUT / source.name
fault.write_text(original.replace(old, new))
targets = OUT / 'Fault.targets'
inputs = OUT / 'compile-inputs.txt'
targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="Internal/TtPreparedConfiguration.cs"/><Compile Include="{fault}"/></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{inputs}" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
build = ROOT / 'artifacts/tt-024/lifetimes/calibration-build'
v.run_phase('build', ['dotnet', 'build', v.PROJECT, '-c', 'Release', '--no-restore',
    '--artifacts-path', str(build), '-p:CustomBeforeMicrosoftCommonTargets=' + str(targets),
    '-nr:false', '-p:UseSharedCompilation=false'], OUT, 180, os.environ)
compiled = inputs.read_text().splitlines()
assert str(fault) in compiled and str(source) not in compiled
dll = build / 'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
binaries = {str(p.relative_to(build)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in sorted(dll.parent.rglob('*')) if p.is_file() and (p.suffix == '.dll' or p.name.endswith(('.deps.json', '.runtimeconfig.json')))}
v.write_json(OUT / 'binding.json', {'sourceIdentity': before, 'compiledInputs': binaries,
    'originalSourceSha256': hashlib.sha256(original.encode()).hexdigest(),
    'faultSourceSha256': hashlib.sha256(fault.read_bytes()).hexdigest(), 'old': old, 'new': new})
try:
    v.run_phase('test', ['dotnet', 'test', str(dll), '--filter',
        'FullyQualifiedName~Zero_slot_capacity_is_reported_before_default_adaptive_constraints|FullyQualifiedName~Invalid_or_unsupported_prepared_configuration_is_rejected_before_image_preparation',
        '--results-directory', str(OUT / 'results'), '--logger', 'trx;LogFileName=results.trx'], OUT, 30, os.environ)
except v.VerificationError:
    pass
receipt = json.loads((OUT / 'test.json').read_text())
assert receipt['exitCode'] == 1 and not receipt['deadlineExceeded'] and receipt['processGroupStopped']
rows = E.parse(OUT / 'results/results.trx').findall('.//{*}UnitTestResult')
assert len(rows) == 26
failed = [{'name': r.get('testName'), 'message': r.findtext('.//{*}Message')}
    for r in rows if r.get('outcome') == 'Failed']
assert len(failed) == 1 and 'Zero_slot_capacity' in failed[0]['name']
assert 'PoolSize' in failed[0]['message'] and 'MinimumWarmDatabases' in failed[0]['message']
assert before == v.source_identity() and source.read_text() == original
v.write_json(OUT / 'result.json', {'question':723, 'failed':failed, 'controlsPassed':25,
    'primaryInputsUnchanged':True, 'qualification':'Bounded source fault with structured diagnostic failure, not historical mutation replay or new product-defect RED.'})
print(json.dumps({'owningFailed':1, 'controlsPassed':25, 'primaryInputsUnchanged':True}))
