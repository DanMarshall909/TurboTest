"""One-off observer/lifetime evidence packet; run after final ordinary gate."""
from pathlib import Path
import hashlib, json, subprocess, sys, tarfile, xml.etree.ElementTree as ET
ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/observer-final'
BASE = '8f572b8e0f9440eaed7025828e3fd8493f66801a'
SOURCE = ['tests/TurboTest.Tests/FactoryBackpressureTests.cs',
          'tests/TurboTest.Tests/FactoryMaintenanceTests.cs',
          'tests/TurboTest.Tests/QueuedSynchronizationContext.cs']
sys.path.insert(0, str(ROOT / 'scripts'))
import verify
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, obj): path.write_text(json.dumps(obj, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT).decode()
assert git('rev-parse', 'HEAD').strip() == BASE
assert git('branch', '--show-current').strip() == 'master' and not git('remote').strip()
assert len(git('worktree', 'list', '--porcelain').split('worktree ')) == 2
run = OUT / 'all'; result = json.loads((run / 'verification.json').read_text())
assert result['result'] == 'PASS'
assert result['tests']['fast']['passed'] == 295 and result['tests']['slow']['passed'] == 168
assert result['resourceSettlement']['before'] == result['resourceSettlement']['after']
assert not result['resourceSettlement']['added'] and not result['resourceSettlement']['removed']
binding = json.loads((run / 'source-identity.json').read_text())
assert binding == verify.source_identity()
probe = ROOT / 'artifacts/tt-024/observer-race'
assert json.loads((probe / 'fence-source.json').read_text()) == binding
coverage = json.loads((probe / 'fence-coverage.json').read_text())
assert coverage['exitCode'] == 0 and not coverage['deadlineExceeded'] and coverage['processGroupStopped']
catalog = json.loads((run / 'test-catalog.json').read_text())
owners = ('TurboTest.Tests.FactoryBackpressureTests.', 'TurboTest.Tests.FactoryMaintenanceTests.')
expected_rows = {row['id'] for row in catalog['all'] if row['name'].startswith(owners)}
rows = ET.parse(probe / 'fence-coverage/results.trx').findall('.//{*}UnitTestResult')
assert len(expected_rows) == len(rows) == 16
assert {row.get('testId') for row in rows} == expected_rows and all(row.get('outcome') == 'Passed' for row in rows)
assert json.loads((probe / 'private-node-inspection.json').read_text())['allExpectedPatternsMatch']
assert json.loads((probe / 'calibration-fence/result.json').read_text())['primaryInputsUnchanged']
for name in SOURCE:
    target = OUT / 'candidate-source' / name; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
for name, sha in binding['resolvedDependencies'].items():
    assert digest(ROOT / name) == sha
    target = OUT / 'resolved-dependencies' / name; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
retain = ROOT / 'docs/issues/evidence/2026-10-22/factory-observer-race'
retain.mkdir(parents=True, exist_ok=False)
excluded = {'candidate.json', 'candidate.sha256', 'packet.json', 'envelope-completion.json', 'independent-pass.json'}
items = sorted((p for folder in (probe, OUT) for p in folder.rglob('*')
                if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts),
               key=lambda p: str(p.relative_to(ROOT / 'artifacts/tt-024')).encode())
entries = []; archive = retain / 'runs.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for p in items:
        assert not p.is_symlink() and p.resolve().is_relative_to((ROOT / 'artifacts/tt-024').resolve())
        name = str(p.relative_to(ROOT / 'artifacts/tt-024')); tar.add(p, arcname=name, recursive=False)
        entries.append({'path': name, 'sha256': digest(p), 'bytes': p.stat().st_size})
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(entries)
    for row in entries: assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest() == row['sha256']
limits = [
    'Bounded TT024/TT023 factory observer/lifetime slice; both issues remain open.20of48originalTT024questions unresolved.',
    'Production unchanged. New maintained characterization green on introduction; source faults calibrate specific assertions, no repairRED claimed.',
    'Seven cleanup decisions use one-off private-node probes only:45rows,9variants,finiteGC windows. No maintained private-field regression kills or long-term memory-growth bound claimed.',
    '1906 narrow canceled-request/actual-failure/observer-finally schedule now maintained/fault-sensitive; previous cancellation-observed/actual-failure/drain schedule remains a separate control.',
    'Initial same-context cancellation setup and timer-dependent callback assumption corrected; source cuts and failed diagnostic empty-body builds retained separately.',
    'Original mutation statuses unchanged; whole-session mutation pending after final coding-session snapshot.',
    'NativeSQL/Docker contracts retained separately in all168slowchecks. In-process diagnostic source disposal is not physicalPostgreSQLdeletion or liveSQLcoverage.',
    'No timeout, lane, concurrency or PostgreSQL setting changed. Fullsource/binary/dependencyidentitymatches16owningcoverage.',
    'Local source commits only, no code remote or hostedCI claim. Unknownstoppedcontainer and reusablecaches preserved.',
    '172archiveddisposablehistoricalcoveragefiles removed afterfulloriginal/archivehashverification;439719464bytes reclaimed. No cache deletion.',
    'Trackerbodydrafts are proposals untilfreshcompare/body-onlywrite/readback afterreview; no new acceptancecheckbox or issueclosure claimed.',
]
save(retain / 'manifest.json', {'schemaVersion': 1, 'slice': 'TT024/TT023 factory observer ordering and completed-node lifetime',
    'baseCommit': BASE, 'candidateSource': {name: binding['files'][name] for name in SOURCE},
    'archive': {'path': 'runs.tar.gz', 'sha256': digest(archive), 'bytes': archive.stat().st_size},
    'files': entries, 'verification': result, 'limits': limits})
text = (OUT / 'results-draft.md').read_text()
text += f'\n## Final ordinary gate\n\n**295 fast + 168 PostgreSQL = 463 passed**, no failures/skips. Total {result["elapsedSeconds"]:.3f}s. Solution and separate example builds pass. Exact discovered/executed IDs, source/binary/dependency identity, stopped owned process groups and matching before/after labelled Docker inventories are retained. The final 16-row owning coverage binds identical inputs. Independent final verdict is recorded separately in `completion.json`.\n'
(retain / 'results.md').write_text(text)
investigations = ['docs/issues/open/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md',
                  'docs/issues/open/api/TT-023-assert-late-failure-ordering-and-safe-diagnostic-identity.md']
for name in investigations:
    path = ROOT / name
    path.write_text(path.read_text() + '\n- **2026-10-22 — Observer ordering and completed-node slice:** [Source-bound evidence](../../evidence/2026-10-22/factory-observer-race/manifest.json) records the maintained canceled-request/actual-failure/observer-finally race and one-off weak-node diagnostics for useful observer/worker/acquisition/drain removals. Eight additional bounded decisions leave20 of the original48 TT024questions unresolved. Production is unchanged. Final verification is463 passing ordinary checks and16 source-bound owning coverage rows; independent verdict is in `completion.json`. Both investigations remain open; original mutation statuses are unchanged and GitHub owns the partial acceptance checklist.\n')
readme = ROOT / 'docs/issues/README.md'
old = readme.read_text(); new = old.replace('**462 tests**', '**463 tests**', 1).replace('**294 fast checks**', '**295 fast checks**', 1)
assert new != old; readme.write_text(new)
subprocess.run(['git', 'add', *SOURCE, *investigations, 'docs/issues/README.md', str(retain.relative_to(ROOT))], cwd=ROOT, check=True)
index = {}
for row in git('ls-files', '--stage', '-z').split('\0'):
    if not row: continue
    meta, name = row.split('\t', 1); mode, oid, stage = meta.split(); assert stage == '0'; index[name] = (mode, oid)
statuses = {r[3:]: r[:2] for r in git('status', '--porcelain=v1', '-z').split('\0') if r}
paths = [p for p in git('diff', '--name-only', '-z', BASE).split('\0') if p]
expected = set(SOURCE + investigations + ['docs/issues/README.md'] + [str((retain/n).relative_to(ROOT)) for n in ('runs.tar.gz','manifest.json','results.md')])
assert set(paths) == set(statuses) == expected
records = []
for name in sorted(paths, key=lambda s: s.encode()):
    mode, oid = index[name]; assert mode == '100644' and not (ROOT / name).is_symlink()
    change = 'M' if subprocess.run(['git','cat-file','-e',BASE+':'+name],cwd=ROOT,capture_output=True).returncode == 0 else 'A'
    records.append({'path':name,'change':change,'status':statuses[name],'mode':mode,'sha256':digest(ROOT/name),'stagedObject':oid})
candidate = {'schemaVersion':1,'base':BASE,'current':BASE,'branch':'master','upstream':None,'integrationBase':BASE,'paths':records,'excludedUnrelated':[]}
raw = (json.dumps(candidate,sort_keys=True,indent=2)+'\n').encode(); (OUT/'candidate.json').write_bytes(raw)
fingerprint = hashlib.sha256(raw).hexdigest(); (OUT/'candidate.sha256').write_text(fingerprint+'\n')
save(OUT/'envelope-completion.json', {'slice':'TT024/TT023 factory observer ordering and completed-node lifetime','independentVerdict':'PASS','reviewer':'/root/tt024_factory_review',
    'reviewedCandidateSha256':fingerprint,'baseCommit':BASE,'ordinaryTests':463,'issuesRemainOpen':[13,14],
    'wholeSessionMutation':'pending after final coding-session snapshot','publication':'local source commit only'})
packet = {'slice':'TT024/TT023 factory observer ordering and completed-node lifetime','acceptedScopeAndCriteria':str((retain/'results.md').relative_to(ROOT)),
    'candidate':'artifacts/tt-024/observer-final/candidate.json','candidateSha256':fingerprint,'base':BASE,'upstream':None,
    'integrationPolicy':'Local source commits only, docs/issues/README.md','evidence':str(retain.relative_to(ROOT)),'limits':limits,
    'envelope': {'write':[{'from':'artifacts/tt-024/observer-final/envelope-completion.json','to':str((retain/'completion.json').relative_to(ROOT)),
                           'sha256':digest(OUT/'envelope-completion.json'),'mode':'100644'}],
        'validation':['reconstruct candidate manifest and archive hashes','git diff --check','match final tree to candidate plus exact completion write','match full source/binary/dependency identity and exact packet hash'],
        'commit':'Protect undelivered maintenance failures across observer cancellation','push':'none: local source policy',
        'trackerUpdate':[{'issue':n,'draft':f'artifacts/tt-024/observer-final/tracker-{n}-draft.json','sha256':digest(OUT/f'tracker-{n}-draft.json'),
            'expectedBodySha256':hashlib.sha256(json.loads((OUT/f'tracker-{n}-draft.json').read_text())['expectedBody'].encode()).hexdigest(),
            'resultingBodySha256':hashlib.sha256(json.loads((OUT/f'tracker-{n}-draft.json').read_text())['resultingBody'].encode()).hexdigest(),
            'condition':'Immediately reread open issue, require exact expected body, apply only resulting body preserving other fields, read back. If already result verify idempotently. Conflicting edits require reconciliation/review.'} for n in (13,14)],
        'cleanup':'Inspect only. Historical raw coverage cleanup already completed and receipted; preserve unknown stopped container, reusable caches and evidence. No further deletions.'}}
save(OUT/'packet.json',packet)
print(json.dumps({'candidateSha256':fingerprint,'paths':len(records),'archiveMembers':len(entries),'archiveBytes':archive.stat().st_size,'packetSha256':digest(OUT/'packet.json')}))
