// One-off structural diagnostic. Not a maintained behavior test.
using System.Collections;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using TurboTest.EFCore;
using TurboTest.EFCore.Internal;
using Xunit.Abstractions;

namespace TurboTest.Tests;

[Collection("Static lifecycle")]
public sealed class PrivateNodeProbe(ITestOutputHelper output)
{
    [Fact]
    public async Task Report_completed_private_node_lifetimes()
    {
        foreach (var scenario in new[] { "lease", "observedSuccess", "observedFailure", "canceledSuccess", "canceledFailure" })
        {
            var state = await Task.Run(() => Complete(scenario));
            try
            {
                var before = Alive(state);
                var drainStage = await Task.Run(() => Drain(state));
                var after = Alive(state);
                Assert.Equal((1, 1, 0), (state.Pool.Created, state.Pool.Deleted, state.Pool.Snapshot.Reserved));
                Assert.Equal(scenario.Contains("Failure") ? 2 : 1, state.Pool.DeleteAttempts);
                Assert.Empty(state.Pool.OwnedResourceIds);
                output.WriteLine("DIAGNOSTIC:" + JsonSerializer.Serialize(new { scenario, before, after, drainStage,
                    state.Pool.Created, state.Pool.Deleted, state.Pool.DeleteAttempts, reserved = state.Pool.Snapshot.Reserved }));
                GC.KeepAlive(state.Factory);
            }
            finally
            {
                state.Pool.Release.TrySetResult();
                await Task.Run(() => Drain(state));
                await state.Pool.DisposeAsync();
            }
        }
    }

    private sealed record State(TtFactory<TestDbContext> Factory, ProbePool Pool, WeakReference Acquisition, WeakReference? Work);
    private sealed record Nodes(bool Acquisition, bool? Work);

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static Nodes Alive(State state)
    {
        for (var i = 0; i < 3; i++)
        {
            GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced, blocking: true, compacting: true);
            GC.WaitForPendingFinalizers();
        }
        return new Nodes(state.Acquisition.IsAlive, state.Work?.IsAlive);
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static State Complete(string scenario)
    {
        var pool = new ProbePool(scenario.Contains("Failure"));
        var factory = new TtFactory<TestDbContext>(pool, new TtOptions { AutoMigrate = false }, ownsPool: true);
        if (scenario != "lease") pool.WarmAsync().WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult();
        using var caller = new CancellationTokenSource();
        var previous = SynchronizationContext.Current;
        var queue = new QueuedSynchronizationContext();
        var complete = false;
        SynchronizationContext.SetSynchronizationContext(queue);
        try
        {
            if (scenario == "lease")
            {
                var acquiring = factory.CreateLeaseAsync();
                var node = Capture(factory, "_acquisitions");
                pool.Checkout.TrySetResult();
                queue.RunUntil(acquiring);
                var lease = acquiring.GetAwaiter().GetResult();
                Assert.NotNull(lease.Context);
                var returning = lease.DisposeAsync().AsTask();
                queue.RunUntil(returning);
                returning.GetAwaiter().GetResult();
                queue.RunPostedCallbacks();
                Assert.Equal((1, 0), (pool.Snapshot.Ready, pool.Snapshot.Leased));
                complete = true;
                return new State(factory, pool, node, null);
            }
            var observation = factory.MaintainIdleAsync(caller.Token);
            Assert.True(pool.Deleting.Task.IsCompleted);
            var acquisition = Capture(factory, "_acquisitions");
            var work = Capture(factory, "_maintenance");
            if (scenario.StartsWith("canceled"))
            {
                Task.Run(() => caller.Cancel()).WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult();
                queue.RunUntil(observation);
                Assert.ThrowsAny<OperationCanceledException>(() => observation.GetAwaiter().GetResult());
            }
            pool.Release.TrySetResult();
            var actual = pool.Actual!;
            queue.RunUntil(actual);
            queue.RunPostedCallbacks();
            if (!scenario.StartsWith("canceled"))
            {
                queue.RunUntil(observation);
                if (scenario.Contains("Failure"))
                    Assert.Equal("SlotIdleRetire", Assert.Throws<TtLifecycleException>(() => observation.GetAwaiter().GetResult()).Stage);
                else observation.GetAwaiter().GetResult();
            }
            Assert.Equal(scenario.Contains("Failure"), actual.IsFaulted);
            queue.RunPostedCallbacks();
            complete = true;
            return new State(factory, pool, acquisition, work);
        }
        finally
        {
            pool.Release.TrySetResult();
            pool.Checkout.TrySetResult();
            SynchronizationContext.SetSynchronizationContext(previous);
            queue.ReleaseToThreadPool();
            if (!complete)
            {
                try { factory.DisposeAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult(); }
                catch (TtLifecycleException failure) { failure.Cleanup?.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult(); }
            }
        }
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static WeakReference Capture(TtFactory<TestDbContext> factory, string name)
    {
        const BindingFlags flags = BindingFlags.Instance | BindingFlags.NonPublic;
        var gate = typeof(TtFactory<TestDbContext>).GetField("_disposeGate", flags)!.GetValue(factory)!;
        lock (gate)
        {
            var entries = ((IEnumerable)typeof(TtFactory<TestDbContext>).GetField(name, flags)!.GetValue(factory)!).Cast<object>().ToArray();
            Assert.Single(entries);
            return new WeakReference(entries[0]);
        }
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static string? Drain(State state)
    {
        var draining = state.Factory.DisposeAsync().AsTask();
        try { draining.WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult(); return null; }
        catch (TtLifecycleException failure)
        {
            Assert.Equal("SlotIdleRetire", failure.Stage);
            Assert.DoesNotContain("private-node-payload", failure.ToString());
            Assert.Null(failure.InnerException);
            Assert.Same(draining, state.Factory.DisposeAsync().AsTask());
            var cleanup = Assert.IsType<TtCleanup>(failure.Cleanup);
            cleanup.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult();
            Assert.Empty(cleanup.OwnedResourceIds);
            return failure.Stage;
        }
    }

    private sealed class ProbePool : ITtDatabasePool
    {
        private readonly TtSlotPool<NpgsqlDataSource> _slots;
        internal readonly TaskCompletionSource Checkout = new(TaskCreationOptions.RunContinuationsAsynchronously);
        internal readonly TaskCompletionSource Deleting = new(TaskCreationOptions.RunContinuationsAsynchronously);
        internal readonly TaskCompletionSource Release = new(TaskCreationOptions.RunContinuationsAsynchronously);
        internal Task? Actual;
        internal int Created, Deleted, DeleteAttempts;
        public TtPoolSnapshot Snapshot => _slots.Snapshot;
        public TtResourceBudget Budget => TtResourceBudget.Create(new TtOptions { PoolSize = 1 }, true);
        public IReadOnlyList<string> OwnedResourceIds => Snapshot.Reserved == 0 ? [] : [Snapshot.OwnerId.ToString("N")];

        internal ProbePool(bool failFirstDelete)
        {
            _slots = new TtSlotPool<NpgsqlDataSource>(1, 1, _ =>
            {
                Assert.Equal(1, Interlocked.Increment(ref Created));
                return NpgsqlDataSource.Create("Host=localhost;Database=unused;Username=unused");
            }, (_, _) => Task.CompletedTask, async source =>
            {
                var attempt = Interlocked.Increment(ref DeleteAttempts);
                Assert.InRange(attempt, 1, failFirstDelete ? 2 : 1);
                if (attempt == 1)
                {
                    Deleting.TrySetResult();
                    await Release.Task;
                    if (failFirstDelete) throw new IOException("private-node-payload");
                }
                await source.DisposeAsync();
                Interlocked.Increment(ref Deleted);
            });
        }

        internal async Task WarmAsync()
        {
            var reservation = await _slots.AcquireAsync();
            await _slots.ReturnAsync(reservation, (_, _) => Task.CompletedTask);
        }

        public async Task<TtDatabase> GetDatabaseAsync(CancellationToken cancellationToken = default)
        {
            await Checkout.Task.WaitAsync(cancellationToken);
            var reservation = await _slots.AcquireAsync(cancellationToken);
            return new TtDatabase(reservation.Value,
                () => _slots.ReturnAsync(reservation, (_, _) => Task.CompletedTask),
                () => _slots.DiscardAsync(reservation));
        }

        public Task MaintainIdleAsync(CancellationToken cancellationToken = default)
        {
            Actual = _slots.ParkIdleAsync(0, (_, _) => Task.CompletedTask, maxParked: 0);
            return Actual.WaitAsync(cancellationToken);
        }

        public ValueTask DisposeAsync() => _slots.DisposeAsync();
        public Task RetryCleanupAsync() => _slots.RetryCleanupAsync();
    }
}
