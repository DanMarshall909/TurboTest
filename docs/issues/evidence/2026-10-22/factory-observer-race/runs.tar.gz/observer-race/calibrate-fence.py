"""One-off1906 diagnostic-loss calibration and extracted-pump root control."""
from pathlib import Path
import hashlib, importlib.util, json, os, xml.etree.ElementTree as ET
ROOT = Path('/home/dan/code/TurboTest'); OUT = ROOT / 'artifacts/tt-024/observer-race/calibration-fence'
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('verify', ROOT / 'scripts/verify.py')
v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
before = v.source_identity(); build = ROOT / 'artifacts/tt-024/lifetimes/calibration-build'
source = ROOT / 'src/TurboTest.EFCore/TtFactory.cs'; original = source.read_text()
fault = OUT / 'fault.cs'; targets = OUT / 'Fault.targets'; compiled = OUT / 'compile-inputs.txt'
equality = 'work.Completion.Task.Result is null'
root = '            _databases.TryAdd(database, 0);'
assert original.count(equality) == original.count(root) == 1
variants = {
    '1906': (original.replace(equality, 'work.Completion.Task.Result is not null'),
             'A_failure_recorded_before_canceled_observer_finally_remains_available_to_drain'),
    '1941-root-control': (original.replace(root, '            ;'),
             'An_abandoned_acquisition_keeps_its_pending_context_cleanup_rooted_until_it_settles'),
}
env = dict(os.environ, DOTNET_CLI_USE_MSBUILD_SERVER='0', MSBUILDDISABLENODEREUSE='1'); results = []
selection = 'FullyQualifiedName~A_failure_recorded_before_canceled_observer|FullyQualifiedName~Canceled_observation_retains_an_already_completed|FullyQualifiedName~An_abandoned_acquisition_keeps'
try:
    for name, (text, expected_name) in variants.items():
        fault.write_text(text); (OUT / (name + '-source.cs')).write_text(text)
        targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="TtFactory.cs" /><Compile Include="{fault}" /></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{compiled}" Lines="@(Compile->'%(FullPath)')" Overwrite="true" /></Target></Project>''')
        v.run_phase(name + '-build', ['dotnet', 'build', 'tests/TurboTest.Tests/TurboTest.Tests.csproj', '--no-restore', '-c', 'Release', '--artifacts-path', str(build), '-p:CustomBeforeMicrosoftCommonTargets=' + str(targets), '-nr:false', '-p:UseSharedCompilation=false', '--verbosity', 'minimal'], OUT, 120, env)
        inputs = compiled.read_text().splitlines(); assert str(fault) in inputs and str(source) not in inputs
        (OUT / (name + '-compile-inputs.txt')).write_text(compiled.read_text())
        dll = build / 'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
        v.write_json(OUT / (name + '-binding.json'), {'source': str(source),
            'sourceSha256': hashlib.sha256(original.encode()).hexdigest(), 'faultSha256': hashlib.sha256(text.encode()).hexdigest(),
            'compiledInputs': {str(p.relative_to(build)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*'))
                if p.is_file() and (p.suffix == '.dll' or p.name.endswith(('.deps.json', '.runtimeconfig.json')))}})
        try:
            v.run_phase(name + '-test', ['dotnet', 'test', str(dll), '--filter', selection,
                '--results-directory', str(OUT / (name + '-results')), '--logger', 'trx;LogFileName=results.trx'], OUT, 30, env)
        except v.VerificationError:
            pass
        receipt = json.loads((OUT / (name + '-test.json')).read_text())
        assert receipt['exitCode'] == 1 and not receipt['deadlineExceeded'] and receipt['processGroupStopped']
        rows = ET.parse(OUT / (name + '-results/results.trx')).findall('.//{*}UnitTestResult'); assert len(rows) == 4
        failures = [{'name': row.get('testName'), 'message': row.findtext('.//{*}Message')}
                    for row in rows if row.get('outcome') == 'Failed']
        assert len(failures) == 1 and failures[0]['name'].split('.')[-1] == expected_name
        expected_assertion = 'Assert.Throws() Failure: No exception was thrown' if name == '1906' else 'Assert.Null() Failure'
        assert expected_assertion in failures[0]['message'] and 'TimeoutException' not in failures[0]['message']
        assert sum(row.get('outcome') == 'Passed' for row in rows) == 3
        results.append({'variant': name, 'namedFailure': failures[0], 'otherCasesPassed': 3})
        v.write_json(OUT / 'progress.json', results); print(name, 'intended assertion fails;3controls pass', flush=True)
finally:
    assert before == v.source_identity()
v.write_json(OUT / 'result.json', {'primaryInputsUnchanged': True, 'results': results,
    'qualification': 'New maintained characterization catches exact1906predicate fault while earlier ordering controls pass. Root sensitivity preserved after helper extraction. Bounded source-substitution calibration; historical original mutation statuses unchanged and full whole-session mutation pending.'})
