"""One-off diagnostic of seven original retained-node questions; no maintained private-field test."""
from pathlib import Path
import hashlib, importlib.util, json, os, xml.etree.ElementTree as ET
ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/observer-race/private-nodes-final'
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('verify', ROOT / 'scripts/verify.py')
v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
before = v.source_identity(); build = ROOT / 'artifacts/tt-024/lifetimes/calibration-build'
source = ROOT / 'src/TurboTest.EFCore/TtFactory.cs'; original = source.read_text()
fault = OUT / 'source.cs'; targets = OUT / 'Probe.targets'; compiled = OUT / 'compile-inputs.txt'
probe = ROOT / 'artifacts/tt-024/observer-race/PrivateNodeProbe.cs'
variants = {'baseline': original,
    '1902': original.replace('                _acquisitions.Remove(settled);', '                ;'),
    '1905': original.replace('work.Completion.Task.Result is null || work.Delivered', 'work.Completion.Task.Result is null && work.Delivered'),
    '1907': original.replace('(work.Completion.Task.Result is null || work.Delivered)) _maintenance.Remove(work);', '(work.Completion.Task.Result is null || work.Delivered)) { }'),
    '1925': original.replace('failure is null || work.Delivered', 'failure is null && work.Delivered'),
    '1927': original.replace('if (!_acquisitions.Contains(observer) && (failure is null || work.Delivered)) _maintenance.Remove(work);', 'if (!_acquisitions.Contains(observer) && (failure is null || work.Delivered)) { }'),
    '2002': original.replace('lock (_disposeGate) _acquisitions.Remove(settled);', 'lock (_disposeGate) { }'),
    '2055': original.replace('                _maintenance.Remove(work);', '                ;'),
    'unchanged-control': original}
env = dict(os.environ, DOTNET_CLI_USE_MSBUILD_SERVER='0', MSBUILDDISABLENODEREUSE='1')
results = []
try:
    for name, text in variants.items():
        assert name in ('baseline', 'unchanged-control') or text != original
        fault.write_text(text); (OUT / (name + '-source.cs')).write_text(text)
        targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="TtFactory.cs" /><Compile Include="{fault}" /></ItemGroup><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.Tests'"><Compile Include="{probe}" /></ItemGroup><Target Name="RecordProbeCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore' Or '$(MSBuildProjectName)' == 'TurboTest.Tests'"><WriteLinesToFile File="{OUT}/$(MSBuildProjectName)-compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true" /></Target></Project>''')
        v.run_phase(name + '-build', ['dotnet', 'build', 'tests/TurboTest.Tests/TurboTest.Tests.csproj', '--no-restore', '-c', 'Release', '--artifacts-path', str(build), '-p:CustomBeforeMicrosoftCommonTargets=' + str(targets), '-nr:false', '-p:UseSharedCompilation=false', '--verbosity', 'minimal'], OUT, 120, env)
        product_inputs = (OUT / 'TurboTest.EFCore-compile.txt').read_text().splitlines()
        test_inputs = (OUT / 'TurboTest.Tests-compile.txt').read_text().splitlines()
        assert str(fault) in product_inputs and str(source) not in product_inputs and str(probe) in test_inputs
        dll = build / 'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
        v.write_json(OUT / (name + '-binding.json'), {'sourceSha256': hashlib.sha256(original.encode()).hexdigest(),
            'variantSha256': hashlib.sha256(text.encode()).hexdigest(), 'probeSha256': hashlib.sha256(probe.read_bytes()).hexdigest(),
            'productCompile': product_inputs, 'testCompile': test_inputs,
            'compiledInputs': {str(p.relative_to(build)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*'))
                if p.is_file() and (p.suffix == '.dll' or p.name.endswith(('.deps.json', '.runtimeconfig.json')))}})
        v.run_phase(name + '-test', ['dotnet', 'test', str(dll), '--filter', 'FullyQualifiedName~PrivateNodeProbe',
            '--results-directory', str(OUT / (name + '-results')), '--logger', 'trx;LogFileName=results.trx'], OUT, 45, env)
        rows = ET.parse(OUT / (name + '-results/results.trx')).findall('.//{*}UnitTestResult')
        assert len(rows) == 1 and rows[0].get('outcome') == 'Passed'
        stdout = rows[0].findtext('.//{*}StdOut')
        diagnostics = [json.loads(line.split('DIAGNOSTIC:', 1)[1]) for line in stdout.splitlines() if 'DIAGNOSTIC:' in line]
        assert len(diagnostics) == 5
        results.append({'variant': name, 'cases': diagnostics})
        v.write_json(OUT / 'progress.json', results)
        print(json.dumps(results[-1]), flush=True)
finally:
    assert before == v.source_identity()
v.write_json(OUT / 'result.json', {'primaryInputsUnchanged': True, 'results': results,
    'qualification': 'One-off private-node diagnostics with real slot ledger and independent public outcomes/physical deletion. Not maintained behavior tests, not original mutation-status updates. Inspect lifetime patterns before deciding useful cleanup.'})
