"""One-off completed public object lifetime versus bare settlement-node control."""
from pathlib import Path
import hashlib, importlib.util, json, os, xml.etree.ElementTree as ET
ROOT = Path('/home/dan/code/TurboTest'); OUT = ROOT / 'artifacts/tt-024/factory-completed-lifetime/calibration'
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('verify', ROOT / 'scripts/verify.py')
v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
before = v.source_identity(); build = ROOT / 'artifacts/tt-024/lifetimes/calibration-build'
source = ROOT / 'src/TurboTest.EFCore/TtFactory.cs'; original = source.read_text()
fault = OUT / 'fault.cs'; targets = OUT / 'Fault.targets'; compiled = OUT / 'compile-inputs.txt'
variants = {
    'retained-completed-database': ('                        _databases.TryRemove(database, out _);', 1),
    'retained-completed-lease': ('                        if (lease is not null) _leases.TryRemove(lease, out _);', 1),
    '2002-bare-settlement-control': ('            lock (_disposeGate) _acquisitions.Remove(settled);', 0),
}
env = dict(os.environ, DOTNET_CLI_USE_MSBUILD_SERVER='0', MSBUILDDISABLENODEREUSE='1'); results = []
try:
    for name, (statement, expected_exit) in variants.items():
        assert original.count(statement) == 1
        text = original.replace(statement, '                        ;')
        fault.write_text(text); (OUT / (name + '-source.cs')).write_text(text)
        targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="TtFactory.cs" /><Compile Include="{fault}" /></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{compiled}" Lines="@(Compile->'%(FullPath)')" Overwrite="true" /></Target></Project>''')
        v.run_phase(name + '-build', ['dotnet', 'build', 'tests/TurboTest.Tests/TurboTest.Tests.csproj', '--no-restore', '-c', 'Release', '--artifacts-path', str(build), '-p:CustomBeforeMicrosoftCommonTargets=' + str(targets), '-nr:false', '-p:UseSharedCompilation=false', '--verbosity', 'minimal'], OUT, 120, env)
        inputs = compiled.read_text().splitlines(); assert str(fault) in inputs and str(source) not in inputs
        (OUT / (name + '-compile-inputs.txt')).write_text(compiled.read_text())
        dll = build / 'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
        v.write_json(OUT / (name + '-binding.json'), {'source': str(source),
            'sourceSha256': hashlib.sha256(original.encode()).hexdigest(), 'faultSha256': hashlib.sha256(text.encode()).hexdigest(),
            'compiledInputs': {str(p.relative_to(build)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*'))
                if p.is_file() and (p.suffix == '.dll' or p.name.endswith(('.deps.json', '.runtimeconfig.json')))}})
        try:
            v.run_phase(name + '-test', ['dotnet', 'test', str(dll), '--filter', 'FullyQualifiedName~Repeated_successful_leases_release_completed',
                '--results-directory', str(OUT / (name + '-results')), '--logger', 'trx;LogFileName=results.trx'], OUT, 30, env)
        except v.VerificationError:
            pass
        receipt = json.loads((OUT / (name + '-test.json')).read_text())
        assert receipt['exitCode'] == expected_exit and not receipt['deadlineExceeded'] and receipt['processGroupStopped']
        rows = ET.parse(OUT / (name + '-results/results.trx')).findall('.//{*}UnitTestResult'); assert len(rows) == 1
        message = rows[0].findtext('.//{*}Message')
        assert rows[0].get('outcome') == ('Failed' if expected_exit else 'Passed')
        if expected_exit: assert 'Assert.All() Failure' in message and 'TimeoutException' not in message
        results.append({'variant': name, 'outcome': rows[0].get('outcome'), 'message': message})
        v.write_json(OUT / 'progress.json', results); print(name, rows[0].get('outcome'), flush=True)
finally:
    assert before == v.source_identity()
v.write_json(OUT / 'result.json', {'primaryInputsUnchanged': True, 'results': results,
    'qualification': 'Completed contexts/leases/public acquisition Tasks release is independently calibrated. Bare settlement-TCS leak2002 remains invisible to this oracle and unresolved; do not claim all work-ledger retention solved. Original mutation statuses unchanged.'})
