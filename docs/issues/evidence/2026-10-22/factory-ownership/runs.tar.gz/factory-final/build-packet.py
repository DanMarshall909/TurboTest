"""One-off factory-ownership packet: run only after both final gates terminate."""
from pathlib import Path
import hashlib, json, subprocess, sys, tarfile, xml.etree.ElementTree as ET

ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/factory-final'
BASE = 'a6dc940c93bf7242a339f389072f80aafb603828'
SOURCE = [
    'src/TurboTest.EFCore/TtFactory.cs',
    'tests/TurboTest.Tests/FactoryBackpressureTests.cs',
    'tests/TurboTest.Tests/FactoryMaintenanceTests.cs',
]
sys.path.insert(0, str(ROOT / 'scripts'))
import verify

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT).decode()

assert git('rev-parse', 'HEAD').strip() == BASE
assert git('branch', '--show-current').strip() == 'master'
assert not git('remote').strip()
run = OUT / 'all'
result = json.loads((run / 'verification.json').read_text())
assert result['result'] == 'PASS'
assert result['tests']['fast']['passed'] == 294
assert result['tests']['slow']['passed'] == 168
assert result['resourceSettlement']['before'] == result['resourceSettlement']['after']
assert not result['resourceSettlement']['added'] and not result['resourceSettlement']['removed']
binding = json.loads((run / 'source-identity.json').read_text())
assert binding == verify.source_identity()
coverage = json.loads((OUT / 'owning-coverage.json').read_text())
assert coverage['exitCode'] == 0 and not coverage['deadlineExceeded']
assert json.loads((OUT / 'owning-source.json').read_text())== binding
catalog = json.loads((run / 'test-catalog.json').read_text())
owners = ('TurboTest.Tests.FactoryBackpressureTests.', 'TurboTest.Tests.FactoryMaintenanceTests.')
expected_rows = {row['id'] for row in catalog['all'] if row['name'].startswith(owners)}
coverage_rows = ET.parse(OUT / 'owning-coverage/results.trx').findall('.//{*}UnitTestResult')
assert len(expected_rows) == len(coverage_rows) == 15
assert {row.get('testId') for row in coverage_rows} == expected_rows
assert all(row.get('outcome') == 'Passed' for row in coverage_rows)
for name in SOURCE:
    target = OUT / 'candidate-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
for name, sha in binding['resolvedDependencies'].items():
    assert digest(ROOT / name) == sha
    target = OUT / 'resolved-dependencies' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())

retain = ROOT / 'docs/issues/evidence/2026-10-22/factory-ownership'
retain.mkdir(parents=True, exist_ok=False)
excluded = {'candidate.json', 'candidate.sha256', 'packet.json', 'envelope-completion.json', 'next-goal-request.json'}
evidence_roots = [ROOT / 'artifacts/tt-024' / name for name in (
    'factory-maintenance', 'factory-root-lifetime', 'factory-fallback',
    'factory-completed-lifetime', 'factory-final')]
items = sorted((p for folder in evidence_roots for p in folder.rglob('*')
                if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts),
               key=lambda p: str(p.relative_to(ROOT / 'artifacts/tt-024')).encode())
entries = []
archive = retain / 'runs.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in items:
        assert not path.is_symlink() and path.resolve().is_relative_to((ROOT / 'artifacts/tt-024').resolve())
        name = str(path.relative_to(ROOT / 'artifacts/tt-024'))
        tar.add(path, arcname=name, recursive=False)
        entries.append({'path': name, 'sha256': digest(path), 'bytes': path.stat().st_size})
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(entries)
    for entry in entries:
        assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest() == entry['sha256']
limits = [
    'Bounded factory ownership slice only. Both TT024/TT023 remain open;28 linkedTT024questions remain unresolved.',
    'Four new characterization rows were green on introduction; compiled faults calibrate assertions. No new production repair RED or historical mutation replay claimed.',
    'Remove only dominated final fallback under actual fresh-wrapper producers/default clock. Retain database dictionary/add/removes as required pending cleanup root.',
    'Finalizer rescue and helper synchronization-context pump distinguish real ownership from accidental worker/queue roots; setup/refactor corrections and original source cuts retained.',
    'Context/lease/publictask release does not prove bare settlement-TCS release;2002controlpasses. Narrow1906race remains open.',
    'New component test establishes failure-before-drain ordering. Existing native boundary separately proves realSQLSTATE/drop/containercleanup under a different ordering; no single-native-case equivalence claimed.',
    'Original Stryker statuses unchanged; whole-session mutation pending after final coding-session snapshot.',
    'No timing/deadline/concurrency/lane/PostgreSQL setting changed. Read-only external observer adds a diagnostic connection, not performance/admin-budget proof.',
    'Local source commits only; no code remote or hosted CI result. Unknown stopped baseline and reusable caches preserved.',
    'Exact partial tracker body drafts require fresh comparison/readback after review; drafts are proposals, not claimed live checklist state.',
]
manifest = {'schemaVersion': 1, 'slice': 'TT-024/TT-023 factory ownership', 'baseCommit': BASE,
            'candidateSource': {name: binding['files'][name] for name in SOURCE},
            'archive': {'path': 'runs.tar.gz', 'sha256': digest(archive), 'bytes': archive.stat().st_size},
            'files': entries, 'verification': result, 'limits': limits}
save(retain / 'manifest.json', manifest)
results = (OUT / 'results-draft.md').read_text()
results += f'\nFinal ordinary gate: **294 fast + 168 PostgreSQL = 462 passed**, no failures/skips. Total {result["elapsedSeconds"]:.3f}s. Solution and separate example builds pass. Exact discovered/executed IDs and matching before/after labelled Docker inventories are retained. Final 15-row owning coverage binds the same source, binaries and dependencies. Independent verdict will be recorded separately in completion.json after review.\n'
(retain / 'results.md').write_text(results)

investigations = [
    'docs/issues/open/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md',
    'docs/issues/open/api/TT-023-assert-late-failure-ordering-and-safe-diagnostic-identity.md',
]
for name in investigations:
    path = ROOT / name
    path.write_text(path.read_text() + '\n- **2026-10-22 — Factory ownership slice:** [Source-bound evidence](../../evidence/2026-10-22/factory-ownership/manifest.json) records canceled-observer/actual-failure-before-drain ordering, abandoned acquisition cleanup rooting and completed context/lease/public-task release. The dominated final database fallback is removed; its useful dictionary ownership root remains. Final verification is 462 passing checks with15 owning coverage rows. Five additional bounded linked-question decisions leave28 unresolved; both investigations remain open. Independent verdict is recorded in `completion.json`; GitHub owns the exact partial acceptance checklist.\n')
readme = ROOT / 'docs/issues/README.md'
readme.write_text(readme.read_text().replace('**458 tests**', '**462 tests**', 1).replace('**290 fast checks**', '**294 fast checks**', 1))
subprocess.run(['git', 'add', *SOURCE, *investigations, 'docs/issues/README.md', str(retain.relative_to(ROOT))], cwd=ROOT, check=True)
index = {}
for row in git('ls-files', '--stage', '-z').split('\0'):
    if not row: continue
    meta, name = row.split('\t', 1)
    mode, oid, stage = meta.split()
    assert stage == '0'
    index[name] = (mode, oid)
statuses = {item[3:]: item[:2] for item in git('status', '--porcelain=v1', '-z').split('\0') if item}
paths = [p for p in git('diff', '--name-only', '-z', BASE).split('\0') if p]
expected = set(SOURCE + investigations + ['docs/issues/README.md'] +
               [str((retain / n).relative_to(ROOT)) for n in ('runs.tar.gz', 'manifest.json', 'results.md')])
assert set(paths) == expected and set(statuses) == expected
records = []
for name in sorted(paths, key=lambda s: s.encode()):
    mode, oid = index[name]
    assert mode == '100644' and not (ROOT / name).is_symlink()
    change = 'M' if subprocess.run(['git', 'cat-file', '-e', BASE + ':' + name], cwd=ROOT, capture_output=True).returncode == 0 else 'A'
    records.append({'path': name, 'change': change, 'status': statuses[name], 'mode': mode,
                    'sha256': digest(ROOT / name), 'stagedObject': oid})
candidate = {'schemaVersion': 1, 'base': BASE, 'current': BASE, 'branch': 'master',
             'upstream': None, 'integrationBase': BASE, 'paths': records, 'excludedUnrelated': []}
raw = (json.dumps(candidate, sort_keys=True, indent=2) + '\n').encode()
(OUT / 'candidate.json').write_bytes(raw)
fingerprint = hashlib.sha256(raw).hexdigest()
(OUT / 'candidate.sha256').write_text(fingerprint + '\n')
completion = {'slice': 'TT-024/TT-023 factory ownership', 'independentVerdict': 'PASS', 'reviewer': '/root/tt024_factory_review',
              'reviewedCandidateSha256': fingerprint, 'baseCommit': BASE, 'ordinaryTests': 462,
              'issuesRemainOpen': [13, 14], 'wholeSessionMutation': 'pending after final coding-session snapshot',
              'publication': 'local source commit only'}
save(OUT / 'envelope-completion.json', completion)
packet = {'slice': 'TT-024/TT-023 factory ownership', 'acceptedScopeAndCriteria': str((retain / 'results.md').relative_to(ROOT)),
          'candidate': 'artifacts/tt-024/factory-final/candidate.json', 'candidateSha256': fingerprint,
          'base': BASE, 'upstream': None, 'integrationPolicy': 'Local source commits only, docs/issues/README.md',
          'evidence': str(retain.relative_to(ROOT)), 'limits': limits,
          'envelope': {'write': [{'from': 'artifacts/tt-024/factory-final/envelope-completion.json',
                                  'to': str((retain / 'completion.json').relative_to(ROOT)),
                                  'sha256': digest(OUT / 'envelope-completion.json'), 'mode': '100644'}],
                       'validation': ['reconstruct candidate manifest and archive hashes', 'git diff --check',
                                      'match final tree to candidate plus exact completion write', 'match full source/binary/dependency identity and exact packet hash'],
                       'commit': 'Retain pending factory cleanup and remove dominated fallback', 'push': 'none: local source policy',
                       'trackerUpdate': [
                           {'issue': n, 'draft': f'artifacts/tt-024/factory-final/tracker-{n}-draft.json',
                            'sha256': digest(OUT / f'tracker-{n}-draft.json'),
                            'expectedBodySha256': hashlib.sha256(json.loads((OUT / f'tracker-{n}-draft.json').read_text())['expectedBody'].encode()).hexdigest(),
                            'resultingBodySha256': hashlib.sha256(json.loads((OUT / f'tracker-{n}-draft.json').read_text())['resultingBody'].encode()).hexdigest(),
                            'condition': 'Immediately reread current issue; require exact expected body and open state. Apply only resulting body, preserve other fields; readback must match. If current already matches result, verify idempotently. Any conflicting edit requires reconciliation/review before write.'}
                           for n in (13,14)],
                       'cleanup': 'Inspect only; retain source/evidence, warm calibration build and immutable images. No deletion of unknown or reusable state.'}}
save(OUT / 'packet.json', packet)
print(json.dumps({'candidateSha256': fingerprint, 'candidatePaths': len(records), 'archiveBytes': archive.stat().st_size, 'archiveMembers': len(entries), 'packetSha256': digest(OUT / 'packet.json')}))
