"""One-off finite envelope. Invoke only after independent PASS is retained."""
from pathlib import Path
import hashlib, json, os, stat, subprocess, sys, tarfile

ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/factory-final'
os.chdir(ROOT)
def git(*args):
    return subprocess.check_output(['git', *args]).decode()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

packet = json.loads((OUT / 'packet.json').read_text())
raw = (OUT / 'candidate.json').read_bytes()
fingerprint = hashlib.sha256(raw).hexdigest()
assert fingerprint == packet['candidateSha256']
candidate = json.loads(raw)
approval = json.loads((OUT / 'independent-pass.json').read_text())
assert approval['verdict'] == 'PASS'
assert sha(OUT / 'packet.json') == approval['packetSha256']
assert approval['reviewer'] == '/root/tt024_factory_review'
assert approval['candidateSha256'] == fingerprint
assert git('rev-parse', 'HEAD').strip() == candidate['base']
assert git('branch', '--show-current').strip() == candidate['branch']
assert candidate['upstream'] is None and not git('remote').strip()
assert not git('ls-files', '--unmerged').strip()
sys.path.insert(0, str(ROOT / 'scripts'))
import verify
assert json.loads((OUT / 'all/source-identity.json').read_text()) == verify.source_identity()
for update in packet['envelope']['trackerUpdate']:
    assert sha(ROOT / update['draft']) == update['sha256']

def index():
    result = {}
    for row in git('ls-files', '--stage', '-z').split('\0'):
        if not row: continue
        meta, name = row.split('\t', 1)
        mode, oid, stage = meta.split()
        assert stage == '0'
        result[name] = (mode, oid)
    return result

def statuses():
    return {row[3:]: row[:2] for row in git('status', '--porcelain=v1', '-z').split('\0') if row}

entries = {row['path']: row for row in candidate['paths']}
assert set(statuses()) == set(entries)
current = index()
for name, row in entries.items():
    path = ROOT / name
    mode = path.lstat().st_mode
    assert stat.S_ISREG(mode) and not mode & 0o111
    assert current[name] == (row['mode'], row['stagedObject'])
    assert sha(path) == row['sha256'] and statuses()[name] == row['status']
    assert git('hash-object', name).strip() == row['stagedObject']
manifest = json.loads((ROOT / packet['evidence'] / 'manifest.json').read_text())
archive = ROOT / packet['evidence'] / manifest['archive']['path']
assert sha(archive) == manifest['archive']['sha256']
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(manifest['files'])
    for entry in manifest['files']:
        assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest() == entry['sha256']
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)

writes = packet['envelope']['write']
assert len(writes) == 1
write = writes[0]
source = ROOT / write['from']
target = ROOT / write['to']
assert write['mode'] == '100644' and sha(source) == write['sha256']
assert not target.exists()
target.write_bytes(source.read_bytes())
subprocess.run(['git', 'add', write['to']], check=True)
assert set(statuses()) == set(entries) | {write['to']}
assert set(git('diff', '--name-only', '-z', candidate['base']).split('\0')) - {''} == set(statuses())
assert sha(target) == write['sha256'] and index()[write['to']][0] == '100644'
for name, row in entries.items():
    assert sha(ROOT / name) == row['sha256']
    assert index()[name] == (row['mode'], row['stagedObject'])
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
subprocess.run(['git', 'commit', '-m', packet['envelope']['commit']], check=True)
commit = git('rev-parse', 'HEAD').strip()
assert not statuses()
assert git('rev-parse', 'HEAD^').strip() == candidate['base']
assert set(git('diff-tree', '--no-commit-id', '--name-only', '-r', commit).splitlines()) == set(entries) | {write['to']}
for name, row in entries.items():
    assert sha(ROOT / name) == row['sha256']
    assert git('rev-parse', 'HEAD:' + name).strip() == row['stagedObject']
save(OUT / 'publication.json', {'commit': commit, 'candidateSha256': fingerprint,
     'independentVerdict': 'PASS', 'paths': len(entries) + 1,
     'scope': 'Local source commit only; issues13/14 remain open',
     'cleanup': 'Inspect only; no unknown or reusable resources deleted'})
print(json.dumps({'commit': commit, 'paths': len(entries) + 1, 'clean': True}))
