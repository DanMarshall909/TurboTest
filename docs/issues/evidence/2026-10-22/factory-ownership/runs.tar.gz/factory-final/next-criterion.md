# Next criterion: undelivered failure versus canceled observer finally (1906)

Planning capsule only. No executable evidence or resolution for 1906 is claimed.
The current maintained ordering test fully finishes observation cancellation
before completing actual work; that intentionally does not cover this race.

Use a bounded test synchronization context and the existing real-slot maintenance
fixture. Candidate deterministic schedule, to calibrate against compiled 1906:

1. Warm fixture; start factory maintenance under the queued context. Actual
   deletion is held, so no owner continuation can run yet.
2. Cancel caller observation. Take the single newly posted cancellation observer
   callback from the test-owned queue and hold it without executing. This uses
   causal scheduling, not opaque callback identity or factory collection counts.
3. Release actual deletion. Pump its callback/retirement completion until the
   underlying actual maintenance task faults. Execute the next posted owner
   worker continuation through return: it records its failure before observer
   finally. Confirm the original observation task is still pending.
4. Execute the held observer continuation; it reports cancellation. Only now
   restore normal continuation dispatch and begin factory drain.
5. Drain must report the original safe SlotIdleRetire failure and confirm cleanup.
   Compiled 1906 instead removes that still-undelivered work during observer
   finally, so drain wrongly succeeds. Release/join all actual jobs in finally.

The exact posted-callback assumptions must be checked against the current
component producer and independently fault calibrated; this proposal is not
proof that the schedule already works. Extracting the narrowly scoped existing
CleanupPump into shared test-only continuation control may remove duplication.
Do not add a production seam or retain external strong release gates for GC
tests. Run the canonical fast gate after the refactor/criterion.

## Later private-node investigation

Independent source review separates useful cleanup from public payload lifetime:

| Question | Bounded source effect |
| --- | --- |
| 1902 | Retains completed maintenance observer settlement TCS; stale membership also prevents late successful worker cleanup |
| 2002 | Retains completed acquisition settlement TCS; public context/lease/task collection can still pass |
| 1905 / 1907 | Suppress observer removal: success never marks Delivered; delivered failure is non-null |
| 1925 / 1927 | Suppress worker removal: Completion is first signalled and predicate checked under the same lock, before observer can set Delivered |
| 1906 | Also retains success, and can remove a failure not delivered because cancellation won before observer finally |
| 2055 | Retains previously unseen maintenance work after drain reports it; cached drain still prevents repeat reporting |

Pairwise suppression equivalences are only to each other, never to baseline.
For a bounded one-off diagnostic, capture weak references to existing private
nodes while operation is held (reflection only for capture under existing lock),
drop all enumerators/strong frames, pump owner continuations through return,
then collect with factory alive. Assert public results, exact ledger/deletion
settlement independently. Keep these structural experiments out of maintained
behavior tests and do not claim permanent mutation regression coverage from them.
No such diagnostic has run yet. All eight node/race questions remain open.
