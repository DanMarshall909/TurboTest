"""One-off source-bound maintenance ownership/error calibration."""
from pathlib import Path
import hashlib, importlib.util, json, os, xml.etree.ElementTree as ET
ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/factory-maintenance/calibration'
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('verify', ROOT / 'scripts/verify.py')
v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
before = v.source_identity()
build = ROOT / 'artifacts/tt-024/lifetimes/calibration-build'
source = ROOT / 'src/TurboTest.EFCore/TtFactory.cs'
original = source.read_text()
fault = OUT / 'fault.cs'; targets = OUT / 'Fault.targets'; compiled = OUT / 'compile-inputs.txt'
tracking = '            _maintenance.Add(work);'
drain = '            catch (Exception error) { first = first is null ? error : new AggregateException(first, error); }\n        }\n        if (first is not null) throw first;'
assert original.count(tracking) == original.count(drain) == 1
variants = {
    'missing-maintenance-owner': (original.replace(tracking, '            ;'), 2),
    'lost-secondary-drain-failure': (original.replace(drain, drain.replace('first = first is null ? error : new AggregateException(first, error)', 'first ??= error')), 1),
}
env = dict(os.environ, DOTNET_CLI_USE_MSBUILD_SERVER='0', MSBUILDDISABLENODEREUSE='1')
results = []
try:
    for name, (text, count) in variants.items():
        fault.write_text(text)
        (OUT / (name + '-source.cs')).write_text(text)
        targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="TtFactory.cs" /><Compile Include="{fault}" /></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{compiled}" Lines="@(Compile->'%(FullPath)')" Overwrite="true" /></Target></Project>''')
        v.run_phase(name + '-build', ['dotnet', 'build', 'tests/TurboTest.Tests/TurboTest.Tests.csproj', '--no-restore', '-c', 'Release', '--artifacts-path', str(build), '-p:CustomBeforeMicrosoftCommonTargets=' + str(targets), '-nr:false', '-p:UseSharedCompilation=false', '--verbosity', 'minimal'], OUT, 120, env)
        inputs = compiled.read_text().splitlines()
        assert str(fault) in inputs and str(source) not in inputs
        (OUT / (name + '-compile-inputs.txt')).write_text(compiled.read_text())
        dll = build / 'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
        v.write_json(OUT / (name + '-binding.json'), {
            'source': str(source), 'sourceSha256': hashlib.sha256(original.encode()).hexdigest(),
            'faultSha256': hashlib.sha256(text.encode()).hexdigest(),
            'compiledInputs': {str(p.relative_to(build)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in sorted(dll.parent.rglob('*')) if p.is_file() and
                (p.suffix == '.dll' or p.name.endswith(('.deps.json', '.runtimeconfig.json')))}})
        try:
            v.run_phase(name + '-test', ['dotnet', 'test', str(dll), '--filter',
                'FullyQualifiedName~Canceled_observation_retains_an_already_completed_maintenance_failure_until_drain',
                '--results-directory', str(OUT / (name + '-results')), '--logger', 'trx;LogFileName=results.trx'], OUT, 30, env)
        except v.VerificationError:
            pass
        receipt = json.loads((OUT / (name + '-test.json')).read_text())
        assert receipt['exitCode'] == 1 and not receipt['deadlineExceeded'] and receipt['processGroupStopped']
        rows = ET.parse(OUT / (name + '-results/results.trx')).findall('.//{*}UnitTestResult')
        assert len(rows) == 2
        failures = [{'name': row.get('testName'), 'message': row.findtext('.//{*}Message')}
            for row in rows if row.get('outcome') == 'Failed']
        assert len(failures) == count and all('Assert.' in f['message'] and 'TimeoutException' not in f['message'] for f in failures)
        if name == 'lost-secondary-drain-failure':
            assert 'failDrain: True' in failures[0]['name']
        results.append({'fault': name, 'namedFailures': failures})
        v.write_json(OUT / 'progress.json', results)
        print(name, 'rejected by', count, 'named assertion(s)', flush=True)
finally:
    assert before == v.source_identity()
v.write_json(OUT / 'result.json', {'primaryInputsUnchanged': True, 'results': results,
    'qualification': 'Bounded compiled source-substitution faults only. New tests characterize existing behavior; original mutation statuses are unchanged. No new production repair RED or whole-session mutation claim.'})
