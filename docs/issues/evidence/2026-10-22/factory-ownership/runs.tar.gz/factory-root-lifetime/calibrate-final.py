"""One-off distinguish pending ownership root from dominated final fallback."""
from pathlib import Path
import hashlib, importlib.util, json, os, xml.etree.ElementTree as ET
ROOT = Path('/home/dan/code/TurboTest'); OUT = ROOT / 'artifacts/tt-024/factory-root-lifetime/calibration-final'
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('verify', ROOT / 'scripts/verify.py')
v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
before = v.source_identity(); build = ROOT / 'artifacts/tt-024/lifetimes/calibration-build'
source = ROOT / 'src/TurboTest.EFCore/TtFactory.cs'; original = source.read_text()
fault = OUT / 'fault.cs'; targets = OUT / 'Fault.targets'; compiled = OUT / 'compile-inputs.txt'
add = '            _databases.TryAdd(database, 0);'
fallback = '''        foreach (var database in _databases.Keys)
        {
            try { await database.DisposeAsync(); }
            catch (Exception error) { first = first is null ? error : new AggregateException(first, error); }
        }
'''
assert original.count(add) == 1 and original.count(fallback) == 0
variants = {'1941-remove-root': (original.replace(add, '            ;'), 1),
            'final-unmodified-control': (original, 0)}
env = dict(os.environ, DOTNET_CLI_USE_MSBUILD_SERVER='0', MSBUILDDISABLENODEREUSE='1'); results = []
try:
    for name, (text, expected_exit) in variants.items():
        fault.write_text(text); (OUT / (name + '-source.cs')).write_text(text)
        targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="TtFactory.cs" /><Compile Include="{fault}" /></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{compiled}" Lines="@(Compile->'%(FullPath)')" Overwrite="true" /></Target></Project>''')
        v.run_phase(name + '-build', ['dotnet', 'build', 'tests/TurboTest.Tests/TurboTest.Tests.csproj', '--no-restore', '-c', 'Release', '--artifacts-path', str(build), '-p:CustomBeforeMicrosoftCommonTargets=' + str(targets), '-nr:false', '-p:UseSharedCompilation=false', '--verbosity', 'minimal'], OUT, 120, env)
        inputs = compiled.read_text().splitlines(); assert str(fault) in inputs and str(source) not in inputs
        (OUT / (name + '-compile-inputs.txt')).write_text(compiled.read_text())
        dll = build / 'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
        v.write_json(OUT / (name + '-binding.json'), {'source': str(source),
            'sourceSha256': hashlib.sha256(original.encode()).hexdigest(), 'faultSha256': hashlib.sha256(text.encode()).hexdigest(),
            'compiledInputs': {str(p.relative_to(build)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*'))
                if p.is_file() and (p.suffix == '.dll' or p.name.endswith(('.deps.json', '.runtimeconfig.json')))}})
        try:
            v.run_phase(name + '-test', ['dotnet', 'test', str(dll), '--filter', 'FullyQualifiedName~An_abandoned_acquisition_keeps',
                '--results-directory', str(OUT / (name + '-results')), '--logger', 'trx;LogFileName=results.trx'], OUT, 30, env)
        except v.VerificationError:
            pass
        receipt = json.loads((OUT / (name + '-test.json')).read_text())
        assert receipt['exitCode'] == expected_exit and not receipt['deadlineExceeded'] and receipt['processGroupStopped']
        rows = ET.parse(OUT / (name + '-results/results.trx')).findall('.//{*}UnitTestResult'); assert len(rows) == 1
        message = rows[0].findtext('.//{*}Message')
        assert rows[0].get('outcome') == ('Failed' if expected_exit else 'Passed')
        if expected_exit: assert 'Assert.Null() Failure' in message and 'TimeoutException' not in message
        results.append({'variant': name, 'outcome': rows[0].get('outcome'), 'message': message})
        v.write_json(OUT / 'progress.json', results); print(name, rows[0].get('outcome'), flush=True)
finally:
    assert before == v.source_identity()
v.write_json(OUT / 'result.json', {'primaryInputsUnchanged': True, 'results': results,
    'qualification': '1941 removal permits premature context finalization; finalizer rescue preserves actual cleanup joins. Final unmodified source passes; prior fallback-only control is retained separately, not global equivalence proof. Original mutation statuses unchanged; no whole-session mutation claim.'})
