"""Freeze exact TT024 whole-investigation closure candidate and finite archive envelope."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/final-questions';BASE='5f827c3de97b5979eb57cf7a36bed350ee8b3a3b'
SOURCE=['src/TurboTest.EFCore/Internal/TtSlotPool.cs','src/TurboTest.EFCore/TtOptions.cs','tests/TurboTest.Tests/AdaptiveSlotTests.cs','tests/TurboTest.Tests/FactoryBackpressureTests.cs','tests/TurboTest.Tests/TurboTest.Tests.csproj']
MEASURED=SOURCE+['src/TurboTest.EFCore/Internal/TtOwnedContextOptions.cs','src/TurboTest.EFCore/Internal/TtCapacityPolicy.cs']
OLD='docs/issues/open/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md'
NEW='docs/issues/resolved/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md'
os.chdir(ROOT);sys.path.insert(0,str(ROOT/'scripts'));import verify
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args]).decode()
assert git('rev-parse','HEAD').strip()==BASE and git('branch','--show-current').strip()=='master'
assert not git('remote').strip() and len(git('worktree','list','--porcelain').split('worktree '))==2
assert not (ROOT/NEW).exists()
run=OUT/'final-all';result=json.loads((run/'verification.json').read_text());assert result['result']=='PASS'
assert result['tests']['fast']['passed']==317 and result['tests']['slow']['passed']==170
assert result['resourceSettlement']['before']==result['resourceSettlement']['after'] and not result['resourceSettlement']['added'] and not result['resourceSettlement']['removed']
binding=json.loads((run/'source-identity.json').read_text());assert binding==verify.source_identity()==json.loads((OUT/'owning-source.json').read_text())
owning=json.loads((OUT/'owning-coverage.json').read_text());assert owning['exitCode']==0 and not owning['deadlineExceeded'] and owning['processGroupStopped']
assert json.loads((OUT/'owning-resource-settlement.json').read_text())['equal']
catalog=json.loads((run/'test-catalog.json').read_text());fast={r['id'] for r in catalog['fast']}
owners=tuple('TurboTest.Tests.'+n+'.' for n in ['OrdinaryRecoveryTests','PreparedDrainRetryTests','PreparedRewarmRecoveryTests','PreparedMaintenanceDrainTests','PreparedRetentionTests'])
method='Failed_startup_retains_exact_cleanup_ownership_and_supports_explicit_or_global_retry'
expected=fast|{r['id'] for r in catalog['all'] if r['name'].startswith(owners) or method in r['name']}
rows=E.parse(OUT/'owning-coverage/results.trx').findall('.//{*}UnitTestResult');assert len(expected)==len(rows)==338
assert {r.get('testId') for r in rows}==expected and all(r.get('outcome')=='Passed' for r in rows)
assert len(expected-fast)==21
for name,controls in [('provider',3),('held',10),('expiry-1208',6),('expiry-1211',6)]:
    c=OUT/('final-'+name+'-calibration');r=json.loads((c/'result.json').read_text())
    assert len(r['failed'])==1 and r['controlsPassed']==controls and r['primaryInputsUnchanged']
    assert json.loads((c/'binding.json').read_text())['sourceIdentity']==binding
assert json.loads((OUT/'restored-calibration-build/result.json').read_text())['restoredFinalOriginalProductInputs']
q=json.loads((OUT/'question-dispositions-candidate.json').read_text());original=json.loads((OUT/'original-question-source.json').read_text())
assert q['count']==len(q['entries'])==48 and q['remainingQuestions']==0
assert {r['key']:r['originalStatus'] for r in q['entries']}=={r['key']:r['status'] for r in original['entries']}
prior=json.loads((OUT/'prior-evidence-revalidation.json').read_text());assert len(prior['packets'])==8 and prior['totalMembers']==2992
for name in MEASURED:
    assert sha(ROOT/name)==binding['files'][name]
    p=OUT/'candidate-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
for name,digest in binding['resolvedDependencies'].items():
    assert sha(ROOT/name)==digest
    p=OUT/'resolved-dependencies'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
retain=ROOT/'docs/issues/evidence/2026-10-22/final-question-closure';retain.mkdir(parents=True,exist_ok=False)
excluded={'candidate.json','candidate.sha256','packet.json','envelope-completion.json','independent-pass.json','publication.json','tracker-receipt.json','final-inspection.json'}
items=sorted((p for p in OUT.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts),key=lambda p:str(p.relative_to(ROOT/'artifacts/tt-024')).encode())
entries=[];archive=retain/'runs.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for p in items:
        assert not p.is_symlink() and p.resolve().is_relative_to(OUT.resolve())
        name=str(p.relative_to(ROOT/'artifacts/tt-024'));t.add(p,arcname=name,recursive=False);entries.append({'path':name,'sha256':sha(p),'bytes':p.stat().st_size})
with tarfile.open(archive) as t:
    assert len(t.getmembers())==len(entries)
    for r in entries:assert hashlib.sha256(t.extractfile(r['path']).read()).hexdigest()==r['sha256']
limits=[
    'Whole TT024 investigation closure:44prior+4final bounded decisions reconcile all48original identities/statuses;7issue clauses explicitly mapped. Generated mutants are not automatically product defects.',
    'Three characterization tests protect genuine alternate-provider diagnostics and explicitly selected Held-no-physical-work/explicit-maintenance cadence. No functional production code or product-defect RED.',
    'Final exact466/1202/1208/1211faults fail intended assertions with3/10/6/6controls. Nullable-park OR orphan is a separate source-level distinction, not claimed runtime calibration; no suite/mutation exclusion introduced.',
    'New EFInMemory10.0.12 dependency test-only with positive actual save/query; production resolved/package graph unchanged. Not a relational/PostgreSQL stand-in or SQL Server support feature.',
    'Final owning338=317fast+21native andfull487=317fast+170native bind identical source/runtime/dependency inputs. Exact discovery/execution IDs, stopped owned process groups and equal resource inventories retained.',
    'Eight prior independentPASS packets/all2992members revalidated without relabelling historical source cuts. Public16cycle payload/registration laws and45oneoff private-node rows remain distinct.',
    '2218 only successful-callback/actual-drain disposal;1691 internal owner/deletion-adapter law;2096 legitimate observer-domain model, not deterministic native schedule. No universal leak/memory-growth/failure-exit guarantee;TT023 retains separate scope.',
    'Actual producer simplifications remain bounded to current callers/default or nonreentrant clocks; arbitrary internal reentry/corruption/fatal allocation excluded. Useful dictionary root and disposal/retry retained.',
    'Whole-session mutation pending final coding-session snapshot; historical mutation statuses unchanged. Ordinary local gate does not claim hostedCI or fresh mutation adequacy.',
    'Exact postPASS completion write and investigation archive mapping only, local commit then conditional issue14checklist/body/state closure/readback. No code remote/push. Native Project fields unavailable/unmodified; inspect-only cleanup retains unknown baseline/caches/evidence.'
]
save(retain/'manifest.json',{'schemaVersion':1,'slice':'TT024 final bounded investigation and closure','baseCommit':BASE,'candidateSource':{n:binding['files'][n] for n in MEASURED},'archive':{'path':'runs.tar.gz','sha256':sha(archive),'bytes':archive.stat().st_size},'files':entries,'verification':result,'priorEvidence':prior['packets'],'limits':limits})
text=(OUT/'results-draft.md').read_text()+f'\n## Final integrated ordinary gate\n\n**317 fast + 170 PostgreSQL = 487 passed**, no failures/skips. Total {result["elapsedSeconds"]:.3f}s. Solution and separate example builds pass without warnings/errors. Final owning coverage passes **338 rows (317 fast,21native)** on identical source/runtime/dependency inputs. Exact discovery/execution IDs and resource inventories match. The independent whole-ticket verdict is in `completion.json`.\n'
(retain/'results.md').write_text(text)
p=ROOT/OLD;p.write_text(p.read_text()+'\n- **2026-10-22 — Final bounded investigation and archive decision:** [Integrated closure evidence](../../evidence/2026-10-22/final-question-closure/manifest.json) reconciles all48 original question identities:44 prior accepted decisions and466/1202/1208/1211 final contracts. Genuine alternate-provider rejection and explicit Held/no-physical-work versus idle-maintenance cadence are characterized and calibrated; useful guards remain. All7 acceptance clauses have bounded evidence with public lifetime/oneoff diagnostic and successful-callback/nonreentrant-domain limits preserved. Final verification is487 ordinary passes and338 owning coverage rows; eight prior archives/all2992members revalidated. The exact independent whole-ticket verdict in `completion.json` authorizes archival of this investigation and issue checklist/state closure. Historical mutation statuses remain unchanged; whole-session mutation is pending after the final coding snapshot. TT023 remains open for its separate scope; native Project fields remain unverified/unmodified. GitHub owns live workflow status.\n')
p=ROOT/'docs/issues/README.md';old=p.read_text();new=old.replace('**484 tests**','**487 tests**',1).replace('**314 fast checks**','**317 fast checks**',1).replace('(open/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md)','(resolved/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md)',1);assert new!=old;p.write_text(new)
subprocess.run(['git','add',*SOURCE,'README.md',OLD,'docs/issues/README.md',str(retain.relative_to(ROOT))],check=True)
index={}
for r in git('ls-files','--stage','-z').split('\0'):
    if not r:continue
    meta,n=r.split('\t',1);mode,oid,stage=meta.split();assert stage=='0';index[n]=(mode,oid)
statuses={r[3:]:r[:2] for r in git('status','--porcelain=v1','--no-renames','-z').split('\0') if r}
paths=[p for p in git('diff','--name-only','--no-renames','-z',BASE).split('\0') if p]
expected=set(SOURCE+['README.md',OLD,'docs/issues/README.md']+[str((retain/n).relative_to(ROOT)) for n in ['runs.tar.gz','manifest.json','results.md']]);assert set(paths)==set(statuses)==expected
records=[]
for n in sorted(paths,key=lambda s:s.encode()):
    mode,oid=index[n];assert mode=='100644' and not (ROOT/n).is_symlink()
    change='M' if subprocess.run(['git','cat-file','-e',BASE+':'+n],capture_output=True).returncode==0 else 'A'
    records.append({'path':n,'change':change,'status':statuses[n],'mode':mode,'sha256':sha(ROOT/n),'stagedObject':oid})
candidate={'schemaVersion':1,'base':BASE,'current':BASE,'branch':'master','upstream':None,'integrationBase':BASE,'paths':records,'excludedUnrelated':[]}
raw=(json.dumps(candidate,sort_keys=True,indent=2)+'\n').encode();(OUT/'candidate.json').write_bytes(raw);fingerprint=hashlib.sha256(raw).hexdigest();(OUT/'candidate.sha256').write_text(fingerprint+'\n')
save(OUT/'envelope-completion.json',{'slice':'TT024 final bounded investigation and closure','independentVerdict':'PASS','reviewer':'/root/tt024_closure_review','reviewedCandidateSha256':fingerprint,'baseCommit':BASE,'ordinaryTests':487,'owningCoverageRows':338,'boundedQuestionDispositions':48,'issueClosure':[14],'wholeSessionMutation':'pending after final coding-session snapshot','publication':'local source commit only; native Project fields unverified/unmodified'})
d=json.loads((OUT/'tracker-14-draft.json').read_text())
packet={'slice':'TT024 final bounded investigation and closure','wholeTicketClosure':True,'acceptedScopeAndCriteria':str((retain/'results.md').relative_to(ROOT)),'candidate':str((OUT/'candidate.json').relative_to(ROOT)),'candidateSha256':fingerprint,'base':BASE,'upstream':None,'integrationPolicy':'Local source commits only, docs/issues/README.md','evidence':str(retain.relative_to(ROOT)),'limits':limits,'envelope':{'write':[{'from':str((OUT/'envelope-completion.json').relative_to(ROOT)),'to':str((retain/'completion.json').relative_to(ROOT)),'sha256':sha(OUT/'envelope-completion.json'),'mode':'100644'}],'archive':[{'from':OLD,'to':NEW,'sha256':sha(ROOT/OLD),'mode':'100644'}],'validation':['reconstruct exact candidate, allarchive hashes and48identity/status map','git diff --check','match final complete tree to candidate plus exact completion write/archive mapping','match full source/runtime/dependency identity and exact packet/finalizer hashes'],'commit':'Resolve TT024 provider and capacity ownership contracts','push':'none: local source policy','trackerUpdate':[{'issue':14,'draft':str((OUT/'tracker-14-draft.json').relative_to(ROOT)),'sha256':sha(OUT/'tracker-14-draft.json'),'expectedBodySha256':hashlib.sha256(d['expectedBody'].encode()).hexdigest(),'resultingBodySha256':hashlib.sha256(d['resultingBody'].encode()).hexdigest(),'expectedState':'open','resultingState':'closed','stateReason':'completed','condition':'Fresh issue must equal exact expectedBody/open, then apply only resultingBody plus closed/completed state preserving all other fields; independent exact body/checklist/state readback. Already-result is idempotent; concurrent conflicts require reconciliation/review.'}],'project':'Native fields unavailable/unmodified; no Done/Order claim','cleanup':'Inspect only; preserve unknown stopped baseline, reusable caches and evidence. No deletions.'},'finalizer':{'path':str((OUT/'finalize.py').relative_to(ROOT)),'sha256':sha(OUT/'finalize.py')}}
save(OUT/'packet.json',packet)
print(json.dumps({'candidateSha256':fingerprint,'paths':len(records),'archiveMembers':len(entries),'archiveBytes':archive.stat().st_size,'packetSha256':sha(OUT/'packet.json'),'finalizerSha256':sha(OUT/'finalize.py')}))
