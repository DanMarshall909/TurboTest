"""Bounded original466 valid alternate-provider fault; isolated compiled outputs, no historical replay."""
from pathlib import Path
import hashlib,importlib.util,json,os,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest'); OUT=ROOT/'artifacts/tt-024/final-questions/provider-calibration'
OUT.mkdir()
s=importlib.util.spec_from_file_location('v',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
before=v.source_identity();source=ROOT/'src/TurboTest.EFCore/Internal/TtOwnedContextOptions.cs';original=source.read_text()
old='.SingleOrDefault()?.DataSource;'
assert original.count(old)==1
fault=OUT/source.name;fault.write_text(original.replace(old,'.Single()?.DataSource;'))
targets=OUT/'Fault.targets'
targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="Internal/TtOwnedContextOptions.cs"/><Compile Include="{fault}"/></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore' Or '$(MSBuildProjectName)' == 'TurboTest.Tests'"><WriteLinesToFile File="{OUT}/$(MSBuildProjectName)-compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
build=ROOT/'artifacts/tt-024/lifetimes/calibration-build';env=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1')
v.run_phase('restore',['dotnet','restore',v.PROJECT,'--artifacts-path',str(build)],OUT,180,env)
v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],OUT,180,env)
product=(OUT/'TurboTest.EFCore-compile.txt').read_text().splitlines();tests=(OUT/'TurboTest.Tests-compile.txt').read_text().splitlines()
assert str(fault) in product and str(source) not in product
assert not any('PrivateNodeProbe.cs' in p for p in tests)
dll=build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
v.write_json(OUT/'binding.json',{'sourceIdentity':before,'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'faultSha256':hashlib.sha256(fault.read_bytes()).hexdigest(),'productCompile':product,'testCompile':tests,'compiledInputs':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*')) if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
try:v.run_phase('test',['dotnet','test',str(dll),'--filter','FullyQualifiedName~A_valid_alternate_provider|FullyQualifiedName~Ordinary_contexts_cannot_replace_their_fixture_owned_source|FullyQualifiedName~An_additional_context_is_validated_before_it_can_escape','--results-directory',str(OUT/'results'),'--logger','trx;LogFileName=results.trx'],OUT,30,env)
except v.VerificationError:pass
r=json.loads((OUT/'test.json').read_text());assert r['exitCode']==1 and not r['deadlineExceeded'] and r['processGroupStopped']
rows=E.parse(OUT/'results/results.trx').findall('.//{*}UnitTestResult');assert len(rows)==4
failed=[{'name':r.get('testName'),'message':r.findtext('.//{*}Message')} for r in rows if r.get('outcome')=='Failed']
assert len(failed)==1 and 'A_valid_alternate_provider' in failed[0]['name']
assert 'ContextConfiguration' in failed[0]['message'] and 'ContextInitialize' in failed[0]['message'] and 'TimeoutException' not in failed[0]['message']
assert before==v.source_identity() and source.read_text()==original
v.write_json(OUT/'result.json',{'question':466,'failed':failed,'controlsPassed':3,'primaryInputsUnchanged':True,'qualification':'Exact SingleOrDefault to Single substitution reaches a genuine provider with working independent store/model; safe lifecycle Stage distinguishes. Not a relational stand-in or historical mutation replay'})
print('466 intended safe Stage assertion rejected fault;3controls passed',flush=True)
