using Microsoft.Extensions.Logging;

namespace TurboTest.EFCore;

/// <summary>
/// Configuration options for TurboTest. Can be configured via IConfiguration, IOptions, or directly.
/// </summary>
public class TtOptions
{
    internal TtOptions Snapshot() => (TtOptions)MemberwiseClone();
    /// <summary>
    /// Configuration section name for IConfiguration binding
    /// </summary>
    public const string SectionName = "TurboTest";

    /// <summary>
    /// The database provider to use. Currently only PostgreSQL is supported.
    /// Can be configured via "TurboTest:Provider" in appsettings.json
    /// </summary>
    public TtDatabaseProvider Provider { get; set; } = TtDatabaseProvider.PostgreSql;

    /// <summary>
    /// Fixed physical workload-slot cap, including preparing, leased and resetting
    /// slots. Ordinary factories use one container per slot; baseline factories
    /// use several slots on one host. Defaults to 3. Acquisitions wait at capacity.
    /// Can be configured via "TurboTest:PoolSize" in appsettings.json
    /// </summary>
    public int PoolSize { get; set; } = 3;

    /// <summary>Initial prepared warm count. Null uses PoolSize in fixed mode, or the adaptive minimum.</summary>
    public int? StartupWarmDatabases { get; set; }

    /// <summary>Immutable policy settings captured when a prepared fixture is created.</summary>
    public TtAdaptiveOptions AdaptivePool { get; set; } = new();

    /// <summary>Minimum Ready prepared slots retained by idle maintenance. Defaults to 0. Adaptive maintenance also preserves its admitted warm target.</summary>
    public int WarmFloor { get; set; }

    /// <summary>Maximum parked idle databases; null uses PoolSize. Parked databases still consume physical reservations.</summary>
    public int? MaxParkedDatabases { get; set; }

    /// <summary>Optional monotonic age since verified Ready publication before explicit idle maintenance or capacity shrink deletes a database. Unchanged-target monitor ticks do not apply expiry. Parking preserves age; the Ready floor is protected. Null disables expiry.</summary>
    public TimeSpan? IdleDatabaseLifetime { get; set; }

    /// <summary>Maximum pooled connections in each owned workload data source. Defaults to 4.</summary>
    public int MaxConnectionsPerDatabase { get; set; } = 4;

    /// <summary>Maximum executing workload preparations. Defaults to 1.</summary>
    public int PreparationConcurrency { get; set; } = 1;

    /// <summary>Maximum executing resets/deletions, separate from preparation. Defaults to 1.</summary>
    public int ResetConcurrency { get; set; } = 1;

    /// <summary>Prepared-fixture administrator connection allowance, including bootstrap. Defaults to 2.</summary>
    public int MaxAdministratorConnections { get; set; } = 2;

    /// <summary>Container ceiling; defaults to the slot cap for ordinary fixtures and one for prepared fixtures.</summary>
    public int? MaxContainers { get; set; }

    /// <summary>Maximum time the caller waits for resource drain. Cleanup ownership survives a timeout. Defaults to 30 seconds.</summary>
    public TimeSpan DrainTimeout { get; set; } = TimeSpan.FromSeconds(30);

    /// <summary>Maximum time the caller waits for fixture initialization. Defaults to 30 seconds.</summary>
    public TimeSpan StartupTimeout { get; set; } = TimeSpan.FromSeconds(30);

    /// <summary>
    /// Automatically run EnsureCreated when creating contexts. Defaults to true.
    /// Can be configured via "TurboTest:AutoMigrate" in appsettings.json
    /// </summary>
    public bool AutoMigrate { get; set; } = true;

    /// <summary>
    /// Enable sensitive data logging in EF Core. Defaults to true for better test error messages.
    /// Can be configured via "TurboTest:EnableSensitiveDataLogging" in appsettings.json
    /// </summary>
    public bool EnableSensitiveDataLogging { get; set; } = true;

    /// <summary>
    /// Custom Docker image to use. If null, uses default image for the provider.
    /// Can be configured via "TurboTest:DockerImage" in appsettings.json
    /// </summary>
    public string? DockerImage { get; set; }

    /// <summary>
    /// Memory limit for each container in MB. Defaults to 256.
    /// Can be configured via "TurboTest:MemoryLimitMb" in appsettings.json
    /// </summary>
    public int MemoryLimitMb { get; set; } = 256;

    /// <summary>
    /// Connection string template. Advanced users only.
    /// </summary>
    public string? ConnectionStringTemplate { get; set; }

    /// <summary>
    /// Docker host URL. If null, auto-detects based on platform.
    /// </summary>
    public string? DockerHost { get; set; }

    /// <summary>
    /// Container name prefix. Defaults to "tt".
    /// </summary>
    public string ContainerPrefix { get; set; } = "tt";

    /// <summary>
    /// Prefix for generated database names. Defaults to "testdb". Prepared
    /// baselines allow at most 21 UTF-8 bytes to retain unique PostgreSQL names.
    /// </summary>
    public string DatabaseName { get; set; } = "testdb";

    /// <summary>
    /// Database username. Defaults based on provider.
    /// </summary>
    public string? Username { get; set; }

    /// <summary>
    /// Database password. Auto-generated if not specified.
    /// </summary>
    public string? Password { get; set; }

    /// <summary>
    /// Automatically allocate system resources optimally for testing performance.
    /// When true, ignores PoolSize and MemoryLimitMb and calculates optimal values.
    /// </summary>
    public bool AutoAllocateResources { get; set; } = false;

    /// <summary>
    /// Amount of system memory to reserve (in MB) when AutoAllocateResources is true.
    /// Defaults to 2GB to leave room for OS and other applications.
    /// </summary>
    public int ReserveMemoryMb { get; set; } = 2048;

    /// <summary>
    /// Amount of CPU cores to reserve when AutoAllocateResources is true.
    /// Defaults to 2 cores to leave room for OS and other applications.
    /// </summary>
    public int ReserveCpuCores { get; set; } = 2;

    /// <summary>
    /// Maximum number of containers to create even with auto-allocation.
    /// Prevents creating too many containers on high-spec systems.
    /// </summary>
    public int MaxAutoContainers { get; set; } = 20;

    /// <summary>
    /// Minimum log level for TurboTest internal logging. Defaults to Information.
    /// Set to Debug to see detailed resource allocation and container management logs.
    /// </summary>
    public LogLevel LogLevel { get; set; } = LogLevel.Information;

    /// <summary>
    /// Logger instance for TurboTest operations. If not provided, uses NullLogger.
    /// </summary>
    public ILogger? Logger { get; set; }

    /// <summary>
    /// Enable sustained-demand warm database adaptation for prepared baseline factories.
    /// Captures AdaptivePool and monitors the owned host's memory headroom. Ordinary factories reject this option.
    /// </summary>
    public bool EnableDynamicScaling { get; set; } = false;

}

/// <summary>
/// Supported database providers
/// </summary>
public enum TtDatabaseProvider
{
    /// <summary>
    /// PostgreSQL, the currently implemented provider. Reset latency depends on workload.
    /// </summary>
    PostgreSql
}
