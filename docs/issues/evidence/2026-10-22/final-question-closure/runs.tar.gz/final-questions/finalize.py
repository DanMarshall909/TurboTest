"""Apply only the independently approved exact TT024 closure envelope."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,tarfile
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/final-questions';os.chdir(ROOT)
def git(*args):return subprocess.check_output(['git',*args]).decode()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def statuses():return {r[3:]:r[:2] for r in git('status','--porcelain=v1','--no-renames','-z').split('\0') if r}
def index():
    result={}
    for r in git('ls-files','--stage','-z').split('\0'):
        if not r:continue
        meta,n=r.split('\t',1);mode,oid,stage=meta.split();assert stage=='0';result[n]=(mode,oid)
    return result
packet=json.loads((OUT/'packet.json').read_text());raw=(OUT/'candidate.json').read_bytes();fingerprint=hashlib.sha256(raw).hexdigest();candidate=json.loads(raw)
approval=json.loads((OUT/'independent-pass.json').read_text())
assert approval['verdict']=='PASS' and approval['reviewer']=='/root/tt024_closure_review'
assert fingerprint==packet['candidateSha256']==approval['candidateSha256']
assert sha(OUT/'packet.json')==approval['packetSha256']
assert sha(Path(__file__))==packet['finalizer']['sha256']==approval['finalizerSha256']
assert git('rev-parse','HEAD').strip()==candidate['base']
assert git('branch','--show-current').strip()==candidate['branch'] and candidate['upstream'] is None and not git('remote').strip()
assert not git('ls-files','--unmerged').strip()
sys.path.insert(0,str(ROOT/'scripts'));import verify
assert json.loads((OUT/'final-all/source-identity.json').read_text())==verify.source_identity()
for update in packet['envelope']['trackerUpdate']:assert sha(ROOT/update['draft'])==update['sha256']
entries={r['path']:r for r in candidate['paths']};assert set(statuses())==set(entries)
current=index()
for name,r in entries.items():
    p=ROOT/name;mode=p.lstat().st_mode
    assert stat.S_ISREG(mode) and not mode & 0o111
    assert current[name]==(r['mode'],r['stagedObject']) and sha(p)==r['sha256'] and statuses()[name]==r['status']
    assert git('hash-object',name).strip()==r['stagedObject']
manifest=json.loads((ROOT/packet['evidence']/'manifest.json').read_text());archive=ROOT/packet['evidence']/manifest['archive']['path']
assert sha(archive)==manifest['archive']['sha256']
with tarfile.open(archive) as t:
    assert len(t.getmembers())==len(manifest['files'])
    for r in manifest['files']:assert hashlib.sha256(t.extractfile(r['path']).read()).hexdigest()==r['sha256']
subprocess.run(['git','diff','--cached','--check'],check=True)
writes=packet['envelope']['write'];moves=packet['envelope']['archive'];assert len(writes)==len(moves)==1
final={n:dict(r) for n,r in entries.items()};deletions=set()
for write in writes:
    source=ROOT/write['from'];target=ROOT/write['to'];assert write['mode']=='100644' and sha(source)==write['sha256'] and not target.exists()
    target.write_bytes(source.read_bytes());subprocess.run(['git','add',write['to']],check=True)
    final[write['to']]={'mode':'100644','sha256':write['sha256'],'stagedObject':git('hash-object',write['to']).strip()}
for move in moves:
    old,new=move['from'],move['to'];source=ROOT/old;target=ROOT/new
    assert old in final and move['mode']=='100644' and sha(source)==move['sha256']==final[old]['sha256'] and not target.exists()
    target.parent.mkdir(parents=True,exist_ok=True);subprocess.run(['git','mv',old,new],check=True)
    final[new]=final.pop(old);deletions.add(old)
assert set(statuses())==set(final)|deletions
assert set(git('diff','--name-only','--no-renames','-z',candidate['base']).split('\0'))-{''}==set(final)|deletions
for old in deletions:assert not (ROOT/old).exists() and old not in index() and statuses()[old]=='D '
for name,r in final.items():assert sha(ROOT/name)==r['sha256'] and index()[name]==(r['mode'],r['stagedObject']) and git('hash-object',name).strip()==r['stagedObject']
assert json.loads((OUT/'final-all/source-identity.json').read_text())==verify.source_identity()
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m',packet['envelope']['commit']],check=True)
commit=git('rev-parse','HEAD').strip();assert not statuses() and git('rev-parse','HEAD^').strip()==candidate['base']
assert set(git('diff-tree','--no-commit-id','--no-renames','--name-only','-r',commit).splitlines())==set(final)|deletions
for name,r in final.items():assert sha(ROOT/name)==r['sha256'] and git('rev-parse','HEAD:'+name).strip()==r['stagedObject']
save(OUT/'publication.json',{'commit':commit,'candidateSha256':fingerprint,'independentVerdict':'PASS','regularFinalPaths':len(final),'deletedArchiveSource':sorted(deletions),'scope':'Local source commit and exact archive only; issue14 closure remains conditional on fresh expected-body comparison/readback','cleanup':'Inspect only; no resources deleted'})
print(json.dumps({'commit':commit,'regularPaths':len(final),'archiveSourceDeletions':len(deletions),'clean':True}))
