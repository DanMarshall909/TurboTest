"""Final-source calibration, restored reusable build and integrated owning coverage."""
from pathlib import Path
import importlib.util,json,os,subprocess,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/final-questions'
s=importlib.util.spec_from_file_location('v',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
before=v.source_identity()
variants=[('calibrate-provider.py','/provider-calibration\'','/final-provider-calibration\''),('calibrate-held.py','/held-calibration\'','/final-held-calibration\''),('calibrate-expiry-1208.py','/expiry-1208-calibration\'','/final-expiry-1208-calibration\''),('calibrate-expiry-1211.py','/expiry-1211-calibration\'','/final-expiry-1211-calibration\'')]
for script,old,new in variants:
    text=(OUT/script).read_text();assert text.count(old)==1
    text=text.replace(old,new)
    if script=='calibrate-held.py':text=text.replace('assert len(rows)==10','assert len(rows)==11').replace("'controlsPassed':9","'controlsPassed':10").replace('9controls passed','10controls passed')
    path=OUT/('final-'+script);path.write_text(text);subprocess.run(['python3',str(path)],cwd=ROOT,check=True)
assert before==v.source_identity()
build=ROOT/'artifacts/tt-024/lifetimes/calibration-build';restore=OUT/'restored-calibration-build';restore.mkdir()
targets=restore/'Original.targets'
targets.write_text(f'''<Project><Target Name="RecordOriginalCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore' Or '$(MSBuildProjectName)' == 'TurboTest.Tests'"><WriteLinesToFile File="{restore}/$(MSBuildProjectName)-compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
env=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1')
v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],restore,180,env)
inputs=(restore/'TurboTest.EFCore-compile.txt').read_text().splitlines();tests=(restore/'TurboTest.Tests-compile.txt').read_text().splitlines()
for name in ['TtSlotPool.cs','TtOwnedContextOptions.cs','TtCapacityPolicy.cs']:assert str(ROOT/'src/TurboTest.EFCore/Internal'/name) in inputs
assert not any('/artifacts/' in p for p in inputs if not '/obj/' in p)
assert not any('PrivateNodeProbe' in p for p in tests)
selection='FullyQualifiedName~A_valid_alternate_provider|FullyQualifiedName~An_unchanged_warm_target_defers_discarded_capacity|FullyQualifiedName~Unchanged_capacity_monitoring_leaves_expiry'
v.run_phase('test',['dotnet','test',str(build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'),'--filter',selection,'--results-directory',str(restore/'results'),'--logger','trx;LogFileName=results.trx'],restore,30,env)
rows=E.parse(restore/'results/results.trx').findall('.//{*}UnitTestResult');assert len(rows)==3 and all(r.get('outcome')=='Passed' for r in rows)
v.write_json(restore/'result.json',{'restoredFinalOriginalProductInputs':True,'passed':3,'productCompile':inputs,'testCompile':tests})
v.run_phase('owning-build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','-nr:false','-p:UseSharedCompilation=false'],OUT,180,env)
binding=v.source_identity();assert binding==before;v.write_json(OUT/'owning-source.json',binding)
env['DOCKER_HOST']=v.DOCKER_HOST;resources=v.docker_inventory(OUT,'owning-resources-before',env)
selection='Category!=PostgreSQL|FullyQualifiedName~OrdinaryRecoveryTests|FullyQualifiedName~PreparedDrainRetryTests|FullyQualifiedName~PreparedRewarmRecoveryTests|FullyQualifiedName~PreparedMaintenanceDrainTests|FullyQualifiedName~Failed_startup_retains_exact_cleanup_ownership_and_supports_explicit_or_global_retry|FullyQualifiedName~PreparedRetentionTests'
try:v.run_phase('owning-coverage',['dotnet','test',v.PROJECT,'--no-build','--no-restore','-c','Release','--filter',selection,'--collect','Code Coverage;Format=cobertura','--results-directory',str(OUT/'owning-coverage'),'--logger','trx;LogFileName=results.trx'],OUT,300,env)
finally:
    after=v.docker_inventory(OUT,'owning-resources-after',env);v.write_json(OUT/'owning-resource-settlement.json',{'before':sorted(resources),'after':sorted(after),'equal':resources==after,'automaticDeletion':False})
assert resources==after and binding==v.source_identity()
print('Final-source calibration and integrated owning coverage terminal PASS',flush=True)
