"""One-off final-resource-disposal evidence packet; run after final ordinary gate."""
from pathlib import Path
import hashlib, json, subprocess, sys, tarfile, xml.etree.ElementTree as ET
ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/final-resources'
BASE = '91431381c356d3a4d35cad39d69649cbd3b76f0c'
SOURCE = ['tests/TurboTest.Tests/OrdinaryPoolClosureTests.cs']
MEASURED = SOURCE + ['src/TurboTest.EFCore/Internal/TtPool.cs', 'src/TurboTest.EFCore/TtServiceFactory.cs']
sys.path.insert(0, str(ROOT / 'scripts'))
import verify
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, obj): path.write_text(json.dumps(obj, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT).decode()
assert git('rev-parse', 'HEAD').strip() == BASE
assert git('branch', '--show-current').strip() == 'master' and not git('remote').strip()
assert len(git('worktree', 'list', '--porcelain').split('worktree ')) == 2
run = OUT / 'final-all'; result = json.loads((run / 'verification.json').read_text())
assert result['result'] == 'PASS'
assert result['tests']['fast']['passed'] == 308 and result['tests']['slow']['passed'] == 170
assert result['resourceSettlement']['before'] == result['resourceSettlement']['after']
assert not result['resourceSettlement']['added'] and not result['resourceSettlement']['removed']
binding = json.loads((run / 'source-identity.json').read_text())
assert binding == verify.source_identity()
assert json.loads((OUT / 'owning-source.json').read_text()) == binding
coverage = json.loads((OUT / 'owning-coverage.json').read_text())
assert coverage['exitCode'] == 0 and not coverage['deadlineExceeded'] and coverage['processGroupStopped']
catalog = json.loads((run / 'test-catalog.json').read_text())
expected_rows = {row['id'] for row in catalog['all'] if row['name'].startswith('TurboTest.Tests.OrdinaryPoolClosureTests.')}
rows = ET.parse(OUT / 'owning-coverage/results.trx').findall('.//{*}UnitTestResult')
assert len(expected_rows) == len(rows) == 2
assert {row.get('testId') for row in rows} == expected_rows and all(row.get('outcome') == 'Passed' for row in rows)
assert json.loads((OUT / 'semaphore-calibration/result.json').read_text())['primaryInputsUnchanged']
probes = json.loads((OUT / 'probe-results.json').read_text())['rows']
assert [(row['variant'], row['passed'], len(row['failed'])) for row in probes] == [('control',4,0),('660',3,1),('2218',3,1)]
assert all(row['resourceIdsUnchanged'] and row['primarySourceBinaryDependenciesUnchanged'] for row in probes)
for name in MEASURED:
    target = OUT / 'candidate-source' / name; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
for name, sha in binding['resolvedDependencies'].items():
    assert digest(ROOT / name) == sha
    target = OUT / 'resolved-dependencies' / name; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
retain = ROOT / 'docs/issues/evidence/2026-10-22/final-resource-disposal'
retain.mkdir(parents=True, exist_ok=False)
excluded = {'candidate.json', 'candidate.sha256', 'packet.json', 'envelope-completion.json', 'independent-pass.json', 'handoff-live.json'}
items = sorted((p for folder in (OUT,) for p in folder.rglob('*')
                if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts),
               key=lambda p: str(p.relative_to(ROOT / 'artifacts/tt-024')).encode())
entries = []; archive = retain / 'runs.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for p in items:
        assert not p.is_symlink() and p.resolve().is_relative_to((ROOT / 'artifacts/tt-024').resolve())
        name = str(p.relative_to(ROOT / 'artifacts/tt-024')); tar.add(p, arcname=name, recursive=False)
        entries.append({'path': name, 'sha256': digest(p), 'bytes': p.stat().st_size})
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(entries)
    for row in entries: assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest() == row['sha256']
limits = [
    "Bounded TT024 final-resource disposal slice; production unchanged. Characterization and source-fault calibration, no new product-repair RED or full mutation replay.",
    "Maintained two-row admission evidence covers never-started and failed-start ordinary owners. Successfully initialized owners return before the semaphore check.",
    "SDK request rejection uses one-off private owner selection and actual Docker; it does not prove a persistent native-socket leak or expose a public SDK client.",
    "Provider diagnostic creates a WaitHandle and holds one successful cancellation callback. It proves that handle's minimum/maximum lifetime in successful drain, not normal kernel-handle allocation or every cancellation-failure exit.",
    "Exact omissions660/661/2218 reject their owning assertions with independent controls; useful disposals remain, original historical mutation statuses unchanged.",
    "Initial socket precondition failure is retained as diagnostic setup correction, not a product RED. All raw attempts remain available.",
    "Three additional bounded questions bring the map to33 decisions and15 unresolved. Guard/flag658/662 and broader optional/lifecycle domains remain open; no additional acceptance checkbox or issue closure.",
    "Final2-row owning coverage and full ordinary gate bind identical source/runtime/dependency inputs. No production, lane, retry, concurrency, existing deadline or PostgreSQL setting changed.",
    "Whole-session mutation pending after final coding-session snapshot; no fresh adequacy score or hosted CI result.",
    "Local source commits only, no code remote. Preserve reusable caches, evidence and unknown stopped baseline. Tracker evidence-only append requires fresh compare, body-only update/readback after PASS."
]
save(retain / 'manifest.json', {'schemaVersion': 1, 'slice': 'TT024 final-resource disposal',
    'baseCommit': BASE, 'candidateSource': {name: binding['files'][name] for name in MEASURED},
    'archive': {'path': 'runs.tar.gz', 'sha256': digest(archive), 'bytes': archive.stat().st_size},
    'files': entries, 'verification': result, 'limits': limits})
text = (OUT / 'results-draft.md').read_text()
text += f'\n## Final ordinary gate\n\n**308 fast + 170 PostgreSQL = 478 passed**, no failures/skips. Total {result["elapsedSeconds"]:.3f}s. Solution and separate example builds pass. Exact discovered/executed IDs, source/binary/dependency identity, stopped owned process groups and matching before/after labelled Docker inventories are retained. The final 2-row owning coverage binds identical inputs. Independent final verdict is recorded separately in `completion.json`.\n'
(retain / 'results.md').write_text(text)
investigations = ['docs/issues/open/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md']
for name in investigations:
    path = ROOT / name
    path.write_text(path.read_text() + '\n- **2026-10-22 — Final-resource disposal contracts:** [Source-bound evidence](../../evidence/2026-10-22/final-resource-disposal/manifest.json) records closed never-started/failed-start adapter admission and one-off owned SDK/provider source disposal diagnostics. Exact omissions reject the owning assertions with independent controls; useful disposals remain. Three more bounded questions leave15 of48 unresolved. Initial socket-precondition correction is retained without a leak claim; the provider handle is diagnostically requested and only successful held-callback drain is shown. Final ordinary verification is478 passes and2 owning coverage rows. Independent verdict is in `completion.json`; the investigation stays open and GitHub owns the partial checklist.\n')
readme = ROOT / 'docs/issues/README.md'
old = readme.read_text(); new = old.replace('**476 tests**', '**478 tests**', 1).replace('**306 fast checks**', '**308 fast checks**', 1)
assert new != old; readme.write_text(new)
subprocess.run(['git', 'add', *SOURCE, *investigations, 'docs/issues/README.md', str(retain.relative_to(ROOT))], cwd=ROOT, check=True)
index = {}
for row in git('ls-files', '--stage', '-z').split('\0'):
    if not row: continue
    meta, name = row.split('\t', 1); mode, oid, stage = meta.split(); assert stage == '0'; index[name] = (mode, oid)
statuses = {r[3:]: r[:2] for r in git('status', '--porcelain=v1', '-z').split('\0') if r}
paths = [p for p in git('diff', '--name-only', '-z', BASE).split('\0') if p]
expected = set(SOURCE + investigations + ['docs/issues/README.md'] + [str((retain/n).relative_to(ROOT)) for n in ('runs.tar.gz','manifest.json','results.md')])
assert set(paths) == set(statuses) == expected
records = []
for name in sorted(paths, key=lambda s: s.encode()):
    mode, oid = index[name]; assert mode == '100644' and not (ROOT / name).is_symlink()
    change = 'M' if subprocess.run(['git','cat-file','-e',BASE+':'+name],cwd=ROOT,capture_output=True).returncode == 0 else 'A'
    records.append({'path':name,'change':change,'status':statuses[name],'mode':mode,'sha256':digest(ROOT/name),'stagedObject':oid})
candidate = {'schemaVersion':1,'base':BASE,'current':BASE,'branch':'master','upstream':None,'integrationBase':BASE,'paths':records,'excludedUnrelated':[]}
raw = (json.dumps(candidate,sort_keys=True,indent=2)+'\n').encode(); (OUT/'candidate.json').write_bytes(raw)
fingerprint = hashlib.sha256(raw).hexdigest(); (OUT/'candidate.sha256').write_text(fingerprint+'\n')
save(OUT/'envelope-completion.json', {'slice':'TT024 final-resource disposal','independentVerdict':'PASS','reviewer':'/root/tt024_final_resources_review',
    'reviewedCandidateSha256':fingerprint,'baseCommit':BASE,'ordinaryTests':478,'issuesRemainOpen':[14],
    'wholeSessionMutation':'pending after final coding-session snapshot','publication':'local source commit only'})
packet = {'slice':'TT024 final-resource disposal','acceptedScopeAndCriteria':str((retain/'results.md').relative_to(ROOT)),
    'candidate':'artifacts/tt-024/final-resources/candidate.json','candidateSha256':fingerprint,'base':BASE,'upstream':None,
    'integrationPolicy':'Local source commits only, docs/issues/README.md','evidence':str(retain.relative_to(ROOT)),'limits':limits,
    'envelope': {'write':[{'from':'artifacts/tt-024/final-resources/envelope-completion.json','to':str((retain/'completion.json').relative_to(ROOT)),
                           'sha256':digest(OUT/'envelope-completion.json'),'mode':'100644'}],
        'validation':['reconstruct candidate manifest and archive hashes','git diff --check','match final tree to candidate plus exact completion write','match full source/binary/dependency identity and exact packet hash'],
        'commit':'Verify final adapter and provider disposal contracts','push':'none: local source policy',
        'trackerUpdate':[{'issue':n,'draft':f'artifacts/tt-024/final-resources/tracker-{n}-draft.json','sha256':digest(OUT/f'tracker-{n}-draft.json'),
            'expectedBodySha256':hashlib.sha256(json.loads((OUT/f'tracker-{n}-draft.json').read_text())['expectedBody'].encode()).hexdigest(),
            'resultingBodySha256':hashlib.sha256(json.loads((OUT/f'tracker-{n}-draft.json').read_text())['resultingBody'].encode()).hexdigest(),
            'condition':'Immediately reread open issue, require exact expected body, apply only resulting body preserving other fields, read back. If already result verify idempotently. Conflicting edits require reconciliation/review.'} for n in (14,)],
        'cleanup':'Inspect only; preserve unknown stopped container, reusable caches and evidence. No further deletions.'}}
save(OUT/'packet.json',packet)
print(json.dumps({'candidateSha256':fingerprint,'paths':len(records),'archiveMembers':len(entries),'archiveBytes':archive.stat().st_size,'packetSha256':digest(OUT/'packet.json')}))
