using System.Reflection;
using System.Text.Json;
using Docker.DotNet;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using TurboTest.EFCore;
using TurboTest.EFCore.Internal;

namespace TurboTest.Tests;

// One-off ownership diagnostics. Private owner selection is intentionally
// excluded from maintained tests; actual SDK resources supply the oracles.
public class FinalResourceProbe
{
    [Fact]
    public async Task Owned_docker_client_closes_its_native_transport_at_final_pool_drain()
    {
        var pool = new TtPool(new TtOptions { PoolSize = 1, DockerHost = "unix:///var/run/docker.sock" });
        var client = Field<DockerClient>(pool, "_dockerClient");
        var before = Sockets();
        try
        {
            var version = await client.System.GetVersionAsync().WaitAsync(TimeSpan.FromSeconds(5));
            Assert.False(string.IsNullOrEmpty(version.Version));
            var owned = Sockets().Except(before).ToArray();
            Assert.NotEmpty(owned);
            await pool.DisposeAsync();
            var retained = owned.Intersect(Sockets()).ToArray();
            Save("docker", new { serverVersion = version.Version, opened = owned, retainedAfterDrain = retained });
            Assert.Empty(retained);
            await Assert.ThrowsAsync<ObjectDisposedException>(() => client.System.GetVersionAsync());
            await pool.DisposeAsync();
            Assert.Empty(pool.OwnedResourceIds);
            GC.KeepAlive(client);
            GC.KeepAlive(pool);
        }
        finally
        {
            await Record.ExceptionAsync(() => pool.DisposeAsync().AsTask());
            client.Dispose();
        }
    }

    [Fact]
    public async Task Provider_shutdown_source_releases_its_handle_after_cancellation_settles()
    {
        using var services = new ServiceCollection().BuildServiceProvider();
        var owner = new TtServiceFactory(Options.Create(new TtOptions()), services);
        var source = Field<CancellationTokenSource>(owner, "_shutdown");
        var token = source.Token;
        var handle = token.WaitHandle;
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        using var release = new ManualResetEventSlim();
        var calls = 0;
        using var registration = token.Register(() =>
        {
            Interlocked.Increment(ref calls);
            entered.TrySetResult();
            if (!release.Wait(TimeSpan.FromSeconds(5))) throw new TimeoutException("Diagnostic cancellation gate was not released.");
        });
        Task? closing = null;
        try
        {
            closing = owner.DisposeAsync().AsTask();
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(2));
            Assert.True(token.IsCancellationRequested);
            Assert.Same(handle, token.WaitHandle);
            Assert.False(handle.SafeWaitHandle.IsClosed);
            Assert.False(closing.IsCompleted);
            Assert.Same(closing, owner.DisposeAsync().AsTask());
            await Assert.ThrowsAsync<ObjectDisposedException>(() => owner.CreateFactoryAsync<TestDbContext>());
            release.Set();
            await closing.WaitAsync(TimeSpan.FromSeconds(2));
            Save("provider", new { calls, closedAfterDrain = handle.SafeWaitHandle.IsClosed });
            Assert.True(handle.SafeWaitHandle.IsClosed);
            Assert.Throws<ObjectDisposedException>(() => token.WaitHandle);
            Assert.Equal(1, calls);
            Assert.Same(closing, owner.DisposeAsync().AsTask());
            GC.KeepAlive(owner);
            GC.KeepAlive(source);
        }
        finally
        {
            release.Set();
            if (closing is not null) await Record.ExceptionAsync(() => closing);
            await Record.ExceptionAsync(() => owner.DisposeAsync().AsTask());
            source.Dispose();
        }
    }

    private static T Field<T>(object owner, string name) => (T)owner.GetType()
        .GetField(name, BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(owner)!;

    private static HashSet<string> Sockets()
    {
        var result = new HashSet<string>();
        foreach (var path in Directory.EnumerateFiles("/proc/self/fd"))
            try
            {
                var target = new FileInfo(path).LinkTarget;
                if (target?.StartsWith("socket:[", StringComparison.Ordinal) == true) result.Add(target);
            }
            catch (IOException) { }
        return result;
    }

    private static void Save(string name, object value) => File.WriteAllText(
        Path.Combine(Environment.GetEnvironmentVariable("TT_RESOURCE_PROBE_RESULT")!, name + ".json"),
        JsonSerializer.Serialize(value, new JsonSerializerOptions { WriteIndented = true }));
}
