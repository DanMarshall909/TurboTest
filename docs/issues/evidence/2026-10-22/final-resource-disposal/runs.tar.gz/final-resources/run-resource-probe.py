"""One-off diagnostic controller; isolated reusable build, no primary edits."""
from pathlib import Path
import hashlib, importlib.util, json, os, xml.etree.ElementTree as E

ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/final-resources'
spec = importlib.util.spec_from_file_location('verify', ROOT / 'scripts/verify.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
BUILD = ROOT / 'artifacts/tt-024/lifetimes/calibration-build'
before = v.source_identity()
original_pool = (ROOT / 'src/TurboTest.EFCore/Internal/TtPool.cs').read_text()
original_provider = (ROOT / 'src/TurboTest.EFCore/TtServiceFactory.cs').read_text()
variants = [
    ('control', None, None, None),
    ('660', 'Internal/TtPool.cs', '_dockerClient?.Dispose();', ';'),
    ('2218', 'TtServiceFactory.cs', 'finally { _shutdown.Dispose(); }', 'finally { }'),
]
results = []
for name, relative, old, new in variants:
    case = OUT / ('probe-request-' + name)
    case.mkdir()
    replacement = ''
    if relative:
        source = ROOT / 'src/TurboTest.EFCore' / relative
        raw = source.read_text()
        assert raw.count(old) == 1
        fault = case / source.name
        fault.write_text(raw.replace(old, new))
        replacement = f'<ItemGroup Condition="\'$(MSBuildProjectName)\' == \'TurboTest.EFCore\'"><Compile Remove="{relative}"/><Compile Include="{fault}"/></ItemGroup>'
    targets = case / 'Probe.targets'
    targets.write_text(f'''<Project>{replacement}
<ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.Tests'"><Compile Include="{OUT / 'FinalResourceProbe.cs'}"/></ItemGroup>
<Target Name="RecordProbeCompile" BeforeTargets="CoreCompile"><WriteLinesToFile File="{case}/$(MSBuildProjectName)-compile-inputs.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
    v.run_phase('build', ['dotnet', 'build', v.PROJECT, '-c', 'Release', '--no-restore',
        '--artifacts-path', str(BUILD), '-p:CustomBeforeMicrosoftCommonTargets=' + str(targets),
        '-nr:false', '-p:UseSharedCompilation=false'], case, 180, os.environ)
    product_inputs = (case / 'TurboTest.EFCore-compile-inputs.txt').read_text().splitlines()
    test_inputs = (case / 'TurboTest.Tests-compile-inputs.txt').read_text().splitlines()
    assert str(OUT / 'FinalResourceProbe.cs') in test_inputs
    assert not any('PrivateNodeProbe.cs' in row for row in test_inputs)
    if relative:
        assert str(fault) in product_inputs and str(source) not in product_inputs
    else:
        assert str(ROOT / 'src/TurboTest.EFCore/Internal/TtPool.cs') in product_inputs
    dll = BUILD / 'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
    compiled = {str(p.relative_to(BUILD)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(dll.parent.rglob('*')) if p.is_file() and (p.suffix == '.dll' or p.name.endswith(('.deps.json', '.runtimeconfig.json')))}
    v.write_json(case / 'binding.json', {'sourceIdentity': before, 'compiledInputs': compiled,
        'probeSha256': hashlib.sha256((OUT / 'FinalResourceProbe.cs').read_bytes()).hexdigest(),
        'fault': None if not relative else {'source': str(source), 'old': old, 'new': new,
            'originalSha256': hashlib.sha256(raw.encode()).hexdigest(),
            'faultSha256': hashlib.sha256(fault.read_bytes()).hexdigest()}})
    env = dict(os.environ, DOCKER_HOST=v.DOCKER_HOST, TT_RESOURCE_PROBE_RESULT=str(case))
    baseline = v.docker_inventory(case, 'resources-before', env)
    try:
        v.run_phase('test', ['dotnet', 'test', str(dll), '--filter',
            'FullyQualifiedName~FinalResourceProbe|FullyQualifiedName~OrdinaryPoolClosureTests',
            '--results-directory', str(case / 'results'), '--logger', 'trx;LogFileName=results.trx'], case, 45, env)
    except v.VerificationError:
        pass
    after = v.docker_inventory(case, 'resources-after', env)
    assert baseline == after
    receipt = json.loads((case / 'test.json').read_text())
    assert not receipt['deadlineExceeded'] and receipt['processGroupStopped']
    rows = E.parse(case / 'results/results.trx').findall('.//{*}UnitTestResult')
    assert len(rows) == 4
    failed = [{'name': row.get('testName'), 'message': row.findtext('.//{*}Message')}
        for row in rows if row.get('outcome') == 'Failed']
    if name == 'control':
        assert receipt['exitCode'] == 0 and not failed
    elif name == '660':
        assert receipt['exitCode'] == 1 and len(failed) == 1
        assert 'Owned_docker_client' in failed[0]['name'] and 'Assert.IsType' in failed[0]['message']
    else:
        assert receipt['exitCode'] == 1 and len(failed) == 1
        assert 'Provider_shutdown_source' in failed[0]['name'] and 'Assert.True' in failed[0]['message']
    assert before == v.source_identity()
    assert (ROOT / 'src/TurboTest.EFCore/Internal/TtPool.cs').read_text() == original_pool
    assert (ROOT / 'src/TurboTest.EFCore/TtServiceFactory.cs').read_text() == original_provider
    results.append({'variant': name, 'passed': len(rows) - len(failed), 'failed': failed,
        'resourceIdsUnchanged': True, 'primarySourceBinaryDependenciesUnchanged': True})
    v.write_json(OUT / 'probe-results.json', {'rows': results,
        'qualification': 'One-off private owner selection plus actual SDK disposed-object behavior and provider kernel-handle closure; no native persistent-socket leak claim, maintained private-field tests, full mutation replay or historical status changes.'})
    print(json.dumps(results[-1]), flush=True)
