"""Freeze the complete TT023 closure candidate only after final ordinary gates."""
from pathlib import Path
import hashlib,json,subprocess,sys,tarfile,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-023/diagnostic-closure';BASE='e18d7e1418890a0a7f39a1bb9d2116580b4cefcb';sys.path.insert(0,str(ROOT/'scripts'));import verify as v

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT).decode()
assert git('rev-parse','HEAD').strip()==BASE and git('branch','--show-current').strip()=='master'
assert not git('remote').strip() and git('branch','--format=%(refname:short)').splitlines()==['master'] and len(git('worktree','list','--porcelain').split('worktree '))==2
final=json.loads((OUT/'final-verification/result.json').read_text());assert final['result']=='PASS' and final['fastCoverageRows']==348 and final['nativeCoverageRows']==35
result=final['canonicalAll'];assert result['result']=='PASS' and result['tests']['fast']['passed']==348 and result['tests']['slow']['passed']==172
assert result['resourceSettlement']['before']==result['resourceSettlement']['after'] and not result['resourceSettlement']['added'] and not result['resourceSettlement']['removed']
binding=json.loads((OUT/'final-verification/source.json').read_text());assert binding==v.source_identity()==json.loads((OUT/'final-verification/all/source-identity.json').read_text())==json.loads((OUT/'final-calibration-v2/source.json').read_text())
cal=json.loads((OUT/'final-calibration-v2/result.json').read_text());assert cal['faults']==28 and cal['restoredPassed']==349
subprocess.run(['python3',str(OUT/'build-question-map.py')],cwd=ROOT,check=True)
questions=json.loads((OUT/'question-dispositions-candidate.json').read_text());assert len(questions['entries'])==54 and questions['directCurrentOriginalFaultCount']==25 and questions['finalCalibrationStatus']=='terminal PASS'
questions['pending']=['independent completion verdict','local publication and conditional issue closure'];questions['finalVerification']=final;save(OUT/'question-dispositions-candidate.json',questions)
red=E.parse(OUT/'criterion3-red-results/results.trx').findall('.//{*}UnitTestResult');assert len(red)==3 and sum(n.get('outcome')=='Failed' for n in red)==1
assert 'CallbackStage' in next(n.findtext('.//{*}Message') for n in red if n.get('outcome')=='Failed')
source=[name for name in git('diff','--name-only').splitlines() if name.startswith(('src/','tests/'))]+['README.md']
assert len(source)==13
for name in source:
 p=OUT/'candidate-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
for name in ['src/TurboTest.EFCore/Tt.cs','src/TurboTest.EFCore/TtFactory.cs']:
 p=OUT/'base-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT))
for name,digest in binding['resolvedDependencies'].items():
 assert sha(ROOT/name)==digest;p=OUT/'resolved-dependencies'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
save(OUT/'qualifications.json',{
 'sourceCut':'Final-v2 and final-verification bind the same compiler/test/runtime/dependency snapshot; earlier criterion evidence preserves earlier source cuts.',
 'genuineRed':'One missing CallbackStage failure and two controls before production repair; final causal-guard fault independently loses both component CallbackStage and native42P01 (2fail15controls). Other new cases characterize useful existing behavior.',
 'historicalMutation':'Original54statuses unchanged.25original shapes and3current regression faults are recompiled on final source; remaining source/test dispositions are not54historical fault replay. Whole-session Stryker pending final coding-session snapshot.',
 'comparatorV1':'First final-calibration controller terminated exit1 after15 validated cases and executed1354. Its full-string comparison rejected differing fault-file stack paths inside the intended Assert.Null failure. Final-v2 removes stack-frame lines only, retains exact assertion diagnostic text/control names, rebinds all28faults after intentional worker refactor and restores349original rows.',
 'comparatorCriterion15':'First one-off comparator required same Assert.Throws text in both lost-failure cases; raw terminal TRX had false/noexception and true/missingIOException. Resume validated these two heterogeneous expected failures independently with1passing control; no product-failure misclassification.',
 'otherHarness':'Criterion3 native type-name setup error fixed before execution; owning count23vs24 and criterion1count20vs21 corrected from rawTRX. Setup/bookkeeping/comparison failures are not product RED. Prior one-off1925 weak-node evidence remains historical.',
 '1924SourceProof':'Consumer sets Delivered then removes same work without intervening await. Worker releases completed actual success; independent observer ledger remains joined before drain reads maintenance. Earlier blanket nonreentry inference is superseded; proof permits synchronous reentrant SynchronizationContext.Post.',
 'scope':'All8TT023clauses and54assigned investigations have bounded dispositions. This is not proof of every hypothetical AggregateException shape, foreign-token cancellation taxonomy or every future producer. Retained real boundary tests establish actual current producers.',
 'publication':'Local-only source policy; no code remote/upstream. GitHub issue13body/checklist+closed/completed after independent PASS and local commit; preserve all unrelated metadata. Native Project fields unverified/unmodified. No Docker/cache/evidence deletion.'})
# Inspect actual changed production anchors in separate ordinary lane coverage.
anchors={}
for lane in ['fast','native']:
 coverage=next((OUT/'final-verification'/lane/'results').glob('*/*.cobertura.xml'))
 classes=E.parse(coverage).findall('.//class');anchors[lane]={}
 for filename,numbers in [('TtFactory.cs',{28,80,81}),('Tt.cs',{138,172,178,179,181,185,190,191})]:
  measured=[n.attrib for c in classes if Path(c.get('filename','')).name==filename for n in c.findall('./lines/line') if int(n.get('number')) in numbers]
  assert measured and all(int(n['hits'])>0 for n in measured)
  anchors[lane][filename]=measured
save(OUT/'coverage-review.json',{'anchors':anchors,'interpretation':'Changed startup-retained ownership flag, callback reporting predicate and success-only worker decision execute with both branch outcomes in final ordinary scopes. Execution is distinct from assertions; current compiled faults and structured diagnostic/physical-resource assertions establish sensitivity. No aggregate coverage adequacy score or slow-only exclusion change claimed.'})
# Timing/lane review: compare ordinary snapshots with identical selected tests; no membership edits.
runs=[OUT/'criterion14-cancellation-request-order/fast',OUT/'criterion15-maintenance-worker/fast',OUT/'final-verification/all']
fasts=[json.loads((p/'fast-results.json').read_text()) for p in runs]
assert all({n['name'] for n in xs}=={n['name'] for n in fasts[0]} for xs in fasts)
save(OUT/'lane-review.json',{'ordinaryFastRuns':[str(p.relative_to(OUT)) for p in runs],'testSeconds':[sum(n['seconds'] for n in xs) for xs in fasts],'fastRows':348,'nativeRows':172,'newNativeValue':'Three actual nested hosts independently prove real initializer/callback errors22012/42P01, returned two-child capability and physical deletion. Fast child/four-error cases own composition law; native test owns actual public factory/provider/Docker boundary.','decision':'Keep existing lanes. Repeated ordinary scopes remain within few-second fast feedback; deadline rows require deliberate observation waits. Native nested host work belongs to PostgreSQL lane. No test removed or moved on isolated timing variation.'})
retain=ROOT/'docs/issues/evidence/2026-10-22/lifecycle-diagnostic-closure';retain.mkdir(parents=True,exist_ok=False)
excludes={'candidate.json','candidate.sha256','packet.json','envelope-completion.json','independent-pass.json','publication.json','tracker-receipt.json','final-inspection.json'}
items=sorted((p for p in OUT.rglob('*') if p.is_file() and p.name not in excludes and '__pycache__' not in p.parts),key=lambda p:str(p.relative_to(ROOT/'artifacts/tt-023')).encode());entries=[];archive=retain/'runs.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in items:
  assert not p.is_symlink() and p.resolve().is_relative_to(OUT.resolve());name=str(p.relative_to(ROOT/'artifacts/tt-023'));t.add(p,arcname=name,recursive=False);entries.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(entries)
 for r in entries:assert hashlib.sha256(t.extractfile(r['path']).read()).hexdigest()==r['sha256']
save(retain/'manifest.json',{'schemaVersion':1,'ticket':'TT-023 lifecycle diagnostic closure','baseCommit':BASE,'candidateSource':{n:sha(ROOT/n) for n in source},'archive':{'path':'runs.tar.gz','sha256':sha(archive),'bytes':archive.stat().st_size},'files':entries,'verification':result,'owningCoverageRows':383,'calibration':{'currentOriginalFaults':25,'currentRegressionFaults':3,'restoredOriginalRows':349},'historicalStatusesUnchanged':True,'wholeSessionMutation':'pending final coding-session snapshot','sourcePublication':'local only'})
save(retain/'question-dispositions.json',questions)
(retain/'results.md').write_text('''# Lifecycle diagnostic identity and recovery

Owning issue: [TT-023](https://github.com/DanMarshall909/TurboTest/issues/13). The [54-question disposition and eight-criterion matrix](question-dispositions.json) preserves exact original identities, statuses, test methods and current source hashes. The independent whole-ticket verdict is in `completion.json`.

## Product changes

A demonstrated startup defect hid a distinct cancellation-callback failure when the initializer already carried a child cleanup capability and the outer drain succeeded. Startup now tracks whether its own retained drain owns callback reporting. Initializer and callback child capabilities remain recoverable together. Interrupted startup consistently reports callback failure through retained recovery, preventing initial/recovery duplication.

Maintenance workers release completed actual success directly. Failed work stays retained until the observer or drain reports it. This removes redundant observer-ledger and Delivered dependencies and the worker's observer parameter. The source proof permits reentrant synchronization contexts: each consumer setting Delivered removes that work itself, and independent acquisition settlement remains joined before drain reads maintenance.

Documented observations distinguish initializer-owned timeout, observation deadline, caller cancellation and owner-only closure. Caller participation before observer resumption wins in either request order; actual work and unseen failures remain owned. The latest composed cleanup capability retains every remaining child in the exercised failure paths.

## Behavior and evidence

One genuine pre-repair RED row loses CallbackStage; two controls pass. The final causal-guard regression also loses the actual nested callback's42P01, with15nearby controls passing. A native three-host test independently observes two real retained child hosts and real22012/42P01 failures, then recovers both exactly once through the returned capability after successful outer deletion.

The four-error component case requires seed42P01, callback42501, drain53100 and retry53200 plus four child owners and the actual remaining host. Later retries physically clear all five owners without consuming a distinct failure. Other maintained cases cover safe/raw stages, first-error identity after fully completed second failure, abandoned delivery without drain replay, rewarm marker transfer, two actual drain failures, failed-context lifetime and documented timing event identities. Expected identities are input-derived; no arbitrary error prose/order is pinned.

Final isolated calibration compiles **25 original fault shapes and3 current regression faults** against the same final source. Every intended diagnostic rejection and passing control is retained. Original source inputs are restored and349checks pass. This is not a54fault historical Stryker replay; all original mutation statuses remain unchanged. Remaining findings use bounded current producer/source proofs and maintained executable contracts.

## Verification and design review

Final owning coverage is **348fast+35native=383passed**. The complete ordinary gate is **348fast+172PostgreSQL=520passed**, no failures or skips. Solution and separate DynamicScalingExample builds pass. Coverage, fault calibration and complete ordinary checks bind identical source/runtime/resolved dependencies. Resource inventories preserve the unrelated stopped baseline; actual owned hosts settle and command process groups stop.

Each criterion has its characterization or genuine RED, GREEN, coverage, refactor decision and canonical fast gate before the next. Existing fixtures/tables absorb cases; no new production abstraction or private membership test is added. Repeated ordinary timing evidence retains the fast/slow lanes; the nested native boundary uniquely earns its setup cost. `lane-review.json` and raw timings are archived.

## Qualifications and publication

Earlier per-criterion source cuts remain historical. The archive explicitly retains harness type-name/count/comparison errors; none is relabelled product RED. The first final comparator failed on differing fault-file stack paths in the intended assertion failure; final-v2 compares diagnostic text exactly after removing stack-frame lines. Criterion15 compares heterogeneous missing-error assertions separately. The current1924source proof supersedes an earlier overly broad nonreentry inference; prior1925weak-node evidence remains a one-off historical measurement.

All54assigned findings have dispositions and all8accepted criteria have executable or previously accepted source-bound evidence. This does not assert every hypothetical future producer/foreign-token/aggregate taxonomy. Whole-session mutation is pending the final coding-session snapshot. Native Project fields remain unverified/unmodified. Source/evidence remain local under project policy; publication closes issue13only after independent PASS and a verified local commit. No resources, caches or evidence are deleted.
''')
old=ROOT/'docs/issues/open/api/TT-023-assert-late-failure-ordering-and-safe-diagnostic-identity.md';new=ROOT/'docs/issues/resolved/api'/old.name
s=old.read_text();s=s.replace('Its `open/` location means the investigation has not been archived; it does not mirror GitHub issue status.','Its `resolved/` location records investigation archival; it does not mirror GitHub issue status.')
s+='\n- **2026-10-22 — Diagnostic investigation archived:** [Final source-bound evidence](../../evidence/2026-10-22/lifecycle-diagnostic-closure/manifest.json) records all54original-question dispositions and all8accepted-criterion evidence, the demonstrated callback/child-cleanup repair, cancellation/timeout distinctions, compound safe diagnostics/capabilities and success-only maintenance worker simplification. Final ordinary verification is520passes, with383owning coverage rows and28current compiled fault calibrations. The independent whole-ticket verdict is retained in `completion.json`; GitHub owns checklist closure and live status. Original mutation statuses are unchanged, whole-session mutation remains pending, and native Project fields remain unverified/unmodified. This move archives the investigation rather than creating a second task board.\n'
new.write_text(s);old.unlink()
p=ROOT/'docs/issues/README.md';s=p.read_text();assert '**498 tests**' in s and '**327 fast checks**' in s;s=s.replace('**498 tests**','**520 tests**',1).replace('**327 fast checks**','**348 fast checks**',1).replace('open/api/TT-023-assert-late-failure-ordering-and-safe-diagnostic-identity.md','resolved/api/TT-023-assert-late-failure-ordering-and-safe-diagnostic-identity.md');p.write_text(s)
paths=source+['docs/issues/README.md',str(old.relative_to(ROOT)),str(new.relative_to(ROOT))]+[str((retain/n).relative_to(ROOT)) for n in ['manifest.json','question-dispositions.json','results.md','runs.tar.gz']]
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
index={}
for r in git('ls-files','--stage','-z').split('\0'):
 if r:
  meta,name=r.split('\t',1);mode,oid,stage=meta.split();assert stage=='0';index[name]=(mode,oid)
statuses={r[3:]:r[:2] for r in git('status','--porcelain=v1','--no-renames','-z').split('\0') if r};assert set(statuses)==set(paths)
records=[]
for name in sorted(paths,key=lambda n:n.encode()):
 path=ROOT/name
 if not path.exists():records.append({'path':name,'change':'D','status':statuses[name],'mode':'100644','sha256':None,'stagedObject':None});continue
 mode,oid=index[name];assert mode=='100644' and not path.is_symlink();exists=subprocess.run(['git','cat-file','-e',BASE+':'+name],cwd=ROOT,capture_output=True).returncode==0
 records.append({'path':name,'change':'M' if exists else 'A','status':statuses[name],'mode':mode,'sha256':sha(path),'stagedObject':oid})
c={'schemaVersion':1,'base':BASE,'current':BASE,'branch':'master','upstream':None,'integrationBase':BASE,'paths':records,'excludedUnrelated':[]};save(OUT/'candidate.json',c);fingerprint=sha(OUT/'candidate.json');(OUT/'candidate.sha256').write_text(fingerprint+'\n')
save(OUT/'envelope-completion.json',{'ticket':'TT-023 lifecycle diagnostic closure','independentVerdict':'PASS','reviewer':'/root/tt023_closure_review','reviewedCandidateSha256':fingerprint,'baseCommit':BASE,'ordinaryTests':520,'owningCoverageRows':383,'currentFaults':28,'wholeIssueClosure':True,'originalQuestionDispositions':54,'historicalStatusesUnchanged':True,'wholeSessionMutation':'pending final coding-session snapshot','publication':'local commit; fresh compared issue13body/checklist+closed/completed readback; native Project fields unverified/unmodified'})
save(OUT/'packet.json',{'ticket':'TT-023 lifecycle diagnostic closure','wholeTicketClosure':True,'candidate':str((OUT/'candidate.json').relative_to(ROOT)),'candidateSha256':fingerprint,'base':BASE,'current':BASE,'upstream':None,'integrationBase':BASE,'integrationPolicy':'Local-only source policy in docs/issues/README.md; no remote/upstream; sole master worktree','evidence':str(retain.relative_to(ROOT)),'acceptedScope':'GitHub issue13body in tracker-before.json; question-dispositions.json criteria1–8; original54source-bound findings','verification':final,'historicalMutationStatusesUnchanged':True,'wholeSessionMutation':'pending final coding-session snapshot','limitations':str((OUT/'qualifications.json').relative_to(ROOT)),'finalizerSha256':sha(OUT/'finalize.py'),'envelope':{'write':{'from':str((OUT/'envelope-completion.json').relative_to(ROOT)),'to':str((retain/'completion.json').relative_to(ROOT)),'sha256':sha(OUT/'envelope-completion.json'),'mode':'100644'},'validation':['exact staged candidate paths/statuses/modes/hashes/objects, including original investigation deletion','all retained archive member hashes','unchanged final source/runtime/dependency identities','git diff --cached --check','complete final changed tree equals candidate plus exact completion write'],'commit':'Preserve startup cleanup diagnostics and resolve lifecycle findings','push':'none: local-only source policy','tracker':{'issue':13,'draft':'artifacts/tt-023/diagnostic-closure/tracker-draft.json','sha256':sha(OUT/'tracker-draft.json'),'operation':'Immediately fresh compare expected body/open state/metadata; set only exact resultingBody and state closed/state_reason completed; exact readback preserves title/labels/assignees/milestone; concurrent drift requires reconciliation and review'},'project':'Unverified/unmodified; no native Project field tools/browser available','cleanup':'Inspect only. Preserve unrelated stopped baseline, reusable calibration build, caches and all evidence; no deletion'}})
print(json.dumps({'candidateSha256':fingerprint,'packetSha256':sha(OUT/'packet.json'),'finalizerSha256':sha(OUT/'finalize.py'),'changedPaths':len(records),'archiveMembers':len(entries),'archiveBytes':archive.stat().st_size}),flush=True)
