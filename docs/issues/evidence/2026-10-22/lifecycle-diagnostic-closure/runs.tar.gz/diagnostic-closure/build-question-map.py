from pathlib import Path
import json,hashlib,sys
ROOT=Path.cwd();OUT=ROOT/'artifacts/tt-023/diagnostic-closure'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
original=json.loads((OUT/'original-question-source.json').read_text())
T={
'monitor':'CapacityMonitorTests.Repeated_stop_and_join_keep_cancellation_alive_until_reader_and_callbacks_settle_then_release_it',
'checkout':'FactoryTimingTests.Admitted_checkout_distinguishes_closure_and_caller_cancellation_in_result_and_timing',
'event':'FactoryTimingTests.Public_timings_cover_checkout_shared_return_cycle_and_actual_shutdown',
'startup':'FailedStartupCleanupTests.Failed_startup_retains_exact_cleanup_ownership_and_supports_explicit_or_global_retry',
'callbackNative':'FailedStartupCleanupTests.Throwing_startup_cancellation_callbacks_cannot_replace_the_initializer_error_or_lose_cleanup',
'maintenance':'FactoryMaintenanceTests.Canceled_observation_retains_an_already_completed_maintenance_failure_until_drain',
'finally':'FactoryMaintenanceTests.A_failure_recorded_before_canceled_observer_finally_remains_available_to_drain',
'precedence':'FactoryMaintenanceTests.Maintenance_cancellation_precedence_preserves_actual_failure_until_owner_drain',
'bulk':'FactoryMaintenanceTests.Bulk_maintenance_reports_all_safe_failures_and_does_not_repeat_delivered_faults_on_drain',
'nested':'LifecycleDiagnosticRetentionTests.Wrapping_a_recovery_failure_retains_all_safe_diagnostics_without_private_payloads',
'late':'StartupLateDrainTests.Interrupted_startup_reports_the_actual_late_initializer_failure_once_after_physical_cleanup',
'lifetime':'StartupLateDrainTests.Interrupted_initialization_keeps_cancellation_alive_for_owned_work_and_releases_it_after_drain',
'four':'StartupLateDrainTests.Startup_recovery_preserves_four_distinct_safe_failures_and_every_remaining_child_owner',
'child':'StartupLateDrainTests.Initializer_child_cleanup_does_not_hide_a_distinct_callback_failure_or_its_owner',
'ownedTimeout':'StartupLateDrainTests.An_initializer_owned_timeout_preserves_its_stage_and_completes_physical_cleanup',
'deadlineCallback':'StartupCancellationOwnershipTests.Deadline_triggered_throwing_callback_is_reported_by_owned_cleanup',
'realChildren':'FailedStartupCleanupTests.Nested_startup_failures_keep_both_real_child_hosts_recoverable_after_outer_cleanup',
'idle':'SlotRetentionTests.Retirement_retry_preserves_capacity_and_replaces_only_for_renewed_demand',
'rewarm':'SlotRewarmDrainTests.A_rewarm_failure_delivered_by_exhausted_cleanup_is_not_reported_again_at_drain',
'prepare':'SlotPoolTests.Failed_preparations_share_the_cleanup_limit_before_releasing_reservations',
'terminal':'SlotPreparationDrainTests.A_terminal_failure_observed_after_abandoned_preparation_is_not_replayed_at_drain',
'transfer':'SlotRewarmDrainTests.A_failed_rewarm_transfers_its_unseen_failure_to_an_admitted_replacement_until_drain',
'quarantine':'SlotPoolTests.A_second_quarantine_cannot_replace_the_first_terminal_error_seen_by_later_acquisition',
'drops':'SlotPoolTests.Two_failed_drain_deletions_retain_both_safe_errors_until_successful_physical_retry',
'reset':'CompensatingCleanupTests.Reset_then_failed_delete_preserves_diagnostic_and_retains_cleanup_ownership',
'contexts':'FactoryBackpressureTests.Repeated_failed_acquisitions_release_completed_contexts_and_work_while_the_factory_remains_usable',
'cancelContext':'FactoryBackpressureTests.Cancellation_from_context_configuration_prevents_schema_initialization_and_discards_the_resource',
'compensation':'CompensatingCleanupTests.Initialization_then_failed_discard_preserves_diagnostic_and_retains_cleanup_ownership',
'ctor':'PublicLeaseTests.Constructor_failure_does_not_leave_an_undisclosed_database_lease',
'schema':'PublicLeaseTests.Schema_initialization_failure_is_reported_before_a_lease_is_published',
'configuration':'PreparedContextBindingTests.EnsureCreated_cannot_publish_a_runtime_model_that_disagrees_with_its_schema_model',
'lateFactory':'PreparedMaintenanceDrainTests.Closure_retains_held_rewarm_and_distinguishes_cancellation_from_late_material_failure'
}
M={}
def add(ids,aliases,contract,decision='Retain useful current contract'):
 for key in ids.split():
  assert key not in M;M[key]={'tests':[T[a] for a in aliases.split()], 'contract':contract,'decision':decision}
add('201','monitor','Repeated Stop preserves first actual cancellation task while reader and callback are held; repeated joins settle and release the CTS without losing a throwing callback.')
add('210','monitor','First Join releases cancellation wait handle after actual reader and callback settle.')
add('211 212','monitor','Concurrent/repeated Join retains the single callback error once; later TakeFailures is empty.')
add('1317','idle','Safe idle-delete stage/state DistinctDelete/53100 survives; raw controls retain SlotIdleRetire. Successful actual retry confirms deletion and renewed capacity.')
add('1396','rewarm','Safe rewarm stage/state DistinctRewarm/53200 survives failed compensation and is not replayed at drain.')
add('1397','rewarm','Raw rewarm failure has SlotRewarm/null state; safe case independently preserves its own stage.')
add('1457','terminal prepare','Known safe preparation identity is preserved: same AbandonedSeed/53100 instance, and distinct FirstCandidate/SecondCandidate failure identities remain observable.')
add('1586','reset','Actual reset failure and subsequent acquisition preserve ResetRows/P0001 through failed real deletion; safe secondary kind and recoverable resource remain.')
add('1354','terminal','After abandoned observer and fully settled preparation, fresh acquisition observes the exact failure; later drain is clean, with one creation/deletion and no replay.')
add('1598','prepare','After both failed preparations fully settle, fresh acquisition sees the first FirstCandidate same instance; SecondCandidate remains separately reported at drain.')
add('1604','transfer','A held admitted replacement owns the unseen RewarmStage/53100 failure after original deletion; shutdown cancellation does not erase it, drain reports it once, both resources are confirmed deleted.')
add('1645','quarantine','After two independent quarantine failures, later acquisition still sees original FirstQuarantine/53100 same instance; physical retry clears both.')
add('1703','drops','Actual drain of two resources reports SlotDispose with FirstDrop/53100 and SecondDrop/53200; successful retry clears both once with finite four-attempt bound.')
add('1709','drops transfer','Drain primary Stage is SlotDispose for multiple safe slot failures and transferred unseen failure.')
add('1713','checkout','PoolClosed returns the same material pool ODE and faulted checkout with Closed/4000ms timing; no Return/Cycle event.')
add('1718','event','All four emitted event identities are explicitly (402,PoolTiming); state records independently cover checkout, return, cycle and drain.')
add('1761','startup callbackNative','Actual raw prepared schema/seed initializer producer needs BaselineInitialize fallback. Native non-clone rows require that stage and retain/recover actual host.')
add('1775 1776','ownedTimeout late lifetime','Initializer-owned TimeoutException preserves BaselineInitialize and completes deletion. Observer deadline instead reports StartupTimeout and retains held work; caller interruption is StartupCanceled.')
add('1780','late four lifetime','Recovery remains incomplete and deletion has not begun until actual initializer settles independently of returned startup observation.')
add('1782','lifetime','Initializer completion alone does not permit deletion while cancellation callback is independently held; CTS remains usable until both settle then releases its handle.')
add('1789','four deadlineCallback','Initially unreported callback failure reaches recovery as CallbackStage/42501 plus its child owner, or native StartupCancellation, followed by clean retry.')
add('1804','four','Current collection appends retry failure and continues collecting seed/callback errors; all four safe identities and five remaining resource labels are reachable and later cleared.','Obsolete historical early throw replaced by complete collection; current retry-collection fault calibrates the append obligation, not original replay')
add('1809','four child','Unseen callback is delivered by retained recovery once; subsequent successful retry neither replays callback/seed nor repeats successful child deletion.')
add('1821','four','Recovery must throw its multiple distinct failures while retaining remaining cleanup; all four stage/state pairs and successful later physical cleanup are asserted.')
add('1824 1827','late lifetime ownedTimeout','Deadline and caller interruption have explicit StartupTimeout/StartupCanceled stages; actual initializer-owned timeout remains BaselineInitialize.')
add('1829','startup configuration','Existing BaselineClone or BaselineConfiguration lifecycle stage survives outer prepared BaselineInitialize boundary; raw fallback independently retained.')
add('1833 1834 1836','child realChildren ownedTimeout','Actual startup-retained drain ownership determines callback recovery responsibility. Initializer-owned child cleanup cannot hide distinct callback error/child; outer success still exposes both real child hosts and permits physical retry. No-callback and retained-outer-drain controls remain.','Retire historical failure.Cleanup presence proxy; use catch-local cleanupRetained ownership; current causal-guard regression fault calibrates demonstrated repair')
add('1835','child callbackNative ownedTimeout','Nonnull callback requirement preserves actual callback failures; no-callback successful drain remains valid. Repaired ownership predicate has explicit immediate/deferred controls.')
add('1896 1897 1899','precedence','Admitted maintenance owner-only cancellation becomes faulted ObjectDisposedException; caller participation in either request order remains canceled OperationCanceledException; actual failure stays owned until drain.')
add('1919','bulk','Two-failure actual maintenance has primary IdleMaintenance plus both safe failure kinds; delivered failures are not replayed at drain.')
add('1922 1923 1926','maintenance finally','Canceled observer -> actual failed work completed -> drain retains SlotIdleRetire and any distinct pool-drain error. Worker now releases success only; it cannot remove unseen failed work. Current maintenance-success-only fault independently loses both intended failures.','Retire original compound worker predicate; retain explicit success-only worker cleanup and failure consumer ownership; not exact original replay')
add('1924','maintenance finally','Worker removes completed actual success without observer-ledger dependency; observers remain independently joined in _acquisitions. Both consumers that set Delivered remove the work themselves without intervening await. This proof permits reentrant SynchronizationContext.Post. Prior1925 one-off canceledSuccess weak-node evidence establishes useful late-success removal, not a maintained public oracle.','Bounded source simplification; remove observer parameter and redundant Delivered/admission relationships. No exact1924 execution or historical-status change')
add('1984','contexts','Sixteen failed acquisitions release weak Context and Acquisition while factory stays live;16 actual deletes/zero reservations, then another usable request. Successful-lease lifetime alone is not used as this proof.')
add('1985','ctor schema compensation','Material construction/schema failure with clean discard requires safe ContextCreate/ContextInitialize; cancellation plus failed discard requires safe original OCE and secondary IOException/capability.')
add('1986 1987','cancelContext ctor','Clean cancellation remains OperationCanceledException, zero schema initialization and one dispose/delete; independent material constructor error requires safe wrapping.')
add('1989','cancelContext compensation','Clean cancellation with successful discard rethrows OCE; cancellation with failed discard composes original and IOException, retaining physical recovery ownership.')
add('1990','cancelContext','Clean configuration cancellation must throw OCE after verified one-time discard, never return lifecycle wrapping or publish schema/context.')
add('1992','compensation','Both material and cancellation initialization failure compose actual secondary Discard/IOException while retaining original kind, safe stage and cleanup until physical retry.')
add('1994','checkout','OwnerClosed gives faulted ODE/Closed; CallerAndOwner and OwnerThenCaller give canceled task/OCE/Canceled; same four-second clock interval and no Return/Cycle.')
add('1997','checkout','Owner-only closure timing is Closed, preserving caller-participation Canceled controls.')
add('2033','lateFactory','After public DrainTimeout, late actual failure retains PreparedPoolDispose stage and safe IOException; returned cleanup reaches physical deletion and succeeds on retry.')
add('2039','maintenance finally','Initial factory drain preserves existing SlotIdleRetire primary stage/safe message and cached exception with cleanup capability instead of replacing it with FactoryDrain.')
add('2111','nested','Nested safe DropOwned is retained with Rewarm and both safe cause types; no false Discard label may appear.')
add('2112','nested','Nested raw secondary retains Discard fallback through outer PoolDrain wrapping; private payload and inner exception remain absent.')
assert set(M)=={n['id'] for n in original['entries']} and len(M)==54
catalog=json.loads((OUT/'criterion15-maintenance-worker/fast/test-catalog.json').read_text())
for key,row in M.items():
 for method in row['tests']:
  assert any(n['name'].startswith('TurboTest.Tests.'+method) for n in catalog['all']), (key,method)
calpath=OUT/'final-calibration-v2/result.json'
cal=json.loads(calpath.read_text()) if calpath.exists() else None
calkeys={n['key'] for n in cal['results']} if cal else set()
for n in original['entries']:
 row=M[n['id']];row['original']=n
 row['evidenceKind']='current compiled exact-fault rejection plus executable contracts' if n['id'] in calkeys else 'current executable contract and bounded producer/source audit; no exact original fault execution claim'
 row['calibration']=str((OUT/'final-calibration-v2'/n['id']/'result.json').relative_to(OUT)) if n['id'] in calkeys else None
 row['currentSourceSha256']=sha(ROOT/n['file'])
 row['testSourceSha256']={t.split('.')[0]+'.cs':sha(ROOT/'tests/TurboTest.Tests'/(t.split('.')[0]+'.cs')) for t in row['tests']}
clauses=[
 {'criterion':1,'outcome':'Cancel observer, actual failure completes, then drain preserves safe error once and confirms cleanup','tests':[T['maintenance'],T['finally']],'evidence':'Existing accepted factory-ownership/factory-observer-race and final owning coverage/full ordinary run'},
 {'criterion':2,'outcome':'Owned timeout, observation deadline, caller interruption and owner/caller cancellation precedence are distinguished','tests':[T['ownedTimeout'],T['late'],T['lifetime'],T['precedence'],T['checkout']],'evidence':'Criteria1/2/14 with current1775/1776/1896/1897/1899/1994/1713/1997 compiled faults; accepted cancellation decision established flags before observer resumes'},
 {'criterion':3,'outcome':'Independent held initializer/callback and concurrent safe seed/callback/drain/retry failures retain identities and all child owners','tests':[T['lifetime'],T['four'],T['child'],T['realChildren']],'evidence':'Criterion3 genuine pre-repair RED: callback disappears despite child cleanup; criterion4 complete collection characterization, current causal-guard/retry-collection faults; actual nested PostgreSQL/Docker boundary'},
 {'criterion':4,'outcome':'Existing safe stages and meaningful secondary errors survive wrapping without arbitrary prose/order contract','tests':[T['nested'],T['idle'],T['rewarm'],T['drops'],T['reset'],T['startup'],T['configuration'],T['lateFactory']],'evidence':'Stage/type/SQLSTATE/redaction/capability assertions and current source producer audit; final per-lane coverage'},
 {'criterion':5,'outcome':'Repeated monitor Stop/Join preserves held callbacks/reader, releases CTS after both settle and delivers throwing callback once','tests':[T['monitor']],'evidence':'Accepted cleanup-lifetimes plus final exact201/210/211/212 faults'},
 {'criterion':6,'outcome':'Multiple independently failing static and retained startup owners remain observable and recoverable','tests':['StaticFailedDrainTests.Independently_failed_static_owners_keep_both_diagnostics_and_both_recovery_capabilities','CleanupOwnershipTests.Global_cleanup_reports_each_failed_owner_and_returns_a_capability_that_retries_them_all'],'evidence':'Already accepted cleanup-ownership slice (local7495ccf) and final full ordinary run; no new reclassification of prior evidence'},
 {'criterion':7,'outcome':'Every distinct failure and remaining capability in exercised startup/slot/factory paths reaches retry and confirmed physical cleanup','tests':[T['four'],T['child'],T['realChildren'],T['drops'],T['transfer'],T['compensation']],'evidence':'Four distinct stage/state pairs, four child handles+actual remaining host; nested actual two-child-host proof; finite attempts, exact deletion and repeat-retry idempotence'},
 {'criterion':8,'outcome':'TT012 bounded failed-test cleanup precedes this work; relevant TT024 owner/retention decisions settled','tests':[T['maintenance'],T['contexts'],T['lifetime'],T['monitor']],'evidence':'TT012 and TT024 archived investigations/verified local commits; criterion15 success-only worker refactor removes redundant ledger dependencies with source proof permitting reentrant Post'}
]
save(OUT/'question-dispositions-candidate.json',{'schemaVersion':1,'ticket':'TT-023','originalCount':54,'historicalStatusesUnchanged':True,'originalSourceSnapshot':original['sourceSnapshot'],'originalClassificationSha256':original['classificationSha256'],'entries':[M[n['id']] for n in original['entries']],'criteria':clauses,'directCurrentOriginalFaultCount':len(calkeys&set(M)),'currentRegressionFaults':['causal-guard','retry-collection','maintenance-success-only'],'finalCalibrationStatus':'terminal PASS' if cal else 'pending','qualification':'Candidate disposition matrix, not independent completion approval. Original mutation statuses preserved;25 original fault shapes and3 current regression faults are compiled on final source when complete. Remaining dispositions use executable maintained contract+bounded current producer/source proof, not a54fault replay. Original1924 useful success-release distinction is separately proved by prior one-off weak-node evidence and current source simplification. Broad claim that Delivered cannot precede worker check is superseded; proof permits reentrant synchronization-context Post.','pending':['final owning source/coverage/full520verification','independent completion verdict','local publication and conditional issue closure']})
print('54 original identities mapped to maintained methods; final calibration terminal:',bool(cal),flush=True)
