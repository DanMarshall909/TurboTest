"""Current-source taxonomy/Closed faults in the warm isolated build."""
from pathlib import Path
import sys,os,json,hashlib,xml.etree.ElementTree as E
ROOT=Path.cwd();OUT=ROOT/'artifacts/tt-023/diagnostic-closure';sys.path.insert(0,str(ROOT/'scripts'));import verify as v
before=v.source_identity();build=ROOT/'artifacts/tt-024/lifetimes/calibration-build';env=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1')
selection='FullyQualifiedName~Maintenance_cancellation_precedence|FullyQualifiedName~Admitted_checkout_distinguishes|FullyQualifiedName~Canceled_checkout_keeps|FullyQualifiedName~Canceled_observation_retains_an_already_completed'
condition='_shutdown.IsCancellationRequested && !cancellationToken.IsCancellationRequested'
items=[('1896','TtFactory.cs',condition,condition.replace(' && ',' || '),1,1),('1897','TtFactory.cs',condition,condition.replace('!cancellationToken','cancellationToken'),1,2),('1899','TtFactory.cs','throw new ObjectDisposedException(nameof(TtFactory<TContext>));',';',1,1),('1994','TtFactory.cs',condition,condition.replace(' && ',' || '),2,1),('1713','Internal/TtTelemetry.cs','ObjectDisposedException => "Closed"','ObjectDisposedException => ""',1,1),('1997','TtFactory.cs','outcome = "Closed";','outcome = "";',1,1)]
for key,relative,old,new,nth,count in items:
 out=OUT/('factory-'+key);out.mkdir();source=ROOT/'src/TurboTest.EFCore'/relative;original=source.read_text();assert original.count(old)>=nth
 start=-1
 for _ in range(nth):start=original.index(old,start+1)
 fault=out/source.name;fault.write_text(original[:start]+new+original[start+len(old):]);targets=out/'Fault.targets';targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="{relative}"/><Compile Include="{fault}"/></ItemGroup><Target Name="RecordFault" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{out}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
 v.run_phase('restore',['dotnet','restore',v.PROJECT,'--artifacts-path',str(build)],out,180,env)
 v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],out,180,env)
 inputs=(out/'compile.txt').read_text().splitlines();assert str(fault) in inputs and str(source) not in inputs
 dll=build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
 v.write_json(out/'binding.json',{'sourceIdentity':before,'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'faultSha256':hashlib.sha256(fault.read_bytes()).hexdigest(),'compile':inputs,'runtime':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dll.parent.rglob('*') if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
 try:v.run_phase('test',['dotnet','test',str(dll),'--filter',selection,'--results-directory',str(out/'results'),'--logger','trx;LogFileName=results.trx'],out,60,env)
 except v.VerificationError:pass
 r=json.loads((out/'test.json').read_text());assert r['exitCode']==1 and not r['deadlineExceeded'] and r['processGroupStopped']
 rows=E.parse(out/'results/results.trx').findall('.//{*}UnitTestResult');assert len(rows)==8
 failed=[{'name':n.get('testName'),'message':n.findtext('.//{*}Message')} for n in rows if n.get('outcome')!='Passed'];assert len(failed)==count and not any('TimeoutException' in n['message'] for n in failed)
 expected='Maintenance_cancellation_precedence' if key in ('1896','1897','1899') else 'Admitted_checkout_distinguishes'
 assert all(expected in n['name'] for n in failed) and before==v.source_identity() and source.read_text()==original
 v.write_json(out/'result.json',{'originalQuestion':key,'failed':failed,'passedControls':len(rows)-len(failed),'primaryInputsUnchanged':True,'qualification':'Exact current compiled fault; no historicalstatus/replay claim'})
 print(key,'intended taxonomy/structured-outcome rejection',count,'controls',len(rows)-count,flush=True)
restore=OUT/'factory-restored';restore.mkdir();targets=restore/'Original.targets';targets.write_text(f'''<Project><Target Name="RecordOriginal" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{restore}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],restore,180,env)
inputs=(restore/'compile.txt').read_text().splitlines();assert str(ROOT/'src/TurboTest.EFCore/TtFactory.cs') in inputs and str(ROOT/'src/TurboTest.EFCore/Internal/TtTelemetry.cs') in inputs
v.run_phase('test',['dotnet','test',str(dll),'--filter',selection,'--results-directory',str(restore/'results'),'--logger','trx;LogFileName=results.trx'],restore,60,env)
assert before==v.source_identity()
v.write_json(OUT/'criterion2-cycle.json',{'baseline':'Existing implemented behavior; all17owning factory rows pass. No product-defect RED claimed','calibration':'Six exact faults reject intended category/taskstatus/outcome assertions; receipts give distinct counts and unchanged primary identity','productionRefactor':'Useful caller-vs-shutdown guards and Closed categories retained; no source change','testRefactor':'Existing targeted pump controls flag requests before RunUntil(observer), separate actual failure ownership check, clock-derived telemetry; no callback identity guesses, no added stand-in','coverage':'criterion2-results cover own factory filter branches/general Closed and explicitClosed; independently assert outcomes not percentage alone','nextGate':'canonicalfast before next criterion'})
