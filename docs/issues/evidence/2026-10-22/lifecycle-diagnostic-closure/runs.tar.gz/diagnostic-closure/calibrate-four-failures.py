from pathlib import Path
import sys,os,json,hashlib,xml.etree.ElementTree as E
ROOT=Path.cwd();OUT=ROOT/'artifacts/tt-023/diagnostic-closure/four-failure-calibration';OUT.mkdir();sys.path.insert(0,str(ROOT/'scripts'));import verify as v
before=v.source_identity();source=ROOT/'src/TurboTest.EFCore/Tt.cs';original=source.read_text();old='failures.Add(retryError);';assert original.count(old)==1
fault=OUT/'Tt.cs';fault.write_text(original.replace(old,'_ = retryError; // Fault: omit retry failure collection.'));targets=OUT/'Fault.targets';targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="Tt.cs"/><Compile Include="{fault}"/></ItemGroup><Target Name="RecordFault" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{OUT}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
build=ROOT/'artifacts/tt-024/lifetimes/calibration-build';env=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1',DOCKER_HOST=v.DOCKER_HOST)
v.run_phase('restore',['dotnet','restore',v.PROJECT,'--artifacts-path',str(build)],OUT,180,env)
v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],OUT,180,env)
inputs=(OUT/'compile.txt').read_text().splitlines();assert str(fault) in inputs and str(source) not in inputs;dll=build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
v.write_json(OUT/'binding.json',{'sourceIdentity':before,'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'faultSha256':hashlib.sha256(fault.read_bytes()).hexdigest(),'compile':inputs,'runtime':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dll.parent.rglob('*') if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
selection='FullyQualifiedName~Startup_recovery_preserves_four_distinct|FullyQualifiedName~Initializer_child_cleanup_does_not_hide|FullyQualifiedName~Startup_recovery_reports_cancellation_drain_and_retry'
resources=v.docker_inventory(OUT,'resources-before',env)
try:
 try:v.run_phase('test',['dotnet','test',str(dll),'--filter',selection,'--results-directory',str(OUT/'results'),'--logger','trx;LogFileName=results.trx'],OUT,180,env)
 except v.VerificationError:pass
finally:
 after=v.docker_inventory(OUT,'resources-after',env);assert resources==after
r=json.loads((OUT/'test.json').read_text());assert r['exitCode']==1 and not r['deadlineExceeded'] and r['processGroupStopped'];rows=E.parse(OUT/'results/results.trx').findall('.//{*}UnitTestResult');assert len(rows)==5
failed=[{'name':n.get('testName'),'message':n.findtext('.//{*}Message')} for n in rows if n.get('outcome')!='Passed'];assert len(failed)==2
assert any('Startup_recovery_preserves_four_distinct' in n['name'] and 'HostRetry' in n['message'] for n in failed)
assert any('Startup_recovery_reports_cancellation_drain_and_retry' in n['name'] and 'RetryHostDelete' in n['message'] for n in failed)
assert before==v.source_identity() and source.read_text()==original
v.write_json(OUT/'result.json',{'failed':failed,'passedControls':3,'resourcesEqual':resources==after,'primaryInputsUnchanged':True,'qualification':'Omit safe retry failure from current collection; discard read preserves compile semantics. Two intended identity losses; no historical replay.'});print('retry collection rejected by full-safe and existing raw compound cases;3controls pass',flush=True)
restore=OUT/'restored';restore.mkdir();targets=restore/'Original.targets';targets.write_text(f'''<Project><Target Name="RecordOriginal" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{restore}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],restore,180,env)
inputs=(restore/'compile.txt').read_text().splitlines();assert str(source) in inputs and str(fault) not in inputs
resources=v.docker_inventory(restore,'resources-before',env)
try:v.run_phase('test',['dotnet','test',str(dll),'--filter',selection,'--results-directory',str(restore/'results'),'--logger','trx;LogFileName=results.trx'],restore,180,env)
finally:assert resources==v.docker_inventory(restore,'resources-after',env)
assert before==v.source_identity();print('restored5rows pass',flush=True)
