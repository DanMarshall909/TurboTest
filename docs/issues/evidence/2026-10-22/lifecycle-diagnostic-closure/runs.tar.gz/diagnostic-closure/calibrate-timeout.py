"""Two current-source timeout faults; no historical Stryker replay claim."""
from pathlib import Path
import sys,os,json,hashlib,xml.etree.ElementTree as E
ROOT=Path.cwd();OUT=ROOT/'artifacts/tt-023/diagnostic-closure';sys.path.insert(0,str(ROOT/'scripts'));import verify as v
source=ROOT/'src/TurboTest.EFCore/Tt.cs';original=source.read_text();build=ROOT/'artifacts/tt-024/lifetimes/calibration-build';env=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1')
v.run_phase('criterion1-final-build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','-nr:false','-p:UseSharedCompilation=false'],OUT,180,env)
before=v.source_identity();v.write_json(OUT/'criterion1-final-source.json',before)
v.run_phase('criterion1-final-coverage',['dotnet','test',v.PROJECT,'--no-build','-c','Release','--filter','FullyQualifiedName~StartupLateDrainTests','--collect','Code Coverage;Format=cobertura','--results-directory',str(OUT/'criterion1-final-results'),'--logger','trx;LogFileName=results.trx'],OUT,60,env)
selection='FullyQualifiedName~An_initializer_owned_timeout|FullyQualifiedName~Interrupted_startup_reports_the_actual_late_initializer_failure_once'
faults=[('1775','error is TimeoutException && !ReferenceEquals','error is TimeoutException || !ReferenceEquals'),('1776','!ReferenceEquals(initialization.Exception?.InnerException, error)','ReferenceEquals(initialization.Exception?.InnerException, error)')]
for key,old,new in faults:
 out=OUT/('timeout-'+key);out.mkdir();assert original.count(old)==1
 fault=out/'Tt.cs';fault.write_text(original.replace(old,new));targets=out/'Fault.targets';targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="Tt.cs"/><Compile Include="{fault}"/></ItemGroup><Target Name="RecordFault" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{out}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
 v.run_phase('restore',['dotnet','restore',v.PROJECT,'--artifacts-path',str(build)],out,180,env)
 v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],out,180,env)
 inputs=(out/'compile.txt').read_text().splitlines();assert str(fault) in inputs and str(source) not in inputs
 dll=build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
 v.write_json(out/'binding.json',{'sourceIdentity':before,'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'faultSha256':hashlib.sha256(fault.read_bytes()).hexdigest(),'compile':inputs,'runtime':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dll.parent.rglob('*') if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
 try:v.run_phase('test',['dotnet','test',str(dll),'--filter',selection,'--results-directory',str(out/'results'),'--logger','trx;LogFileName=results.trx'],out,40,env)
 except v.VerificationError:pass
 r=json.loads((out/'test.json').read_text());assert r['exitCode']==1 and not r['deadlineExceeded'] and r['processGroupStopped']
 rows=E.parse(out/'results/results.trx').findall('.//{*}UnitTestResult');failed=[{'name':n.get('testName'),'message':n.findtext('.//{*}Message')} for n in rows if n.get('outcome')!='Passed'];assert len(rows)==11
 own=[n for n in failed if 'An_initializer_owned_timeout' in n['name']];assert len(own)==1 and 'BaselineInitialize' in own[0]['message'] and 'StartupTimeout' in own[0]['message']
 assert len(failed)==(1 if key=='1775' else 6)
 assert before==v.source_identity() and source.read_text()==original
 v.write_json(out/'result.json',{'originalQuestion':key,'failed':failed,'passedControls':len(rows)-len(failed),'primaryInputsUnchanged':True,'qualification':'Current exact compiled fault; no historical mutant status change'})
 print(key,'intended safeStage rejection',len(failed),'failed',len(rows)-len(failed),'controls',flush=True)
restore=OUT/'timeout-restored';restore.mkdir();targets=restore/'Original.targets';targets.write_text(f'''<Project><Target Name="RecordOriginal" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{restore}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],restore,180,env)
inputs=(restore/'compile.txt').read_text().splitlines();assert str(source) in inputs and not any('/timeout-177' in n for n in inputs)
v.run_phase('test',['dotnet','test',str(dll),'--filter',selection,'--results-directory',str(restore/'results'),'--logger','trx;LogFileName=results.trx'],restore,40,env)
assert before==v.source_identity()
v.write_json(OUT/'criterion1-cycle.json',{'baseline':'Existing behavior;21owning rows pass. No defect RED claimed','calibration':'1775exactOR:1safeStage failure+10controls;1776exactnegation:ownedStage+5wrong observation completion failures+5controls','coverage':'Inspect criterion1-final-results; immediate owned timeout executes missing interrupted predicate branch','productionRefactor':'Existing reference/kind distinction is useful; retained unchanged','testRefactor':'Reuse actual ledger; bounded finally explicitly retries unexpected retained handle so misclassification fault settles too','nextGate':'canonicalfast before next criterion'})
