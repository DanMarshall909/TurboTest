from pathlib import Path
exec(Path('artifacts/tt-023/diagnostic-closure/diagnostic-identity-cycles.py').read_text().split('# Criterion5:')[0])
p=ROOT/'tests/TurboTest.Tests/FactoryMaintenanceTests.cs';s=p.read_text();start=s.index('    [Theory]');end=s.index('\n    [Fact]',start);body=s[start:end];old='''    [InlineData(false)]
    [InlineData(true)]
    public async Task Maintenance_cancellation_precedence_preserves_actual_failure_until_owner_drain(bool callerCancellation)''';assert body.count(old)==1;body=body.replace(old,'''    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public async Task Maintenance_cancellation_precedence_preserves_actual_failure_until_owner_drain(bool callerCancellation, bool shutdownFirst)''');old='''                    if (callerCancellation)
                        Task.Run(() => caller.Cancel()).WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult();''';assert body.count(old)==1;body=body.replace(old,old.replace('if (callerCancellation)','if (callerCancellation && !shutdownFirst)'));old='                    closing = factory.DisposeAsync().AsTask();';assert body.count(old)==1;body=body.replace(old,old+'''
                    if (callerCancellation && shutdownFirst)
                        Task.Run(() => caller.Cancel()).WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult();''');p.write_text(s[:start]+body+s[end:])
p=ROOT/'tests/TurboTest.Tests/FactoryTimingTests.cs';s=p.read_text();start=s.index('    [Theory]');end=s.index('\n    [Fact]',start);body=s[start:end];old='    [InlineData("CallerAndOwner")]';assert body.count(old)==1;body=body.replace(old,old+'\n    [InlineData("OwnerThenCaller")]');old='                        closing = factory.DisposeAsync().AsTask();';assert body.count(old)==1;body=body.replace(old,old+'''
                        if (cause == "OwnerThenCaller")
                            Task.Run(() => caller.Cancel()).WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult();''');old='\n            if (cause == "CallerAndOwner")\n';assert body.count(old)==1;body=body.replace(old,'\n            if (cause is "CallerAndOwner" or "OwnerThenCaller")\n');old='cause == "CallerAndOwner" ? "Canceled" : "Closed"';assert body.count(old)==1;body=body.replace(old,'cause is "CallerAndOwner" or "OwnerThenCaller" ? "Canceled" : "Closed"');p.write_text(s[:start]+body+s[end:])
condition='_shutdown.IsCancellationRequested && !cancellationToken.IsCancellationRequested'
maint='''catch (OperationCanceledException) when ('''+condition+''')
        {
            throw new ObjectDisposedException(nameof(TtFactory<TContext>));'''
checkout='''catch (OperationCanceledException) when ('''+condition+''')
        {
            outcome = "Closed";'''
selection='FullyQualifiedName~Maintenance_cancellation_precedence|FullyQualifiedName~Admitted_checkout_distinguishes|FullyQualifiedName~Canceled_checkout_keeps|FullyQualifiedName~Canceled_observation_retains_an_already_completed'
finish('criterion14-cancellation-request-order','FullyQualifiedName~FactoryMaintenanceTests|FullyQualifiedName~FactoryTimingTests',[
 ('1896','TtFactory.cs',maint,maint.replace(' && ',' || '),selection,2,10,'False',None),
 ('1897','TtFactory.cs',maint,maint.replace('!cancellationToken','cancellationToken'),selection,3,10,'False',None),
 ('1899','TtFactory.cs',maint,maint.replace('throw new ObjectDisposedException(nameof(TtFactory<TContext>));',';'),selection,1,10,'True',None),
 ('1994','TtFactory.cs',checkout,checkout.replace(' && ',' || '),selection,2,10,'OperationCanceledException',None),
 ('1713','Internal/TtTelemetry.cs','ObjectDisposedException => "Closed"','ObjectDisposedException => ""',selection,1,10,'Closed',None),
 ('1997','TtFactory.cs','outcome = "Closed";','outcome = "";',selection,1,10,'Closed',None)
],'Add both caller-first and owner-first requests before target observer resumes. Existing controlled pump holds actual work and establishes both flags; assert caller category/taskstatus and safe late failure ownership. Existing caller-only and owner-only controls remain. No wall-clock simultaneity claim or opaque continuation guesses.')
