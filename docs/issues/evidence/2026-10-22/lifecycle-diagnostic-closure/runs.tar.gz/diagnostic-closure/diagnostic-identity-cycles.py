"""Three sequential characterization/coverage/calibration/refactor/fast cycles."""
from pathlib import Path
import sys,os,json,hashlib,xml.etree.ElementTree as E
ROOT=Path.cwd();OUT=ROOT/'artifacts/tt-023/diagnostic-closure';sys.path.insert(0,str(ROOT/'scripts'));import verify as v
BUILD=ROOT/'artifacts/tt-024/lifetimes/calibration-build';ENV=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(path):return E.parse(path).findall('.//{*}UnitTestResult')
def build(out,targets=None,isolated=False):
 cmd=['dotnet','build',v.PROJECT,'--no-restore','-c','Release','-nr:false','-p:UseSharedCompilation=false']
 if isolated:cmd+=['--artifacts-path',str(BUILD)]
 if targets:cmd+=['-p:CustomBeforeMicrosoftCommonTargets='+str(targets)]
 v.run_phase('build',cmd,out,180,ENV)
def run_test(out,selection,isolated=False,coverage=False):
 project=str(BUILD/'bin/TurboTest.Tests/release/TurboTest.Tests.dll') if isolated else v.PROJECT
 cmd=['dotnet','test',project]
 if not isolated:cmd+=['--no-build','-c','Release']
 cmd+=['--filter',selection,'--results-directory',str(out/'results'),'--logger','trx;LogFileName=results.trx']
 if coverage:cmd+=['--collect','Code Coverage;Format=cobertura']
 v.run_phase('test',cmd,out,60,ENV)
def calibration(out,key,relative,old,new,selection,expected_count,total,needle,expected_case=None):
 out.mkdir();source=ROOT/'src/TurboTest.EFCore'/relative;original=source.read_text();assert original.count(old)==1;fault=out/source.name;fault.write_text(original.replace(old,new));targets=out/'Fault.targets';targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="{relative}"/><Compile Include="{fault}"/></ItemGroup><Target Name="RecordFault" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{out}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
 before=v.source_identity();v.run_phase('restore',['dotnet','restore',v.PROJECT,'--artifacts-path',str(BUILD)],out,180,ENV);build(out,targets,True)
 inputs=(out/'compile.txt').read_text().splitlines();assert str(fault) in inputs and str(source) not in inputs
 dll=BUILD/'bin/TurboTest.Tests/release/TurboTest.Tests.dll';v.write_json(out/'binding.json',{'sourceIdentity':before,'compile':inputs,'originalSha256':sha(source),'faultSha256':sha(fault),'runtime':{str(p.relative_to(BUILD)):sha(p) for p in dll.parent.rglob('*') if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
 try:run_test(out,selection,True)
 except v.VerificationError:pass
 r=json.loads((out/'test.json').read_text());assert r['exitCode']==1 and not r['deadlineExceeded'] and r['processGroupStopped'];allrows=rows(out/'results/results.trx');assert len(allrows)==total
 failed=[{'name':n.get('testName'),'message':n.findtext('.//{*}Message')} for n in allrows if n.get('outcome')!='Passed'];assert len(failed)==expected_count and all(needle in n['message'] and 'TimeoutException' not in n['message'] for n in failed)
 if expected_case:assert all(expected_case in n['name'] for n in failed)
 assert before==v.source_identity();v.write_json(out/'result.json',{'originalQuestion':key,'failed':failed,'passedControls':total-expected_count,'primaryInputsUnchanged':True,'qualification':'Exact current compiled fault; original statuses unchanged; not historical replay'})
 print(key,'expected diagnostic rejection, controls',total-expected_count,flush=True)
def finish(phase,selection,mutations,refactor):
 out=OUT/phase;out.mkdir();build(out);before=v.source_identity();v.write_json(out/'source.json',before);run_test(out,selection,coverage=True);passed=rows(out/'results/results.trx');assert all(n.get('outcome')=='Passed' for n in passed)
 for item in mutations:calibration(out/('fault-'+item[0]),*item)
 restore=out/'restored';restore.mkdir();targets=restore/'Original.targets';targets.write_text(f'''<Project><Target Name="RecordOriginal" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{restore}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''');build(restore,targets,True);inputs=(restore/'compile.txt').read_text().splitlines();assert not any('/fault-' in p for p in inputs);run_test(restore,selection,True);assert before==v.source_identity()
 coverage=next((out/'results').glob('*/*.cobertura.xml'));owners={Path(c.get('filename','')).name for c in E.parse(coverage).findall('.//class') if any(int(n.get('hits'))>0 for n in c.findall('./lines/line'))};assert 'TtLifecycleException.cs' in owners or 'TtTelemetry.cs' in owners or 'TtFactory.cs' in owners
 v.write_json(out/'cycle.json',{'owningPassed':len(passed),'baseline':'Existing production behavior; characterization, no product defect RED','assertions':'Structured identities with nonempty heterogeneous controls; fault must fail intended named identity, no prose/order pin','productionRefactor':'Retain useful documented diagnostics and safe stage paths; no production edit required','testRefactor':refactor,'coverage':str(coverage),'ownersExecuted':sorted(owners),'calibration':'Exact compiled faults bind this source cut; primary inputs unchanged; warm build restored','nextGate':'canonicalfast before following criterion'})
 v.run_phase('canonical-fast',['python3','scripts/verify.py','fast','--output',str(out/'fast')],out,240,ENV);assert json.loads((out/'fast/verification.json').read_text())['result']=='PASS';assert before==v.source_identity();print(phase,'owning+coverage+calibration+refactor+canonicalfast PASS',flush=True)
# Criterion5: documented numeric and named event identity, using existing public timing rows.
p=ROOT/'tests/TurboTest.Tests/FactoryTimingTests.cs';s=p.read_text();old='            Assert.Equal(4, logger.Records.Count);';assert s.count(old)==1;s=s.replace(old,old+'\n            Assert.Equal(4, logger.Events.Count);\n            Assert.All(logger.Events, entry => Assert.Equal((402, "PoolTiming"), (entry.Id, entry.Name)));')
old='        internal ConcurrentQueue<Dictionary<string, object?>> Records { get; } = new();';assert s.count(old)==1;s=s.replace(old,old+'\n        internal ConcurrentQueue<EventId> Events { get; } = new();');old='            Records.Enqueue(record);';assert s.count(old)==1;s=s.replace(old,'            Events.Enqueue(eventId);\n'+old);p.write_text(s)
finish('criterion5-event-name','FullyQualifiedName~FactoryTimingTests',[('1718','Internal/TtTelemetry.cs','new EventId(402, "PoolTiming")','new EventId(402, "")','FullyQualifiedName~Public_timings_cover_checkout_shared_return_cycle_and_actual_shutdown|FullyQualifiedName~Throwing_diagnostic_observers_preserve',1,3,'PoolTiming',None)],'Record the actual EventId beside existing state; four real emitted records make name/number assertions nonvacuous. No new test fixture; compare both fields explicitly.')
# Criterion6: aggregate maintenance's primary lifecycle identity on the existing two-failure scenario.
p=ROOT/'tests/TurboTest.Tests/FactoryMaintenanceTests.cs';s=p.read_text();start=s.index('    public async Task Bulk_maintenance_reports_all_safe_failures');end=s.index('\n    [Fact]',start);body=s[start:end];old='            var failure = await Assert.ThrowsAsync<TtLifecycleException>(() => maintenance);';assert body.count(old)==1;body=body.replace(old,old+'\n            Assert.Equal("IdleMaintenance", failure.Stage);');p.write_text(s[:start]+body+s[end:])
finish('criterion6-maintenance-stage','FullyQualifiedName~FactoryMaintenanceTests',[('1919','TtFactory.cs','new TtLifecycleException("IdleMaintenance", aggregate)','new TtLifecycleException("", aggregate)','FullyQualifiedName~Bulk_maintenance_reports_all_safe_failures|FullyQualifiedName~Canceled_observation_retains_an_already_completed',1,3,'IdleMaintenance',None)],'Add one stable Stage assertion to existing actual two-slot failure/physical recovery scenario; no duplicate setup or native case.')
# Criterion7: nested raw and known lifecycle secondary identities retain the correct labels.
p=ROOT/'tests/TurboTest.Tests/LifecycleDiagnosticRetentionTests.cs';s=p.read_text();old='''    [Fact]
    public void Wrapping_a_recovery_failure_retains_all_safe_diagnostics_without_private_payloads()''';assert s.count(old)==1;s=s.replace(old,'''    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Wrapping_a_recovery_failure_retains_all_safe_diagnostics_without_private_payloads(bool safeSecondary)''');old='        var recovery = original.WithCleanupFailure(new UnauthorizedAccessException("private-cleanup-payload"));';assert s.count(old)==1;s=s.replace(old,'''        Exception secondary = new UnauthorizedAccessException("private-cleanup-payload");
        if (safeSecondary) secondary = new TtLifecycleException("DropOwned", secondary);
        var recovery = original.WithCleanupFailure(secondary);''');old='        Assert.Contains("IOException", drain.Message);';assert s.count(old)==1;s=s.replace(old,'''        Assert.Equal("PoolDrain", drain.Stage);
        Assert.Contains("Rewarm", drain.Message);
        Assert.Contains(safeSecondary ? "DropOwned" : "Discard", drain.Message);
        if (safeSecondary) Assert.DoesNotContain("Discard", drain.Message);
'''+old);p.write_text(s)
old='(cleanupFailure as TtLifecycleException)?.Stage ?? "Discard"'
finish('criterion7-nested-secondary','FullyQualifiedName~LifecycleDiagnosticRetentionTests',[('2111','TtLifecycleException.cs',old,'"Discard"','FullyQualifiedName~LifecycleDiagnosticRetentionTests',1,2,'Discard','safeSecondary: True'),('2112','TtLifecycleException.cs',old,'(cleanupFailure as TtLifecycleException)?.Stage ?? ""','FullyQualifiedName~LifecycleDiagnosticRetentionTests',1,2,'Discard','safeSecondary: False')],'Extend existing nested-wrap test with one genuinely distinct safe secondary; check original primary, named secondary or raw Discard, safe kinds/redaction, and absence of false Discard identity. No full message/order checks.')
