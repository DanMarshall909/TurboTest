from pathlib import Path
exec(Path('artifacts/tt-023/diagnostic-closure/diagnostic-identity-cycles.py').read_text().split('# Criterion5:')[0])
p=ROOT/'tests/TurboTest.Tests/FactoryBackpressureTests.cs';s=p.read_text();marker='public class FactoryBackpressureTests\n{';assert s.count(marker)==1;s=s.replace(marker,marker+'''
    [Fact]
    public async Task Repeated_failed_acquisitions_release_completed_contexts_and_work_while_the_factory_remains_usable()
    {
        await using var pool = new BoundedPool();
        var factory = new TtFactory<CancelingConfigurationContext>(pool,
            new TtOptions { AutoMigrate = false }, ownsPool: true);
        try
        {
            var completed = await Task.Run(() => CompleteFailedContexts(factory, 16));
            Assert.Equal(16, completed.Length);
            GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced, blocking: true, compacting: true);
            GC.WaitForPendingFinalizers();
            GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced, blocking: true, compacting: true);
            Assert.All(completed, entry =>
            {
                Assert.False(entry.Context.IsAlive);
                Assert.False(entry.Acquisition.IsAlive);
            });
            Assert.Equal((16, 0), (pool.Deleted, factory.PoolState.Reserved));
            var next = await Task.Run(() => CompleteFailedContexts(factory, 1));
            Assert.Single(next);
            Assert.Equal((17, 0), (pool.Deleted, factory.PoolState.Reserved));
            GC.KeepAlive(factory);
        }
        finally { await factory.DisposeAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(2)); }
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static (WeakReference Context, WeakReference Acquisition)[] CompleteFailedContexts(
        TtFactory<CancelingConfigurationContext> factory, int count)
    {
        var completed = new List<(WeakReference, WeakReference)>();
        for (var i = 0; i < count; i++)
        {
            using var caller = new CancellationTokenSource();
            var probe = new ConfigurationCancellationProbe(caller);
            NextConfigurationProbe = probe;
            try
            {
                var acquiring = factory.CreateLeaseAsync(cancellationToken: caller.Token);
                Assert.ThrowsAny<OperationCanceledException>(() => acquiring.WaitAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult());
                Assert.Equal((1, 0, 1), (probe.Configurations, probe.SchemaInitializations, probe.Disposals));
                completed.Add((Assert.IsType<WeakReference>(probe.Context), new WeakReference(acquiring)));
            }
            finally { NextConfigurationProbe = null; }
        }
        return completed.ToArray();
    }
''',1)
start=s.index('    private sealed class ConfigurationCancellationProbe');end=s.index('\n    public sealed class CancelingConfigurationContext',start);body=s[start:end];old='        internal int Disposals;';assert body.count(old)==1;body=body.replace(old,old+'\n        internal WeakReference? Context;');s=s[:start]+body+s[end:]
old='''            _probe = NextConfigurationProbe ?? throw new InvalidOperationException("Missing configuration cancellation probe.");
            NextConfigurationProbe = null;''';assert s.count(old)==1;s=s.replace(old,old+'\n            _probe.Context = new WeakReference(this);');p.write_text(s)
finish('criterion13-failed-context-lifetime','FullyQualifiedName~FactoryBackpressureTests',[
 ('1984','TtFactory.cs','finally { _databases.TryRemove(database, out _); }','finally { }','FullyQualifiedName~Repeated_failed_acquisitions_release_completed|FullyQualifiedName~Repeated_successful_leases_release_completed|FullyQualifiedName~Cancellation_from_context_configuration_prevents_schema',1,3,'False','Repeated_failed_acquisitions_release_completed')
],'Reuse actual existing canceled-configuration context and bounded resource pool. No-inline worker returns only weak context/task references after16completed failures, with factory explicitly kept alive and17threquest proving reuse. This targets completed failed acquisition removal, distinct from successful lease removal and pending ownership. No private reflection/new stand-in.')
