"""Recompile retained behavioral faults against the single final compiler/test snapshot."""
from pathlib import Path
import sys,os,json,hashlib,subprocess,difflib,xml.etree.ElementTree as E
ROOT=Path.cwd();OUT=ROOT/'artifacts/tt-023/diagnostic-closure';FINAL=OUT/'final-calibration-v2';FINAL.mkdir(exist_ok=True);sys.path.insert(0,str(ROOT/'scripts'));import verify as v
BUILD=ROOT/'artifacts/tt-024/lifetimes/calibration-build';ENV=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1',DOCKER_HOST=v.DOCKER_HOST)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tree_rows(p):return E.parse(p).findall('.//{*}UnitTestResult')
def build(out,targets=None,isolated=True):
 cmd=['dotnet','build',v.PROJECT,'--no-restore','-c','Release','-nr:false','-p:UseSharedCompilation=false']
 if isolated:cmd+=['--artifacts-path',str(BUILD)]
 if targets:cmd+=['-p:CustomBeforeMicrosoftCommonTargets='+str(targets)]
 v.run_phase('build',cmd,out,180,ENV)
build(FINAL,isolated=False);binding=v.source_identity()
if (FINAL/'source.json').exists():assert json.loads((FINAL/'source.json').read_text())==binding
else:v.write_json(FINAL/'source.json',binding)
def normalized(message):return '\n'.join(line for line in message.splitlines() if not line.lstrip().startswith('at '))
def resource_ids(inventory):return set(inventory)

existing=[('1775','timeout-1775'),('1776','timeout-1776')]
existing += [(key,'criterion14-cancellation-request-order/fault-'+key) for key in ['1896','1897','1899','1994','1713','1997']]
existing += [('1718','criterion5-event-name/fault-1718'),('1919','criterion6-maintenance-stage/fault-1919'),('2111','criterion7-nested-secondary/fault-2111'),('2112','criterion7-nested-secondary/fault-2112')]
existing += [(key,'criterion8-safe-idle-stages/fault-'+key) for key in ['1317','1396','1397']]
existing += [('1354','criterion9-terminal-delivery/fault-1354')]+[(key,'criterion10-first-terminal-identity/fault-'+key) for key in ['1598','1645']]
existing += [('1604','criterion11-rewarm-marker-transfer/fault-1604'),('1703','criterion12-slot-drain-errors/fault-1703'),('1984','criterion13-failed-context-lifetime/fault-1984'),('causal-guard','child-cleanup-calibration'),('retry-collection','four-failure-calibration'),('maintenance-success-only','criterion15-maintenance-worker/fault-failure-release')]
specs=[]
for key,folder in existing:
 oldout=OUT/folder;meta=json.loads((oldout/'binding.json').read_text());oldresult=json.loads((oldout/'result.json').read_text());command=json.loads((oldout/'test.json').read_text())['command'];selection=command[command.index('--filter')+1];faults=list(oldout.glob('*.cs'));assert len(faults)==1;oldfault=faults[0];name=oldfault.name
 relative=name if name in {'Tt.cs','TtFactory.cs','TtLifecycleException.cs'} else 'Internal/'+name;source=ROOT/'src/TurboTest.EFCore'/relative;current=source.read_text();faulttext=oldfault.read_text()
 if sha(source)!=meta['originalSha256']:
  assert name in {'Tt.cs','TtFactory.cs'};oldoriginal=subprocess.check_output(['git','show','e18d7e1418890a0a7f39a1bb9d2116580b4cefcb:'+str(source.relative_to(ROOT))]).decode();assert hashlib.sha256(oldoriginal.encode()).hexdigest()==meta['originalSha256'];changed=current
  for tag,a,b,c,d in reversed(difflib.SequenceMatcher(None,oldoriginal,faulttext,autojunk=False).get_opcodes()):
   if tag=='equal':continue
   left=max(0,a-80);right=min(len(oldoriginal),b+80);anchor=oldoriginal[left:right];replacement=oldoriginal[left:a]+faulttext[c:d]+oldoriginal[b:right];assert changed.count(anchor)==1;changed=changed.replace(anchor,replacement)
  faulttext=changed
 specs.append({'key':key,'relative':relative,'fault':faulttext,'selection':selection,'failed':oldresult['failed'],'controls':oldresult['passedControls'],'prior':folder})
monitor=ROOT/'src/TurboTest.EFCore/Internal/TtCapacityMonitor.cs';original=monitor.read_text();catalog=json.loads((OUT/'criterion14-cancellation-request-order/fast/test-catalog.json').read_text());names=[n['name'] for n in catalog['all'] if '.CapacityMonitorTests.Repeated_stop_and_join_keep_cancellation_alive' in n['name']];assert len(names)==2
for key,old,new,count,needle in [('201','if (_stopping) return;',';',2,'ObjectDisposedException'),('210','if (_terminalObserved) return;','if (!_terminalObserved) return;',2,'True'),('211','if (_terminalObserved) return;','if (_terminalObserved) { }',1,'Assert.Single'),('212','_terminalObserved = true;','_terminalObserved = false;',1,'Assert.Single')]:
 assert original.count(old)==1;specs.append({'key':key,'relative':'Internal/TtCapacityMonitor.cs','fault':original.replace(old,new),'selection':'FullyQualifiedName~Repeated_stop_and_join_keep_cancellation_alive','failedNames':names if count==2 else [n for n in names if 'throwingCallback: True' in n],'needle':needle,'controls':2-count,'prior':'current exact original fault on unchanged monitor source'})
assert len(specs)==28
def validate(spec,out):
 receipt=json.loads((out/'test.json').read_text())
 assert receipt['exitCode']==1 and not receipt['deadlineExceeded'] and receipt['processGroupStopped'] and not v.group_members(receipt['processGroupId'])
 meta=json.loads((out/'binding.json').read_text());source=ROOT/'src/TurboTest.EFCore'/spec['relative'];fault=out/source.name
 assert meta['sourceIdentity']==binding and meta['currentOriginalSha256']==sha(source) and meta['faultSha256']==sha(fault)
 assert fault.read_text()==spec['fault'] and str(fault) in meta['compile'] and str(source) not in meta['compile']
 allrows=tree_rows(out/'results/results.trx')
 failed=[{'name':n.get('testName'),'message':n.findtext('.//{*}Message')} for n in allrows if n.get('outcome')!='Passed']
 if 'failed' in spec:
  expected={n['name']:normalized(n['message']) for n in spec['failed']};actual={n['name']:normalized(n['message']) for n in failed};assert actual==expected,(spec['key'],actual,expected)
 else:
  assert {n['name'] for n in failed}==set(spec['failedNames']) and all(spec['needle'] in n['message'] and 'TimeoutException' not in n['message'] for n in failed),(spec['key'],failed)
 assert len(allrows)==len(failed)+spec['controls'] and all(n.get('outcome')=='Passed' for n in allrows if n.get('outcome')!='Failed')
 native='Nested_startup_failures_keep' in spec['selection']
 if native:
  before={n['ID'] for n in json.loads((out/'resources-before-containers.json').read_text())};after={n['ID'] for n in json.loads((out/'resources-after-containers.json').read_text())};assert before==after
 assert binding==v.source_identity()
 result={'key':spec['key'],'failed':failed,'passedControls':spec['controls'],'primaryInputsUnchanged':True,'nativeResourceSettlement':True if native else 'not applicable','qualification':'Current final-source compiled fault. Historical statuses unchanged; no historical Stryker replay. Comparison ignores stack-frame lines only; diagnostic/assertion text and test/control identities remain exact.'}
 v.write_json(out/'result.json',result)
 print('final calibration',spec['key'],'rejected',len(failed),'controls',spec['controls'],flush=True)
 return result
results=[];faultpaths=[];dll=BUILD/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
for spec in specs:
 out=FINAL/spec['key'];source=ROOT/'src/TurboTest.EFCore'/spec['relative'];fault=out/source.name;faultpaths.append(str(fault))
 if (out/'test.json').exists():
  results.append(validate(spec,out));continue
 out.mkdir();fault.write_text(spec['fault']);targets=out/'Fault.targets'
 targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="{spec['relative']}"/><Compile Include="{fault}"/></ItemGroup><Target Name="RecordFault" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{out}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
 v.run_phase('restore',['dotnet','restore',v.PROJECT,'--artifacts-path',str(BUILD)],out,180,ENV);build(out,targets)
 inputs=(out/'compile.txt').read_text().splitlines();assert str(fault) in inputs and str(source) not in inputs
 v.write_json(out/'binding.json',{'sourceIdentity':binding,'currentOriginalSha256':sha(source),'faultSha256':sha(fault),'compile':inputs,'priorEvidence':spec['prior'],'runtime':{str(p.relative_to(BUILD)):sha(p) for p in dll.parent.rglob('*') if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
 native='Nested_startup_failures_keep' in spec['selection'];resources=v.docker_inventory(out,'resources-before',ENV) if native else None
 try:
  try:v.run_phase('test',['dotnet','test',str(dll),'--filter',spec['selection'],'--results-directory',str(out/'results'),'--logger','trx;LogFileName=results.trx'],out,180 if native else 60,ENV)
  except v.VerificationError:pass
 finally:
  if native:assert resources==v.docker_inventory(out,'resources-after',ENV)
 results.append(validate(spec,out))
restore=FINAL/'restored';restore.mkdir();targets=restore/'Original.targets';targets.write_text(f'''<Project><Target Name="RecordOriginal" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{restore}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''');build(restore,targets);inputs=(restore/'compile.txt').read_text().splitlines();assert not set(faultpaths)&set(inputs)
selection='Category!=PostgreSQL|FullyQualifiedName~Nested_startup_failures_keep';resources=v.docker_inventory(restore,'resources-before',ENV)
try:v.run_phase('test',['dotnet','test',str(dll),'--filter',selection,'--results-directory',str(restore/'results'),'--logger','trx;LogFileName=results.trx'],restore,180,ENV)
finally:assert resource_ids(resources)==resource_ids(v.docker_inventory(restore,'resources-after',ENV))
rows=tree_rows(restore/'results/results.trx');assert len(rows)==349 and all(n.get('outcome')=='Passed' for n in rows);assert binding==v.source_identity();v.write_json(FINAL/'result.json',{'faults':len(results),'results':results,'restoredPassed':len(rows),'primaryInputsUnchanged':True,'wholeSessionMutation':'pending final coding-session snapshot','historicalStatusesUnchanged':True});print('28 final calibrations and restored349rows terminal PASS',flush=True)
