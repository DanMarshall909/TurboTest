from pathlib import Path
import sys,os,json,xml.etree.ElementTree as E
ROOT=Path.cwd();OUT=ROOT/'artifacts/tt-023/diagnostic-closure';FINAL=OUT/'final-verification';FINAL.mkdir();sys.path.insert(0,str(ROOT/'scripts'));import verify as v
ENV=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1',DOCKER_HOST=v.DOCKER_HOST)
cal=json.loads((OUT/'final-calibration-v2/result.json').read_text());assert cal['faults']==28 and cal['restoredPassed']==349
binding=json.loads((OUT/'final-calibration-v2/source.json').read_text());assert binding==v.source_identity();v.write_json(FINAL/'source.json',binding)
catalog=json.loads((OUT/'criterion15-maintenance-worker/fast/test-catalog.json').read_text())
classes=['StartupCancellationOwnershipTests','StartupDeadlineTests','FailedStartupCleanupTests','CompensatingCleanupTests','PreparedMaintenanceDrainTests','OrdinaryRecoveryTests','StaticFailedDrainTests']
methods=['EnsureCreated_cannot_publish_a_runtime_model_that_disagrees_with_its_schema_model','Constructor_failure_does_not_leave_an_undisclosed_database_lease','Schema_initialization_failure_is_reported_before_a_lease_is_published']
selectors=classes+methods
native=[r for r in catalog['slow'] if any('.'+n+'.' in r['name'] for n in classes) or any(n in r['name'] for n in methods)]
assert native and len({r['id'] for r in native})==len(native)
v.write_json(FINAL/'selected-native.json',native)
for lane,selection,expected,deadline in [('fast','Category!=PostgreSQL',catalog['fast'],180),('native','|'.join('FullyQualifiedName~'+n for n in selectors),native,600)]:
 out=FINAL/lane;out.mkdir();resources=v.docker_inventory(out,'resources-before',ENV) if lane=='native' else None
 try:v.run_phase('coverage',['dotnet','test',v.PROJECT,'--no-build','-c','Release','--filter',selection,'--collect','Code Coverage;Format=cobertura','--results-directory',str(out/'results'),'--logger','trx;LogFileName=results.trx'],out,deadline,ENV)
 finally:
  if lane=='native':assert resources==v.docker_inventory(out,'resources-after',ENV)
 rows=v.read_results(out/'results/results.trx',[r['name'] for r in expected]);assert {r['id'] for r in rows}=={r['id'] for r in expected}
 assert binding==v.source_identity();v.write_json(out/'rows.json',rows)
 coverage=next((out/'results').glob('*/*.cobertura.xml'))
 executed={Path(c.get('filename','')).name:sum(int(n.get('hits'))>0 for n in c.findall('./lines/line')) for c in E.parse(coverage).findall('.//class') if any(int(n.get('hits'))>0 for n in c.findall('./lines/line'))}
 v.write_json(out/'coverage-owners.json',executed);print(lane,'owning coverage passed',len(rows),flush=True)
v.run_phase('all',['python3','scripts/verify.py','all','--output',str(FINAL/'all')],FINAL,1200,ENV)
r=json.loads((FINAL/'all/verification.json').read_text());assert r['result']=='PASS' and r['discovered']=={'all':520,'fast':348,'slow':172}
assert json.loads((FINAL/'all/source-identity.json').read_text())==binding==v.source_identity()
v.write_json(FINAL/'result.json',{'result':'PASS','fastCoverageRows':len(catalog['fast']),'nativeCoverageRows':len(native),'canonicalAll':r,'identicalFinalSourceRuntimeDependencies':True,'wholeSessionMutation':'pending final coding-session snapshot','ProjectFields':'unverified/unmodified; no native field tools or browser available'})
print('final owning coverage and complete520gate PASS',flush=True)
