"""Apply the finite independently reviewed local publication envelope."""
from pathlib import Path
import hashlib,json,subprocess,sys,tarfile
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-023/diagnostic-closure';BASE='e18d7e1418890a0a7f39a1bb9d2116580b4cefcb'
osource=OUT/'final-verification/source.json';sys.path.insert(0,str(ROOT/'scripts'));import verify as v

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT).decode()
def index():
 result={}
 for row in git('ls-files','--stage','-z').split('\0'):
  if row:
   meta,name=row.split('\t',1);mode,oid,stage=meta.split();assert stage=='0';result[name]=(mode,oid)
 return result
p=json.loads((OUT/'packet.json').read_text());c=json.loads((OUT/'candidate.json').read_text());a=json.loads((OUT/'independent-pass.json').read_text())
assert a['verdict']=='PASS' and a['candidateSha256']==sha(OUT/'candidate.json')==p['candidateSha256']
assert a['packetSha256']==sha(OUT/'packet.json') and a['finalizerSha256']==sha(Path(__file__))==p['finalizerSha256']
assert git('rev-parse','HEAD').strip()==BASE and git('branch','--show-current').strip()=='master' and not git('remote').strip()
assert git('branch','--format=%(refname:short)').splitlines()==['master'] and len(git('worktree','list','--porcelain').split('worktree '))==2
statuses={r[3:]:r[:2] for r in git('status','--porcelain=v1','--no-renames','-z').split('\0') if r};assert set(statuses)=={r['path'] for r in c['paths']}
i=index()
for r in c['paths']:
 name=r['path'];path=ROOT/name;assert statuses[name]==r['status']
 if r['change']=='D':assert not path.exists() and name not in i
 else:assert not path.is_symlink() and sha(path)==r['sha256'] and i[name]==(r['mode'],r['stagedObject'])
retain=ROOT/p['evidence'];m=json.loads((retain/'manifest.json').read_text());assert sha(retain/'runs.tar.gz')==m['archive']['sha256']
with tarfile.open(retain/'runs.tar.gz') as t:
 assert {n.name for n in t.getmembers()}=={r['path'] for r in m['files']}
 for r in m['files']:assert hashlib.sha256(t.extractfile(r['path']).read()).hexdigest()==r['sha256']
assert json.loads((osource).read_text())==v.source_identity()==json.loads((OUT/'final-verification/all/source-identity.json').read_text())
w=p['envelope']['write'];assert sha(ROOT/w['from'])==w['sha256'];dest=ROOT/w['to'];assert not dest.exists();dest.write_bytes((ROOT/w['from']).read_bytes());subprocess.run(['git','add',w['to']],cwd=ROOT,check=True)
expected={r['path']:r['sha256'] for r in c['paths']};expected[w['to']]=w['sha256']
changed=set(git('diff','--name-only','--no-renames','-z',BASE).split('\0'))-{''};assert changed==set(expected) and not git('diff','--name-only').strip()
for name,digest in expected.items():assert not (ROOT/name).exists() if digest is None else sha(ROOT/name)==digest
subprocess.run(['git','diff','--check','--cached'],cwd=ROOT,check=True);subprocess.run(['git','commit','-m',p['envelope']['commit']],cwd=ROOT,check=True)
head=git('rev-parse','HEAD').strip();assert git('rev-parse','HEAD^').strip()==BASE and not git('status','--porcelain').strip();assert v.source_identity()==json.loads(osource.read_text())
v.write_json(OUT/'publication.json',{'head':head,'parent':BASE,'localCommitOnly':True,'candidateSha256':a['candidateSha256'],'packetSha256':a['packetSha256'],'treeClean':True,'sourceRuntimeDependenciesUnchanged':True,'noPush':True,'noCleanupDeletion':True});print(head,flush=True)
