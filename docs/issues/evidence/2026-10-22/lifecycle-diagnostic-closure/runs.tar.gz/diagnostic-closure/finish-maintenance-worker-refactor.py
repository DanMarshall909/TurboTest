from pathlib import Path
import json,sys,os
ROOT=Path.cwd();OUT=ROOT/'artifacts/tt-023/diagnostic-closure'
exec((OUT/'diagnostic-identity-cycles.py').read_text().split('# Criterion5:')[0])
out=OUT/'criterion15-maintenance-worker';fault=out/'fault-failure-release';r=json.loads((fault/'test.json').read_text());assert r['exitCode']==1 and not r['deadlineExceeded'] and r['processGroupStopped'] and not v.group_members(r['processGroupId'])
allrows=rows(fault/'results/results.trx');failed=[{'name':n.get('testName'),'message':n.findtext('.//{*}Message')} for n in allrows if n.get('outcome')=='Failed'];assert len(allrows)==3 and len(failed)==2
for n in failed:
 if 'failDrain: False' in n['name']:assert 'No exception was thrown' in n['message']
 elif 'failDrain: True' in n['name']:assert 'IOException' in n['message'] and 'Not found' in n['message']
 else:raise AssertionError(n)
assert all('TimeoutException' not in n['message'] for n in failed)
meta=json.loads((fault/'binding.json').read_text());assert meta['sourceIdentity']==v.source_identity()
v.write_json(fault/'result.json',{'originalQuestion':'maintenance-success-only','failed':failed,'passedControls':1,'primaryInputsUnchanged':True,'qualification':'Current-source compiled regression fault. First comparator required same assertion in two heterogeneous cases and failed after both intended diagnostic rejections. Exact false/noexception and true/missingIOException messages now checked independently against terminal raw TRX; no re-execution or product RED claim.'})
selection='FullyQualifiedName~FactoryMaintenanceTests|FullyQualifiedName~FactoryBackpressureTests|FullyQualifiedName~FactoryTimingTests'
restore=out/'restored';restore.mkdir();build(restore,isolated=True);run_test(restore,selection,isolated=True)
assert len(rows(restore/'results/results.trx'))==31
v.write_json(out/'cycle.json',{'owningPassed':31,'kind':'Behavior-preserving refactor after green characterization; no new product RED claim','productionRefactor':'Worker releases actual completed success; failed work remains until its reporting consumer removes it. Remove redundant observer-ledger dependency and argument. Observer and drain set Delivered and remove work without an intervening await; proof does not assume SynchronizationContext.Post is nonreentrant. Independently tracked acquisition observers remain joined before drain reads maintenance.','testRefactor':'Reuse existing held-failure, delivered-failure, repeated context lifetime and timing controls; no private-membership assertion added. Prior1925 one-off weak-node measurement remains historical.','calibration':'Two canceled-observation failure rows reject failure release; ordinary maintenance rejection remains passing control.','coverage':str(next((out/'green/results').glob('*/*.cobertura.xml'))),'historicalQuestion1924':'Original Survived status preserved; obsolete predicate simplified, not an executed1924 replay.'})
v.run_phase('canonical-fast',['python3','scripts/verify.py','fast','--output',str(out/'fast')],out,240,ENV);assert json.loads((out/'fast/verification.json').read_text())['result']=='PASS'
print('criterion15 refactor/coverage/fault calibration/fast PASS',flush=True)
