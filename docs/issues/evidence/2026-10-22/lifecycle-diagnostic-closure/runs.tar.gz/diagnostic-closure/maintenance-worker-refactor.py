from pathlib import Path
import json,sys,os
ROOT=Path.cwd();OUT=ROOT/'artifacts/tt-023/diagnostic-closure'
exec((OUT/'diagnostic-identity-cycles.py').read_text().split('# Criterion5:')[0])
out=OUT/'criterion15-maintenance-worker';out.mkdir()
selection='FullyQualifiedName~FactoryMaintenanceTests|FullyQualifiedName~FactoryBackpressureTests|FullyQualifiedName~FactoryTimingTests'
build(out);v.write_json(out/'before-source.json',v.source_identity());run_test(out,selection)
baseline=rows(out/'results/results.trx');assert all(n.get('outcome')=='Passed' for n in baseline)
p=ROOT/'src/TurboTest.EFCore/TtFactory.cs';s=p.read_text()
for old,new in [('_ = RunMaintenanceAsync(work, settled);','_ = RunMaintenanceAsync(work);'),('private async Task RunMaintenanceAsync(MaintenanceWork work, TaskCompletionSource observer)','private async Task RunMaintenanceAsync(MaintenanceWork work)'),('if (!_acquisitions.Contains(observer) && (failure is null || work.Delivered)) _maintenance.Remove(work);','if (failure is null) _maintenance.Remove(work);')]:
 assert s.count(old)==1;s=s.replace(old,new)
p.write_text(s)
green=out/'green';green.mkdir();build(green);run_test(green,selection,coverage=True)
assert len(rows(green/'results/results.trx'))==len(baseline)
v.write_json(out/'source.json',v.source_identity())
calibration(out/'fault-failure-release','maintenance-success-only','TtFactory.cs','if (failure is null) _maintenance.Remove(work);','if (failure is not null) _maintenance.Remove(work);','FullyQualifiedName~Canceled_observation_retains_an_already_completed_maintenance_failure_until_drain|FullyQualifiedName~Ordinary_factory_rejects_prepared_maintenance_without_allocation',2,3,'Assert.Throws',None)
restore=out/'restored';restore.mkdir();build(restore,isolated=True);run_test(restore,selection,isolated=True)
v.write_json(out/'cycle.json',{'owningPassed':len(baseline),'kind':'Behavior-preserving refactor after green characterization, no new product RED claim','productionRefactor':'Worker releases actual completed success; failed work remains until its reporting consumer removes it. Remove redundant observer-ledger dependency and argument. Observer and drain set Delivered and remove work without an intervening await; proof does not assume SynchronizationContext.Post is nonreentrant. Independently tracked acquisition observers remain joined before drain reads maintenance.','testRefactor':'Reuse existing held-failure, delivered-failure, repeated context lifetime and timing controls; no private-membership assertion added. Earlier1925 one-off weak-node measurement remains historical, not relabelled current.','calibration':'Two current canceled-observation failure rows reject failure release; ordinary maintenance rejection remains passing control.','coverage':str(next((green/'results').glob('*/*.cobertura.xml'))),'historicalQuestion1924':'Original Survived status preserved; current obsolete predicate simplified, not an executed1924 replay.'})
v.run_phase('canonical-fast',['python3','scripts/verify.py','fast','--output',str(out/'fast')],out,240,ENV)
assert json.loads((out/'fast/verification.json').read_text())['result']=='PASS'
print('criterion15 refactor/coverage/fault calibration/fast PASS',flush=True)
