from pathlib import Path
prefix=Path('artifacts/tt-023/diagnostic-closure/diagnostic-identity-cycles.py').read_text().split('# Criterion5:')[0]
exec(prefix)
p=ROOT/'tests/TurboTest.Tests/SlotRetentionTests.cs';s=p.read_text();old='''    [InlineData(false)]
    [InlineData(true)]
    public async Task Retirement_retry_preserves_capacity_and_replaces_only_for_renewed_demand(bool renewed)''';assert s.count(old)==1;s=s.replace(old,'''    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task Retirement_retry_preserves_capacity_and_replaces_only_for_renewed_demand(bool renewed, bool safeFailure)''');old='        var inject = true;';assert s.count(old)==1;s=s.replace(old,old+'''
        Exception deletionFailure = safeFailure
            ? new TtLifecycleException("DistinctDelete", new Npgsql.PostgresException("private-idle-drop", "ERROR", "ERROR", "53100"))
            : new IOException("private-idle-drop");''');old='if (attempt == 1) throw new IOException("The idle drop has not been confirmed.");';assert s.count(old)==1;s=s.replace(old,'if (attempt == 1) throw deletionFailure;');old='            Assert.Equal("SlotIdleRetire", failure.Stage);';assert s.count(old)==1;s=s.replace(old,'''            Assert.Equal(safeFailure ? "DistinctDelete" : "SlotIdleRetire", failure.Stage);
            Assert.Equal(safeFailure ? "53100" : null, failure.SqlState);
            Assert.DoesNotContain("private-idle-drop", failure.ToString());
            Assert.Null(failure.InnerException);''');p.write_text(s)
p=ROOT/'tests/TurboTest.Tests/SlotRewarmDrainTests.cs';s=p.read_text();old='''    [Fact]
    public async Task A_rewarm_failure_delivered_by_exhausted_cleanup_is_not_reported_again_at_drain()''';assert s.count(old)==1;s=s.replace(old,'''    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task A_rewarm_failure_delivered_by_exhausted_cleanup_is_not_reported_again_at_drain(bool safeFailure)''');old='        var allowCleanup = false;';assert s.count(old)==1;s=s.replace(old,old+'''
        Exception rewarmFailure = safeFailure
            ? new TtLifecycleException("DistinctRewarm", new Npgsql.PostgresException("private-rewarm-failure", "ERROR", "ERROR", "53200"))
            : new IOException("private-rewarm-failure");''');old='rewarm: (_, _) => Task.FromException(new IOException("private-rewarm-failure"))';assert s.count(old)==1;s=s.replace(old,'rewarm: (_, _) => Task.FromException(rewarmFailure)');start=s.index('    public async Task A_rewarm_failure_delivered');end=s.index('\n    [Fact]',start);body=s[start:end];old='            Assert.Contains("IOException", failure.Message);';assert body.count(old)==1;body=body.replace(old,'''            Assert.Equal(safeFailure ? "DistinctRewarm" : "SlotRewarm", failure.Stage);
            Assert.Equal(safeFailure ? "53200" : null, failure.SqlState);
            Assert.Contains(safeFailure ? "53200" : nameof(IOException), failure.Message);
            Assert.Null(failure.InnerException);''');p.write_text(s[:start]+body+s[end:])
select='FullyQualifiedName~Retirement_retry_preserves_capacity|FullyQualifiedName~A_rewarm_failure_delivered_by_exhausted_cleanup'
finish('criterion8-safe-idle-stages','FullyQualifiedName~SlotRetentionTests|FullyQualifiedName~SlotRewarmDrainTests',[
 ('1317','Internal/TtSlotPool.cs','error as TtLifecycleException ?? new TtLifecycleException("SlotIdleRetire", error)','new TtLifecycleException("SlotIdleRetire", error)',select,2,6,'DistinctDelete',None),
 ('1396','Internal/TtSlotPool.cs','error as TtLifecycleException ?? new TtLifecycleException("SlotRewarm", error)','new TtLifecycleException("SlotRewarm", error)',select,1,6,'DistinctRewarm',None),
 ('1397','Internal/TtSlotPool.cs','new TtLifecycleException("SlotRewarm", error)','new TtLifecycleException("", error)',select,1,6,'SlotRewarm',None)
],'Existing retirement/rewarm fixtures absorb distinct safe Stage/SQLSTATE rows while retaining raw controls and actual cleanup/no replay assertions. No additional native setup or replacement stand-in; stage identity is primary, not only a nested substring.')
