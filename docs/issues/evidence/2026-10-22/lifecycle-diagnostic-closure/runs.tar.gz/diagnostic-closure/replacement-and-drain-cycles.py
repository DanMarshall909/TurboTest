from pathlib import Path
exec(Path('artifacts/tt-023/diagnostic-closure/diagnostic-identity-cycles.py').read_text().split('# Criterion5:')[0])
p=ROOT/'tests/TurboTest.Tests/SlotRewarmDrainTests.cs';s=p.read_text();s='using System.Collections.Concurrent;\n'+s if 'using System.Collections.Concurrent;' not in s else s;marker='public class SlotRewarmDrainTests\n{';assert s.count(marker)==1;s=s.replace(marker,marker+'''
    [Fact]
    public async Task A_failed_rewarm_transfers_its_unseen_failure_to_an_admitted_replacement_until_drain()
    {
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var release = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var created = new ConcurrentQueue<object>();
        var deleted = new ConcurrentQueue<object>();
        var preparations = 0;
        var owner = new TtSlotPool<object>(1, 1, _ =>
        {
            if (created.Count >= 2) throw new InvalidOperationException("Recovery created another replacement.");
            var resource = new object();
            created.Enqueue(resource);
            return resource;
        }, async (_, token) =>
        {
            var attempt = Interlocked.Increment(ref preparations);
            if (attempt == 1) return;
            if (attempt > 2) throw new InvalidOperationException("Replacement preparation was repeated.");
            entered.TrySetResult();
            await release.Task;
            token.ThrowIfCancellationRequested();
        }, resource =>
        {
            Assert.DoesNotContain(resource, deleted);
            deleted.Enqueue(resource);
            return Task.CompletedTask;
        }, rewarm: (_, _) => Task.FromException(new TtLifecycleException("RewarmStage",
            new Npgsql.PostgresException("private-transferred-rewarm", "ERROR", "ERROR", "53100"))));
        Task<TtSlotPool<object>.Reservation>? waiting = null;
        Task? closing = null;
        try
        {
            var initial = await owner.AcquireAsync();
            await owner.ReturnAsync(initial, (_, _) => Task.CompletedTask);
            await owner.ParkIdleAsync(0, (_, _) => Task.CompletedTask);
            waiting = owner.AcquireAsync();
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(2));
            Assert.Equal((2, 1, 1, 1), (created.Count, deleted.Count, owner.Snapshot.Preparing, owner.Snapshot.Reserved));
            Assert.False(waiting.IsCompleted);
            closing = owner.DisposeAsync().AsTask();
            await Assert.ThrowsAsync<ObjectDisposedException>(() => waiting.WaitAsync(TimeSpan.FromSeconds(2)));
            Assert.False(closing.IsCompleted);
            release.TrySetResult();
            var failure = await Assert.ThrowsAsync<TtLifecycleException>(() => closing.WaitAsync(TimeSpan.FromSeconds(2)));
            Assert.Equal("SlotDispose", failure.Stage);
            Assert.Contains("RewarmStage", failure.Message);
            Assert.Contains("53100", failure.Message);
            Assert.DoesNotContain(nameof(OperationCanceledException), failure.Message);
            Assert.DoesNotContain("private-", failure.ToString());
            Assert.Null(failure.InnerException);
            await owner.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2));
            await owner.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2));
            Assert.Equal(created.ToArray(), deleted.ToArray());
            Assert.Equal((2, 2, 0), (created.Count, preparations, owner.Snapshot.Reserved));
        }
        finally
        {
            release.TrySetResult();
            if (waiting is not null) await Record.ExceptionAsync(() => waiting.WaitAsync(TimeSpan.FromSeconds(2)));
            closing ??= owner.DisposeAsync().AsTask();
            await Record.ExceptionAsync(() => closing.WaitAsync(TimeSpan.FromSeconds(2)));
            await owner.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2));
        }
    }
''',1);p.write_text(s)
finish('criterion11-rewarm-marker-transfer','FullyQualifiedName~SlotRewarmDrainTests',[
 ('1604','Internal/TtSlotPool.cs','replacement.UnseenPreparationFailure = reservation.UnseenPreparationFailure;',';','FullyQualifiedName~A_failed_rewarm_transfers_its_unseen_failure|FullyQualifiedName~Closure_joins_rewarm_and_reports_material_late_failure_once_without_replacement',1,4,'No exception was thrown',None)
],'Admit and hold actual replacement before closure so the transferred marker is uniquely exercised. Existing no-replacement closure rows are controls. Safe rewarm stage/state survives owned cancellation; actual created/deleted identities, finite attempts and two clean retries establish settlement.')
# Criterion12: all independent material errors from physical slot drain remain observable.
p=ROOT/'tests/TurboTest.Tests/SlotPoolTests.cs';s=p.read_text();marker='public class SlotPoolTests\n{';assert s.count(marker)==1;s=s.replace(marker,marker+'''
    [Fact]
    public async Task Two_failed_drain_deletions_retain_both_safe_errors_until_successful_physical_retry()
    {
        var allowDeletion = false;
        var attempts = 0;
        var confirmed = new HashSet<Guid>();
        var errors = new Dictionary<Guid, TtLifecycleException>();
        var owner = new TtSlotPool<Resource>(2, 1, id => new Resource(id), (_, _) => Task.CompletedTask, resource =>
        {
            if (++attempts > 4) throw new InvalidOperationException("Drain exceeded its finite deletion oracle.");
            if (!allowDeletion) throw errors[resource.Id];
            Assert.True(confirmed.Add(resource.Id), "Confirmed drain deletion was repeated.");
            return Task.CompletedTask;
        });
        try
        {
            var first = await owner.AcquireAsync();
            var second = await owner.AcquireAsync();
            errors[first.Value.Id] = new TtLifecycleException("FirstDrop",
                new Npgsql.PostgresException("private-first-drop", "ERROR", "ERROR", "53100"));
            errors[second.Value.Id] = new TtLifecycleException("SecondDrop",
                new Npgsql.PostgresException("private-second-drop", "ERROR", "ERROR", "53200"));
            await owner.ReturnAsync(first, (_, _) => Task.CompletedTask);
            await owner.ReturnAsync(second, (_, _) => Task.CompletedTask);
            var failure = await Assert.ThrowsAsync<TtLifecycleException>(() => owner.DisposeAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(2)));
            Assert.Equal("SlotDispose", failure.Stage);
            Assert.Contains("FirstDrop", failure.Message);
            Assert.Contains("53100", failure.Message);
            Assert.Contains("SecondDrop", failure.Message);
            Assert.Contains("53200", failure.Message);
            Assert.DoesNotContain("private-", failure.ToString());
            Assert.Null(failure.InnerException);
            Assert.Equal((2, 2, 2, 0), (attempts, owner.Snapshot.Reserved, owner.Snapshot.Quarantined, confirmed.Count));
            allowDeletion = true;
            await owner.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2));
            await owner.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2));
            Assert.Equal(errors.Keys.Order().ToArray(), confirmed.Order().ToArray());
            Assert.Equal((4, 0), (attempts, owner.Snapshot.Reserved));
        }
        finally
        {
            allowDeletion = true;
            await Record.ExceptionAsync(() => owner.DisposeAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(2)));
            await owner.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2));
        }
    }
''',1);p.write_text(s)
finish('criterion12-slot-drain-errors','FullyQualifiedName~SlotPoolTests',[
 ('1703','Internal/TtSlotPool.cs','first = first is null ? error : new AggregateException(first, error);','first = error;','FullyQualifiedName~Two_failed_drain_deletions_retain_both_safe_errors|FullyQualifiedName~A_second_quarantine_cannot_replace|FullyQualifiedName~Failed_preparations_share_the_cleanup_limit',1,3,'FirstDrop',None)
],'Two actual reservations fail physical drain with distinct safe stages/states; assert both identities and retained capacity, then enable deletion and confirm each identity once. This distinguishes errors within one owner, supplementing prior multi-owner static evidence; existing preparation/quarantine cases remain controls.')
