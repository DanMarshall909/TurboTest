from pathlib import Path
exec(Path('artifacts/tt-023/diagnostic-closure/diagnostic-identity-cycles.py').read_text().split('# Criterion5:')[0])
p=ROOT/'tests/TurboTest.Tests/SlotPreparationDrainTests.cs';s=p.read_text();marker='public class SlotPreparationDrainTests\n{';assert s.count(marker)==1;s=s.replace(marker,marker+'''
    [Fact]
    public async Task A_terminal_failure_observed_after_abandoned_preparation_is_not_replayed_at_drain()
    {
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var release = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var expected = new TtLifecycleException("AbandonedSeed",
            new Npgsql.PostgresException("private-abandoned-seed", "ERROR", "ERROR", "53100"));
        var creates = 0;
        var deletes = 0;
        var owner = new TtSlotPool<Resource>(1, 1, id =>
        {
            if (++creates > 1) throw new InvalidOperationException("Terminal preparation created another resource.");
            return new Resource(id);
        }, async (_, _) =>
        {
            entered.TrySetResult();
            await release.Task;
            throw expected;
        }, _ =>
        {
            if (++deletes > 1) throw new InvalidOperationException("Confirmed preparation deletion was repeated.");
            return Task.CompletedTask;
        });
        using var caller = new CancellationTokenSource();
        var abandoned = owner.AcquireAsync(caller.Token);
        try
        {
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(2));
            caller.Cancel();
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => abandoned.WaitAsync(TimeSpan.FromSeconds(2)));
            release.TrySetResult();
            using var settled = new CancellationTokenSource(TimeSpan.FromSeconds(2));
            while (owner.Snapshot.Reserved != 0) await Task.Delay(1, settled.Token);
            Assert.Equal((1, 1, 0), (creates, deletes, owner.Snapshot.QueuedAcquisitions));
            var delivered = await Assert.ThrowsAsync<TtLifecycleException>(() => owner.AcquireAsync());
            Assert.Same(expected, delivered);
            Assert.Equal(("AbandonedSeed", "53100"), (delivered.Stage, delivered.SqlState));
            Assert.DoesNotContain("private-", delivered.ToString());
            Assert.Null(delivered.InnerException);
            var drain = await Record.ExceptionAsync(() => owner.DisposeAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(2)));
            Assert.Null(drain);
            await owner.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2));
            Assert.Equal((1, 1, 0), (creates, deletes, owner.Snapshot.Reserved));
        }
        finally
        {
            release.TrySetResult();
            caller.Cancel();
            await Record.ExceptionAsync(() => abandoned.WaitAsync(TimeSpan.FromSeconds(2)));
            await Record.ExceptionAsync(() => owner.DisposeAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(2)));
            await owner.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2));
        }
    }
''',1);p.write_text(s)
finish('criterion9-terminal-delivery','FullyQualifiedName~SlotPreparationDrainTests',[
 ('1354','Internal/TtSlotPool.cs','                MarkFailureDelivered(_failure);','                // Fault: do not record actual terminal delivery.','FullyQualifiedName~A_terminal_failure_observed_after_abandoned_preparation|FullyQualifiedName~An_abandoned_initial_preparation_retains_material_and_cleanup_failures_through_shutdown',1,5,'AbandonedSeed',None)
],'Actual initial work fails only after its original observer cancels; zero-reservation snapshot establishes settled terminal state without private access. A fresh immediate acquisition consumes that exact failure, then drain is clean. Existing canceled-before-drain cases are distinct controls. Finite factory/deletion counters and bounded cleanup remain.')
# Criterion10: first terminal identity survives a second independent error in both producer paths.
p=ROOT/'tests/TurboTest.Tests/SlotPoolTests.cs';s=p.read_text();start=s.index('    public async Task Failed_preparations_share_the_cleanup_limit');end=s.index('\n    [Fact]',start);body=s[start:end];old='            Assert.Same(delivered, await Assert.ThrowsAsync<TtLifecycleException>(() => second));';assert body.count(old)==1;body=body.replace(old,old+'''
            using var settled = new CancellationTokenSource(TimeSpan.FromSeconds(2));
            while (owner.Snapshot.Reserved != 0) await Task.Delay(1, settled.Token);
            var later = await Assert.ThrowsAsync<TtLifecycleException>(() => owner.AcquireAsync());
            Assert.Equal("FirstCandidate", later.Stage);
            Assert.Same(delivered, later);''');s=s[:start]+body+s[end:]
marker='public class SlotPoolTests\n{';assert s.count(marker)==1;s=s.replace(marker,marker+'''
    [Fact]
    public async Task A_second_quarantine_cannot_replace_the_first_terminal_error_seen_by_later_acquisition()
    {
        var allowDeletion = false;
        var confirmed = new HashSet<Guid>();
        var errors = new Dictionary<Guid, TtLifecycleException>();
        var creates = 0;
        var owner = new TtSlotPool<Resource>(2, 1, id =>
        {
            if (++creates > 2) throw new InvalidOperationException("Quarantine created another resource.");
            return new Resource(id);
        }, (_, _) => Task.CompletedTask, resource =>
        {
            if (!allowDeletion) throw errors[resource.Id];
            Assert.True(confirmed.Add(resource.Id), "Confirmed quarantine deletion was repeated.");
            return Task.CompletedTask;
        });
        try
        {
            var first = await owner.AcquireAsync();
            var second = await owner.AcquireAsync();
            var firstError = errors[first.Value.Id] = new TtLifecycleException("FirstQuarantine",
                new Npgsql.PostgresException("private-first-quarantine", "ERROR", "ERROR", "53100"));
            var secondError = errors[second.Value.Id] = new TtLifecycleException("SecondQuarantine",
                new Npgsql.PostgresException("private-second-quarantine", "ERROR", "ERROR", "53200"));
            Assert.Same(firstError, await Assert.ThrowsAsync<TtLifecycleException>(() => owner.DiscardAsync(first)));
            Assert.Same(secondError, await Assert.ThrowsAsync<TtLifecycleException>(() => owner.DiscardAsync(second)));
            Assert.Equal((2, 2, 0), (owner.Snapshot.Reserved, owner.Snapshot.Quarantined, owner.Snapshot.QueuedAcquisitions));
            var later = await Assert.ThrowsAsync<TtLifecycleException>(() => owner.AcquireAsync());
            Assert.Equal("FirstQuarantine", later.Stage);
            Assert.Same(firstError, later);
            Assert.Equal("53100", later.SqlState);
            Assert.DoesNotContain("private-", later.ToString());
            allowDeletion = true;
            await owner.DisposeAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(2));
            await owner.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2));
            Assert.Equal(errors.Keys.Order().ToArray(), confirmed.Order().ToArray());
            Assert.Equal((2, 0), (creates, owner.Snapshot.Reserved));
        }
        finally
        {
            allowDeletion = true;
            await Record.ExceptionAsync(() => owner.DisposeAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(2)));
            await owner.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2));
        }
    }
''',1);p.write_text(s)
select='FullyQualifiedName~Failed_preparations_share_the_cleanup_limit|FullyQualifiedName~A_second_quarantine_cannot_replace|FullyQualifiedName~A_terminal_failure_observed_after_abandoned_preparation'
old='''        _owned.Remove(reservation);
        RetainUnseenFailure(reservation);
        _failure ??= failure;'''
oldq='''            _owned[reservation] = State.Quarantined;
            _failure ??= failure;
            FailWaiters(_failure);'''
finish('criterion10-first-terminal-identity','FullyQualifiedName~SlotPoolTests|FullyQualifiedName~SlotPreparationDrainTests',[
 ('1598','Internal/TtSlotPool.cs',old,old.replace('_failure ??= failure;','_failure = failure;'),select,1,3,'FirstCandidate',None),
 ('1645','Internal/TtSlotPool.cs',oldq,oldq.replace('_failure ??= failure;','_failure = failure;'),select,1,3,'FirstQuarantine',None)
],'Extend the existing two-preparation case only after both reservations settle; fresh acquisition must still receive exact first instance. Add two independently quarantined leased resources for the other terminal producer, with fresh acquisition after second failure and complete physical deletion. Existing queued-caller assertions remain distinct, no timing oracle.')
