"""Bounded copied-source calibration of original1485/1609; no Stryker replay."""
from pathlib import Path
import hashlib, importlib.util, json, os, xml.etree.ElementTree as ET
ROOT = Path('/home/dan/code/TurboTest'); OUT = ROOT / 'artifacts/tt-024/preparation-drain/guard-calibration'
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('verify', ROOT / 'scripts/verify.py')
v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
before = v.source_identity(); build = ROOT / 'artifacts/tt-024/lifetimes/calibration-build'
source = ROOT / 'src/TurboTest.EFCore/Internal/TtSlotPool.cs'; original = source.read_text()
delay = '                    await Task.Delay(RecoveryDelay, _clock, _closing.Token);'
stop = '            if (_closed || _stopping) return;'
assert original.count(delay) == original.count(stop) == 1
variants = {'1485': original.replace(delay, '                    ;'),
            '1609': original.replace(stop, '            if (_closed && _stopping) return;')}
env = dict(os.environ, DOTNET_CLI_USE_MSBUILD_SERVER='0', MSBUILDDISABLENODEREUSE='1')
fault = OUT / 'fault.cs'; targets = OUT / 'Fault.targets'; results = []
selection = 'FullyQualifiedName~Stopping_admission_leaves_failed_idle_cleanup|FullyQualifiedName~Shutdown_during_replacement_retry|FullyQualifiedName~An_abandoned_initial_preparation'
try:
    for name, text in variants.items():
        fault.write_text(text); (OUT / (name + '-source.cs')).write_text(text)
        targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="Internal/TtSlotPool.cs" /><Compile Include="{fault}" /></ItemGroup><Target Name="RecordGuardCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore' Or '$(MSBuildProjectName)' == 'TurboTest.Tests'"><WriteLinesToFile File="{OUT}/$(MSBuildProjectName)-compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true" /></Target></Project>''')
        v.run_phase(name + '-build', ['dotnet','build','tests/TurboTest.Tests/TurboTest.Tests.csproj','--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false','--verbosity','minimal'], OUT, 120, env)
        inputs = (OUT / 'TurboTest.EFCore-compile.txt').read_text().splitlines()
        tests = (OUT / 'TurboTest.Tests-compile.txt').read_text().splitlines()
        assert str(fault) in inputs and str(source) not in inputs
        assert not any('PrivateNodeProbe.cs' in s for s in tests)
        dll = build / 'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
        v.write_json(OUT / (name + '-binding.json'), {'originalSha256':hashlib.sha256(original.encode()).hexdigest(),
            'variantSha256':hashlib.sha256(text.encode()).hexdigest(),'productCompile':inputs,'testCompile':tests,
            'compiledInputs':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*'))
                if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
        try:v.run_phase(name+'-test',['dotnet','test',str(dll),'--filter',selection,'--results-directory',str(OUT/(name+'-results')),'--logger','trx;LogFileName=results.trx'],OUT,30,env)
        except v.VerificationError:pass
        receipt = json.loads((OUT/(name+'-test.json')).read_text())
        assert receipt['exitCode']==1 and not receipt['deadlineExceeded'] and receipt['processGroupStopped']
        rows = ET.parse(OUT/(name+'-results/results.trx')).findall('.//{*}UnitTestResult'); assert len(rows)==7
        failures = [{'name':r.get('testName'),'message':r.findtext('.//{*}Message')} for r in rows if r.get('outcome')=='Failed']
        expected = 'Shutdown_during_replacement_retry' if name=='1485' else 'Stopping_admission_leaves_failed_idle_cleanup'
        assert len(failures)==(2 if name=='1485' else 1)
        assert all(expected in r['name'] and 'Assert.False() Failure' in r['message'] and 'TimeoutException' not in r['message'] for r in failures)
        results.append({'variant':name,'namedFailures':failures,'controlsPassed':sum(r.get('outcome')=='Passed' for r in rows)})
        v.write_json(OUT/'progress.json',results); print(name,'intended assertion failed,controls passed',flush=True)
finally:assert before==v.source_identity()
v.write_json(OUT/'result.json',{'primaryInputsUnchanged':True,'results':results,
    'qualification':'Exact original1485/1609faults in copied source; lifetime/cadence assertions reject faults promptly. Historical mutation statuses unchanged; no whole-session adequacy or mutation replay claim.'})
