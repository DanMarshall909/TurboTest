"""One-off preparation-ownership evidence packet; run after final ordinary gate."""
from pathlib import Path
import hashlib, json, subprocess, sys, tarfile, xml.etree.ElementTree as ET
ROOT = Path('/home/dan/code/TurboTest')
OUT = ROOT / 'artifacts/tt-024/preparation-final'
BASE = '5f2247fad3c7b6ec111a64df1c5f0beb1177211b'
SOURCE = ['src/TurboTest.EFCore/Internal/TtPool.cs', 'src/TurboTest.EFCore/Internal/TtSlotPool.cs',
          'tests/TurboTest.Tests/OrdinaryRecoveryTests.cs', 'tests/TurboTest.Tests/SlotPoolTests.cs',
          'tests/TurboTest.Tests/SlotPreparationDrainTests.cs']
sys.path.insert(0, str(ROOT / 'scripts'))
import verify
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, obj): path.write_text(json.dumps(obj, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT).decode()
assert git('rev-parse', 'HEAD').strip() == BASE
assert git('branch', '--show-current').strip() == 'master' and not git('remote').strip()
assert len(git('worktree', 'list', '--porcelain').split('worktree ')) == 2
run = OUT / 'all'; result = json.loads((run / 'verification.json').read_text())
assert result['result'] == 'PASS'
assert result['tests']['fast']['passed'] == 306 and result['tests']['slow']['passed'] == 170
assert result['resourceSettlement']['before'] == result['resourceSettlement']['after']
assert not result['resourceSettlement']['added'] and not result['resourceSettlement']['removed']
binding = json.loads((run / 'source-identity.json').read_text())
assert binding == verify.source_identity()
probe = ROOT / 'artifacts/tt-024/preparation-drain'
assert json.loads((OUT / 'owning-source.json').read_text()) == binding
coverage = json.loads((OUT / 'owning-coverage.json').read_text())
assert coverage['exitCode'] == 0 and not coverage['deadlineExceeded'] and coverage['processGroupStopped']
catalog = json.loads((run / 'test-catalog.json').read_text())
owners = ('TurboTest.Tests.SlotPreparationDrainTests.', 'TurboTest.Tests.OrdinaryRecoveryTests.')
expected_rows = {row['id'] for row in catalog['all'] if row['name'].startswith(owners) or any(n in row['name'] for n in ('Failed_preparations_share_the_cleanup_limit', 'Cleanup_retries_do_not_restart_the_three_candidate_recovery_budget'))}
rows = ET.parse(OUT / 'owning-coverage/results.trx').findall('.//{*}UnitTestResult')
assert len(expected_rows) == len(rows) == 16
assert {row.get('testId') for row in rows} == expected_rows and all(row.get('outcome') == 'Passed' for row in rows)
assert json.loads((probe / 'guard-calibration/result.json').read_text())['primaryInputsUnchanged']
for name in SOURCE:
    target = OUT / 'candidate-source' / name; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
for name, sha in binding['resolvedDependencies'].items():
    assert digest(ROOT / name) == sha
    target = OUT / 'resolved-dependencies' / name; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
retain = ROOT / 'docs/issues/evidence/2026-10-22/preparation-failure-ownership'
retain.mkdir(parents=True, exist_ok=False)
excluded = {'candidate.json', 'candidate.sha256', 'packet.json', 'envelope-completion.json', 'independent-pass.json', 'handoff-live.json'}
items = sorted((p for folder in (probe, OUT) for p in folder.rglob('*')
                if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts),
               key=lambda p: str(p.relative_to(ROOT / 'artifacts/tt-024')).encode())
entries = []; archive = retain / 'runs.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for p in items:
        assert not p.is_symlink() and p.resolve().is_relative_to((ROOT / 'artifacts/tt-024').resolve())
        name = str(p.relative_to(ROOT / 'artifacts/tt-024')); tar.add(p, arcname=name, recursive=False)
        entries.append({'path': name, 'sha256': digest(p), 'bytes': p.stat().st_size})
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(entries)
    for row in entries: assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest() == row['sha256']
limits = [
    "Bounded TT023/TT024 preparation ownership slice. Both issues remain open; 18 of the original 48 TT024 questions remain unresolved.",
    "Genuine product REDs establish loss of unseen initial, replacement, secondary and successive failures, and false reporting of owned cancellation. Final 16-row owning coverage binds identical source and runtime inputs.",
    "The independent-candidate oracle now distinguishes both errors. The original failed canonical cut and the resource-identity fixture correction are retained; the fixture failure is not a product RED.",
    "Exact original 1485/1609 copied-source faults are rejected by named assertions with controls. Useful delay and stop predicates remain; historical mutation statuses are unchanged.",
    "No resource state, resource budget, retry count, test deadline, concurrency, lane or PostgreSQL setting was changed.",
    "Native evidence covers reset SQLSTATE P0001, ownership of a created unstarted replacement, cancellation versus material failure and physical container removal. Fast ledger tests and native contracts retain distinct roles.",
    "Whole-session mutation remains pending on the final coding-session snapshot. No fresh adequacy score or Stryker replay is claimed.",
    "Broader unchecked lifecycle, initializer timeout, optional callback and remaining ledger questions are not declared complete.",
    "Local source commits only; no code remote or hosted CI result. Reusable caches and the unknown stopped baseline are retained.",
    "Tracker drafts add evidence only and require fresh comparison, body-only update and readback after review. No additional acceptance checkbox or issue closure is claimed."
]
save(retain / 'manifest.json', {'schemaVersion': 1, 'slice': 'TT023/TT024 preparation failure ownership',
    'baseCommit': BASE, 'candidateSource': {name: binding['files'][name] for name in SOURCE},
    'archive': {'path': 'runs.tar.gz', 'sha256': digest(archive), 'bytes': archive.stat().st_size},
    'files': entries, 'verification': result, 'limits': limits})
text = (OUT / 'results-draft.md').read_text()
text += f'\n## Final ordinary gate\n\n**306 fast + 170 PostgreSQL = 476 passed**, no failures/skips. Total {result["elapsedSeconds"]:.3f}s. Solution and separate example builds pass. Exact discovered/executed IDs, source/binary/dependency identity, stopped owned process groups and matching before/after labelled Docker inventories are retained. The final 16-row owning coverage binds identical inputs. Independent final verdict is recorded separately in `completion.json`.\n'
(retain / 'results.md').write_text(text)
investigations = ['docs/issues/open/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md',
                  'docs/issues/open/api/TT-023-assert-late-failure-ordering-and-safe-diagnostic-identity.md']
for name in investigations:
    path = ROOT / name
    path.write_text(path.read_text() + '\n- **2026-10-22 — Preparation failure ownership slice:** [Source-bound evidence](../../evidence/2026-10-22/preparation-failure-ownership/manifest.json) records unseen initial/replacement failures, retained prior and compensation errors, distinct successive errors, verified publication clearing, actual delivery deduplication and native ordinary cancellation classification. Useful retry-delay and stop predicates are retained with exact fault calibration, resolving two additional bounded original questions and leaving 18 of 48 unresolved. Final ordinary verification is 476 passes with 16 owning coverage rows; independent verdict is in `completion.json`. Both investigations stay open; original mutation statuses are unchanged and GitHub owns the partial acceptance checklist.\n')
readme = ROOT / 'docs/issues/README.md'
old = readme.read_text(); new = old.replace('**463 tests**', '**476 tests**', 1).replace('**295 fast checks**', '**306 fast checks**', 1)
assert new != old; readme.write_text(new)
subprocess.run(['git', 'add', *SOURCE, *investigations, 'docs/issues/README.md', str(retain.relative_to(ROOT))], cwd=ROOT, check=True)
index = {}
for row in git('ls-files', '--stage', '-z').split('\0'):
    if not row: continue
    meta, name = row.split('\t', 1); mode, oid, stage = meta.split(); assert stage == '0'; index[name] = (mode, oid)
statuses = {r[3:]: r[:2] for r in git('status', '--porcelain=v1', '-z').split('\0') if r}
paths = [p for p in git('diff', '--name-only', '-z', BASE).split('\0') if p]
expected = set(SOURCE + investigations + ['docs/issues/README.md'] + [str((retain/n).relative_to(ROOT)) for n in ('runs.tar.gz','manifest.json','results.md')])
assert set(paths) == set(statuses) == expected
records = []
for name in sorted(paths, key=lambda s: s.encode()):
    mode, oid = index[name]; assert mode == '100644' and not (ROOT / name).is_symlink()
    change = 'M' if subprocess.run(['git','cat-file','-e',BASE+':'+name],cwd=ROOT,capture_output=True).returncode == 0 else 'A'
    records.append({'path':name,'change':change,'status':statuses[name],'mode':mode,'sha256':digest(ROOT/name),'stagedObject':oid})
candidate = {'schemaVersion':1,'base':BASE,'current':BASE,'branch':'master','upstream':None,'integrationBase':BASE,'paths':records,'excludedUnrelated':[]}
raw = (json.dumps(candidate,sort_keys=True,indent=2)+'\n').encode(); (OUT/'candidate.json').write_bytes(raw)
fingerprint = hashlib.sha256(raw).hexdigest(); (OUT/'candidate.sha256').write_text(fingerprint+'\n')
save(OUT/'envelope-completion.json', {'slice':'TT023/TT024 preparation failure ownership','independentVerdict':'PASS','reviewer':'/root/tt023_preparation_review',
    'reviewedCandidateSha256':fingerprint,'baseCommit':BASE,'ordinaryTests':476,'issuesRemainOpen':[13,14],
    'wholeSessionMutation':'pending after final coding-session snapshot','publication':'local source commit only'})
packet = {'slice':'TT023/TT024 preparation failure ownership','acceptedScopeAndCriteria':str((retain/'results.md').relative_to(ROOT)),
    'candidate':'artifacts/tt-024/preparation-final/candidate.json','candidateSha256':fingerprint,'base':BASE,'upstream':None,
    'integrationPolicy':'Local source commits only, docs/issues/README.md','evidence':str(retain.relative_to(ROOT)),'limits':limits,
    'envelope': {'write':[{'from':'artifacts/tt-024/preparation-final/envelope-completion.json','to':str((retain/'completion.json').relative_to(ROOT)),
                           'sha256':digest(OUT/'envelope-completion.json'),'mode':'100644'}],
        'validation':['reconstruct candidate manifest and archive hashes','git diff --check','match final tree to candidate plus exact completion write','match full source/binary/dependency identity and exact packet hash'],
        'commit':'Retain unseen preparation failures through shutdown','push':'none: local source policy',
        'trackerUpdate':[{'issue':n,'draft':f'artifacts/tt-024/preparation-final/tracker-{n}-draft.json','sha256':digest(OUT/f'tracker-{n}-draft.json'),
            'expectedBodySha256':hashlib.sha256(json.loads((OUT/f'tracker-{n}-draft.json').read_text())['expectedBody'].encode()).hexdigest(),
            'resultingBodySha256':hashlib.sha256(json.loads((OUT/f'tracker-{n}-draft.json').read_text())['resultingBody'].encode()).hexdigest(),
            'condition':'Immediately reread open issue, require exact expected body, apply only resulting body preserving other fields, read back. If already result verify idempotently. Conflicting edits require reconciliation/review.'} for n in (13,14)],
        'cleanup':'Inspect only; preserve unknown stopped container, reusable caches and evidence. No further deletions.'}}
save(OUT/'packet.json',packet)
print(json.dumps({'candidateSha256':fingerprint,'paths':len(records),'archiveMembers':len(entries),'archiveBytes':archive.stat().st_size,'packetSha256':digest(OUT/'packet.json')}))
