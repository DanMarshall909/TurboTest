"""Freeze only the demonstrated late-initializer ownership repair, not all TT023."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-023/startup-failure';BASE='63737df38997d21eb2854d260bb0324147b8f23c'
SOURCE=['src/TurboTest.EFCore/Tt.cs','tests/TurboTest.Tests/StartupLateDrainTests.cs','tests/TurboTest.Tests/StartupCancellationOwnershipTests.cs']
os.chdir(ROOT);sys.path.insert(0,str(ROOT/'scripts'));import verify

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def git(*args):return subprocess.check_output(['git',*args]).decode()
assert git('rev-parse','HEAD').strip()==BASE and git('branch','--show-current').strip()=='master'
assert not git('remote').strip() and git('branch','--format=%(refname:short)').splitlines()==['master']
assert len(git('worktree','list','--porcelain').split('worktree '))==2
run=OUT/'final-all';result=json.loads((run/'verification.json').read_text());assert result['result']=='PASS'
assert result['tests']['fast']['passed']==327 and result['tests']['slow']['passed']==171
assert result['resourceSettlement']['before']==result['resourceSettlement']['after'] and not result['resourceSettlement']['added'] and not result['resourceSettlement']['removed']
binding=json.loads((run/'source-identity.json').read_text());assert binding==verify.source_identity()==json.loads((OUT/'final-owning-source.json').read_text())
assert binding==json.loads((OUT/'final-calibration/binding.json').read_text())['primarySource']
assert json.loads((OUT/'final-owning.json').read_text())['exitCode']==0 and json.loads((OUT/'final-owning-resources.json').read_text())['equal']
catalog=json.loads((run/'test-catalog.json').read_text());fast={r['id'] for r in catalog['fast']}
owners=('TurboTest.Tests.StartupCancellationOwnershipTests.','TurboTest.Tests.StartupDeadlineTests.');method='Failed_startup_retains_exact_cleanup_ownership_and_supports_explicit_or_global_retry'
expected=fast|{r['id'] for r in catalog['all'] if r['name'].startswith(owners) or method in r['name']}
rows=E.parse(OUT/'final-owning-results/results.trx').findall('.//{*}UnitTestResult')
assert len(rows)==len(expected)==339 and {r.get('testId') for r in rows}==expected and all(r.get('outcome')=='Passed' for r in rows)
red=E.parse(OUT/'red-results/results.trx').findall('.//{*}UnitTestResult');assert len(red)==10 and sum(r.get('outcome')=='Failed' for r in red)==6
assert all('No exception was thrown' in r.findtext('.//{*}Message','') for r in red if r.get('outcome')=='Failed')
redBinding=json.loads((OUT/'red-source.json').read_text());baseSource=subprocess.check_output(['git','show',BASE+':'+SOURCE[0]])
assert hashlib.sha256(baseSource).hexdigest()==redBinding['files'][SOURCE[0]]
assert redBinding['files'][SOURCE[1]]==binding['files'][SOURCE[1]]
cal=json.loads((OUT/'final-calibration/result.json').read_text());assert len(cal['failed'])==7 and cal['passedControls']==13 and cal['resourcesEqual'] and cal['primaryInputsUnchanged']
for name in SOURCE:
 assert sha(ROOT/name)==binding['files'][name]
 p=OUT/'candidate-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
p=OUT/'base-source/Tt.cs';p.parent.mkdir(exist_ok=True);p.write_bytes(baseSource)
for name,digest in binding['resolvedDependencies'].items():
 assert sha(ROOT/name)==digest
 p=OUT/'resolved-dependencies'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
limits=[
 'Bounded TT023 repair only: interrupted observer returns before held actual initializer fails materially; retained cleanup reports that previously unobserved safe error once after cancellation and physical drain. No whole-ticket closure or original54-question resolution claim.',
 'Six genuine RED rows and four success/owned-cancellation controls precede production change. Raw IOException, already-safe LateSeedWrite/53100, and late actual TimeoutException inputs cross caller cancellation and observation deadline.',
 'Native held seed executes an actual missing-relation query after caller cancellation. Independent Docker identity, gated callback and physical deletion prove BaselineInitialize/42P01, safe diagnostics and exact-once cleanup. Native case was added as boundary calibration after component GREEN, then independently rejects the compiled fault.',
 'Final exact compiled discard fault rejects six fast cases plus native seed;13controls pass, source/binary/dependency identity unchanged, owned command groups stopped, resources equal. First calibration build failed only for unused-variable warning and is retained as harness failure, not product RED.',
 'Raw OperationCanceledException suppression and observed-error reference comparison retain existing behavior. This slice does not settle foreign-token cancellation, all AggregateException inner failures, immediate initializer-owned timeout taxonomy, caller/simultaneous shutdown precedence or every secondary failure/capability path.',
 'Final ordinary498=327fast+171native and owning339=327fast+12native share identical source/runtime/dependency inputs. Local gate is not hostedCI. Whole-session mutation remains pending final coding-session snapshot; original mutation statuses unchanged.',
 'No lane change from one timing observation. New fast deadline cases add approximately250ms of intentional observation waits, while the new native case stays in the PostgreSQL lane; retained ordinary timings support further review.',
 'PostPASS envelope: exact completion write, local source commit and conditional issue13body-only append/readback. Issue remains open; all existing checkboxes unchanged. No source remote, push, Project field claim or cleanup deletion. Preserve stopped unknown baseline and reusable caches/evidence.'
]
retain=ROOT/'docs/issues/evidence/2026-10-22/startup-late-initializer';retain.mkdir(parents=True,exist_ok=False)
excluded={'candidate.json','candidate.sha256','packet.json','envelope-completion.json','independent-pass.json','publication.json','tracker-receipt.json','final-inspection.json'}
items=sorted((p for p in OUT.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts),key=lambda p:str(p.relative_to(ROOT/'artifacts/tt-023')).encode());entries=[];archive=retain/'runs.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in items:
  assert not p.is_symlink() and p.resolve().is_relative_to(OUT.resolve())
  n=str(p.relative_to(ROOT/'artifacts/tt-023'));t.add(p,arcname=n,recursive=False);entries.append({'path':n,'bytes':p.stat().st_size,'sha256':sha(p)})
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(entries)
 for r in entries:assert hashlib.sha256(t.extractfile(r['path']).read()).hexdigest()==r['sha256']
save(retain/'manifest.json',{'schemaVersion':1,'slice':'TT023 late initializer failure ownership','baseCommit':BASE,'candidateSource':{n:binding['files'][n] for n in SOURCE},'archive':{'path':'runs.tar.gz','sha256':sha(archive),'bytes':archive.stat().st_size},'files':entries,'verification':result,'owningCoverageRows':339,'limits':limits})
(retain/'results.md').write_text('''# Interrupted startup retains actual initializer failure

Owning issue: [TT-023](https://github.com/DanMarshall909/TurboTest/issues/13). This is a bounded repair; the issue remains open.

## Behavior and evidence

Startup previously returned `StartupCanceled` or `StartupTimeout`, then unconditionally swallowed a later initializer failure under the assumption it had already been reported. Cleanup could succeed physically without exposing that material error.

The repair captures a distinct late material initializer error, preserves its existing safe stage/SQLSTATE, waits for actual initializer/cancellation/disposal completion, and delivers it once through retained cleanup. It neither replays the already-observed initializer error nor converts successful/owned-cancellation completion into a new material error.

The ten-row fast theory reuses the actual generic slot ledger. Six material rows genuinely fail before the product change; four controls pass. The assertions independently specify raw type/safe stage/SQLSTATE, cleanup identity, actual deletion, empty reservations and repeat recovery without duplicate errors/deletions.

The native seed case issues a real PostgreSQL query only after startup cancellation and while cancellation callback completion is independently held. It receives `BaselineInitialize`/`42P01`, exposes no query text, retains the original container until work and callback completion, deletes it once, and retries cleanly. Existing native success and callback-failure rows remain distinct controls.

The final isolated compile fault consumes the actual initializer error. Seven intended assertions fail, including the native seed case;13 controls pass. The primary compiler/runtime/dependency inputs remain unchanged; the warm isolated build is restored to original sources and passes. The initial unused-variable calibration compile failure is explicitly retained as setup failure.

## Coverage and refactoring

Final owning coverage contains339 rows (327fast,12native) with exact IDs matching final discovery. New capture/report lines execute; diagnostic and physical-resource assertions, rather than coverage alone, establish behavior. Production retains one owner/delegate and neighboring once-delivery flags; no extraction earns its cost. Tests reuse one bounded actual slot fixture and the existing native held-work/callback helper, without another fake or private seam.

Final ordinary verification: **327fast+171PostgreSQL=498passed**, no failures/skips. Solution and separate DynamicScalingExample builds pass. Source, runtime and dependency identities match owning coverage and final calibration. Native resource inventories preserve the unrelated stopped baseline; owned command groups stop. `completion.json` retains the independent bounded-slice verdict.

## Limits and remaining work

This does not complete TT023 or reclassify any of its54original generated faults. Immediate initializer-owned timeout classification, caller/simultaneous shutdown precedence, integrated secondary safe failures/capabilities and remaining original question decisions retain their scope. Raw OperationCanceledException handling is unchanged; foreign-token and all AggregateException-inner taxonomies are not claimed.

The new fast deadline rows add roughly250ms of intentional waits; the native seed case uniquely calibrates real user seed, provider errors and Docker deletion. No lane changes are inferred from a single timing variation. Whole-session mutation remains pending after the final coding snapshot. Native Project fields are unverified/unmodified. Source and evidence remain local under the declared repository policy; no source push or resource/cache deletion.
''')
p=ROOT/'docs/issues/open/api/TT-023-assert-late-failure-ordering-and-safe-diagnostic-identity.md';p.write_text(p.read_text()+'\n- **2026-10-22 — Late initializer failure ownership:** [Source-bound repair evidence](../../evidence/2026-10-22/startup-late-initializer/manifest.json) demonstrates a material initializer failure lost after startup observation was interrupted, then retains that safe error once through actual cancellation and physical cleanup. Six genuine fast RED cases and a separately fault-calibrated real PostgreSQL seed failure distinguish safe identity and confirmed one-time deletion from successful/owned-cancellation controls. Final ordinary verification is498passes and339owning coverage rows on identical source/runtime/dependencies; the independent bounded verdict is recorded in `completion.json`. This investigation and its remaining criteria stay open; no original mutation status or whole-ticket completion claim changes. Whole-session mutation remains pending; GitHub owns live status.\n')
p=ROOT/'docs/issues/README.md';s=p.read_text();assert '**487 tests**' in s and '**317 fast checks**' in s;p.write_text(s.replace('**487 tests**','**498 tests**',1).replace('**317 fast checks**','**327 fast checks**',1))
paths=SOURCE+['docs/issues/README.md','docs/issues/open/api/TT-023-assert-late-failure-ordering-and-safe-diagnostic-identity.md']+[str((retain/n).relative_to(ROOT)) for n in ('manifest.json','results.md','runs.tar.gz')]
subprocess.run(['git','add',*paths],check=True)
index={}
for r in git('ls-files','--stage','-z').split('\0'):
 if r:
  meta,n=r.split('\t',1);mode,oid,stage=meta.split();assert stage=='0';index[n]=(mode,oid)
statuses={r[3:]:r[:2] for r in git('status','--porcelain=v1','--no-renames','-z').split('\0') if r};assert set(statuses)==set(paths)
records=[]
for n in sorted(paths,key=lambda n:n.encode()):
 mode,oid=index[n];assert mode=='100644' and not (ROOT/n).is_symlink()
 change='M' if subprocess.run(['git','cat-file','-e',BASE+':'+n],capture_output=True).returncode==0 else 'A'
 records.append({'path':n,'change':change,'status':statuses[n],'mode':mode,'sha256':sha(ROOT/n),'stagedObject':oid})
c={'schemaVersion':1,'base':BASE,'current':BASE,'branch':'master','upstream':None,'integrationBase':BASE,'paths':records,'excludedUnrelated':[]}
save(OUT/'candidate.json',c);fingerprint=sha(OUT/'candidate.json');(OUT/'candidate.sha256').write_text(fingerprint+'\n')
save(OUT/'envelope-completion.json',{'slice':'TT023 late initializer failure ownership','independentVerdict':'PASS','reviewer':'/root/tt023_initializer_review','reviewedCandidateSha256':fingerprint,'baseCommit':BASE,'ordinaryTests':498,'owningCoverageRows':339,'wholeIssueClosure':False,'wholeSessionMutation':'pending final coding-session snapshot','publication':'local commit; issue13body evidence append only; native Project fields unverified/unmodified'})
save(OUT/'packet.json',{'slice':'TT023 late initializer failure ownership','wholeTicketClosure':False,'acceptedScopeAndCriteria':str((retain/'results.md').relative_to(ROOT)),'candidate':str((OUT/'candidate.json').relative_to(ROOT)),'candidateSha256':fingerprint,'base':BASE,'current':BASE,'upstream':None,'integrationBase':BASE,'integrationPolicy':'Local source commits only, docs/issues/README.md','evidence':str(retain.relative_to(ROOT)),'limits':limits,'finalizerSha256':sha(OUT/'finalize.py'),'envelope':{'write':{'from':str((OUT/'envelope-completion.json').relative_to(ROOT)),'to':str((retain/'completion.json').relative_to(ROOT)),'sha256':sha(OUT/'envelope-completion.json'),'mode':'100644'},'validation':['exact candidate statuses/modes/hashes/staged objects','all archive member hashes','unchanged final source/runtime/dependency identities','git diff --cached --check','complete final changed tree equals candidate plus exact completion write'],'commit':'Retain late initializer failures through startup cleanup','push':'none: local source policy','tracker':{'issue':13,'draft':'artifacts/tt-023/startup-failure/tracker-draft.json','sha256':sha(OUT/'tracker-draft.json'),'operation':'Fresh compare of expectedBody/open; body-only resultingBody patch and exact readback; leave issue open and all checkboxes/other fields unchanged; concurrent conflict requires reconciliation/review'},'project':'Unavailable/unverified/unmodified','cleanup':'Inspect only: retain unrelated stopped Docker baseline, reusable caches/evidence; no deletion'}})
print(json.dumps({'candidateSha256':fingerprint,'packetSha256':sha(OUT/'packet.json'),'finalizerSha256':sha(OUT/'finalize.py'),'paths':len(records),'archiveMembers':len(entries),'archiveBytes':archive.stat().st_size}),flush=True)
