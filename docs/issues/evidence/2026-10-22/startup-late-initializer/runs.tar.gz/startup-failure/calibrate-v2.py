from pathlib import Path
import importlib.util,os,json,hashlib,xml.etree.ElementTree as E
ROOT=Path.cwd();OUT=ROOT/'artifacts/tt-023/startup-failure/calibration-v2';OUT.mkdir()
s=importlib.util.spec_from_file_location('v',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
before=v.source_identity();source=ROOT/'src/TurboTest.EFCore/Tt.cs';original=source.read_text()
old='''                    if (!ReferenceEquals(initializationError, error) && initializationError is not OperationCanceledException)
                        initializationFailure = initializationError as TtLifecycleException ??
                            new TtLifecycleException(stage, initializationError);'''
assert original.count(old)==1
fault=OUT/'Tt.cs';fault.write_text(original.replace(old,'                    _ = initializationError; // Fault: consume the actual late initializer failure.'))
targets=OUT/'Fault.targets';targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="Tt.cs"/><Compile Include="{fault}"/></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{OUT}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
build=ROOT/'artifacts/tt-024/lifetimes/calibration-build';env=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1')
v.run_phase('restore',['dotnet','restore',v.PROJECT,'--artifacts-path',str(build)],OUT,180,env)
v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],OUT,180,env)
inputs=(OUT/'compile.txt').read_text().splitlines();assert str(fault) in inputs and str(source) not in inputs
dll=build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
v.write_json(OUT/'binding.json',{'primarySource':before,'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'faultSha256':hashlib.sha256(fault.read_bytes()).hexdigest(),'compile':inputs,'binaries':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dll.parent.rglob('*') if p.is_file() and p.suffix=='.dll'}})
try:v.run_phase('test',['dotnet','test',str(dll),'--filter','FullyQualifiedName~StartupLateDrainTests','--results-directory',str(OUT/'results'),'--logger','trx;LogFileName=results.trx'],OUT,60,env)
except v.VerificationError:pass
r=json.loads((OUT/'test.json').read_text());assert r['exitCode']==1 and not r['deadlineExceeded'] and r['processGroupStopped']
rows=E.parse(OUT/'results/results.trx').findall('.//{*}UnitTestResult');failed=[{'name':r.get('testName'),'message':r.findtext('.//{*}Message')} for r in rows if r.get('outcome')!='Passed']
assert len(failed)==6 and all('Interrupted_startup_reports_the_actual_late_initializer_failure_once' in r['name'] and 'No exception was thrown' in r['message'] for r in failed)
assert before==v.source_identity() and source.read_text()==original
v.write_json(OUT/'result.json',{'failed':failed,'passedControls':len(rows)-6,'primaryInputsUnchanged':True,'qualification':'Exact compiled fault; no historical mutant replay claim'})
restore=OUT/'restored';restore.mkdir();targets=restore/'Original.targets'
targets.write_text(f'''<Project><Target Name="RecordOriginalCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><WriteLinesToFile File="{restore}/compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],restore,180,env)
inputs=(restore/'compile.txt').read_text().splitlines();assert str(source) in inputs and str(fault) not in inputs
v.run_phase('test',['dotnet','test',str(dll),'--filter','FullyQualifiedName~StartupLateDrainTests','--results-directory',str(restore/'results'),'--logger','trx;LogFileName=results.trx'],restore,60,env)
assert before==v.source_identity()
print('6 intended rejections; remaining controls passed; warm isolated build restored',flush=True)
