"""Finite reviewed local publication; no source edits, remote push or resource deletion."""
from pathlib import Path
import hashlib,json,subprocess,sys,tarfile
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-023/startup-failure'
sys.path.insert(0,str(ROOT/'scripts'));import verify
BASE='63737df38997d21eb2854d260bb0324147b8f23c'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).decode()
p=json.loads((OUT/'packet.json').read_text());c=json.loads((OUT/'candidate.json').read_text());a=json.loads((OUT/'independent-pass.json').read_text())
assert a['verdict']=='PASS' and a['candidateSha256']==sha(OUT/'candidate.json')==p['candidateSha256']
assert a['packetSha256']==sha(OUT/'packet.json') and a['finalizerSha256']==sha(Path(__file__))==p['finalizerSha256']
assert git('rev-parse','HEAD').strip()==BASE and git('branch','--show-current').strip()=='master' and not git('remote').strip()
assert git('branch','--format=%(refname:short)').splitlines()==['master']
assert len(git('worktree','list','--porcelain').split('worktree '))==2
statuses={r[3:]:r[:2] for r in git('status','--porcelain=v1','--no-renames','-z').split('\0') if r}
assert set(statuses)=={r['path'] for r in c['paths']}
index={}
for r in git('ls-files','--stage','-z').split('\0'):
 if r:
  meta,n=r.split('\t',1);mode,oid,stage=meta.split();assert stage=='0';index[n]=(mode,oid)
for r in c['paths']:
 path=ROOT/r['path'];assert not path.is_symlink() and sha(path)==r['sha256'] and statuses[r['path']]==r['status'] and index[r['path']]==(r['mode'],r['stagedObject'])
retain=ROOT/p['evidence'];m=json.loads((retain/'manifest.json').read_text())
assert sha(retain/'runs.tar.gz')==m['archive']['sha256']
with tarfile.open(retain/'runs.tar.gz') as t:
 assert {n.name for n in t.getmembers()}=={r['path'] for r in m['files']}
 for r in m['files']:assert hashlib.sha256(t.extractfile(r['path']).read()).hexdigest()==r['sha256']
assert verify.source_identity()==json.loads((OUT/'final-all/source-identity.json').read_text())==json.loads((OUT/'final-owning-source.json').read_text())
envelope=p['envelope'];w=envelope['write'];assert sha(ROOT/w['from'])==w['sha256'];dest=ROOT/w['to'];assert not dest.exists();dest.write_bytes((ROOT/w['from']).read_bytes())
subprocess.run(['git','add',str(dest.relative_to(ROOT))],cwd=ROOT,check=True)
expected={r['path']:r['sha256'] for r in c['paths']};expected[w['to']]=w['sha256']
changed=set(git('diff','--name-only','--no-renames','-z',BASE).split('\0'))-{''};assert changed==set(expected)
assert not git('diff','--name-only').strip()
for name,digest in expected.items():assert sha(ROOT/name)==digest
subprocess.run(['git','diff','--check','--cached'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m',envelope['commit']],cwd=ROOT,check=True)
head=git('rev-parse','HEAD').strip();assert git('rev-parse','HEAD^').strip()==BASE and not git('status','--porcelain').strip()
assert verify.source_identity()==json.loads((OUT/'final-all/source-identity.json').read_text())
verify.write_json(OUT/'publication.json',{'head':head,'parent':BASE,'localCommitOnly':True,'candidateSha256':a['candidateSha256'],'packetSha256':a['packetSha256'],'treeClean':True,'sourceRuntimeDependenciesUnchanged':True,'noPush':True,'noCleanupDeletion':True})
print(head,flush=True)
