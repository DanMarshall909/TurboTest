from pathlib import Path
import importlib.util,os,json,xml.etree.ElementTree as E
ROOT=Path.cwd();OUT=ROOT/'artifacts/tt-023/startup-failure'
s=importlib.util.spec_from_file_location('v',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
env=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1',DOCKER_HOST=v.DOCKER_HOST)
binding=v.source_identity();assert binding==json.loads((OUT/'native-source.json').read_text())==json.loads((OUT/'final-calibration/binding.json').read_text())['primarySource']
v.write_json(OUT/'final-owning-source.json',binding)
selection='Category!=PostgreSQL|FullyQualifiedName~StartupCancellationOwnershipTests|FullyQualifiedName~StartupDeadlineTests|FullyQualifiedName~Failed_startup_retains_exact_cleanup_ownership_and_supports_explicit_or_global_retry'
before=v.docker_inventory(OUT,'final-owning-resources-before',env)
try:v.run_phase('final-owning',['dotnet','test',v.PROJECT,'--no-build','-c','Release','--filter',selection,'--collect','Code Coverage;Format=cobertura','--results-directory',str(OUT/'final-owning-results'),'--logger','trx;LogFileName=results.trx'],OUT,240,env)
finally:
 after=v.docker_inventory(OUT,'final-owning-resources-after',env);v.write_json(OUT/'final-owning-resources.json',{'before':sorted(before),'after':sorted(after),'equal':before==after});assert before==after
assert binding==v.source_identity()
rows=E.parse(OUT/'final-owning-results/results.trx').findall('.//{*}UnitTestResult');assert all(r.get('outcome')=='Passed' for r in rows)
v.write_json(OUT/'final-owning-result.json',{'passed':len(rows),'selection':selection,'sourceUnchanged':True,'resourceSettlement':True})
print('final owning coverage PASS',len(rows),flush=True)
v.run_phase('canonical-all',['python3','scripts/verify.py','all','--output',str(OUT/'final-all')],OUT,1100,env)
assert binding==v.source_identity()==json.loads((OUT/'final-all/source-identity.json').read_text())
print('final canonical ordinary gate PASS, same source/runtime/dependencies',flush=True)
