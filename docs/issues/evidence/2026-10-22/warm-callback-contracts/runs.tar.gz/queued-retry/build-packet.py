"""Freeze the verified bounded TT024 warm-callback candidate, without publication."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/queued-retry'
BASE='2f313f8cfa6e02e7ffb29da8b8263bb47145276b'
SOURCE=['src/TurboTest.EFCore/Internal/TtSlotPool.cs','tests/TurboTest.Tests/AdaptiveSlotTests.cs','tests/TurboTest.Tests/CapacityPolicyTests.cs','tests/TurboTest.Tests/SlotParkingTests.cs','tests/TurboTest.Tests/SlotPreparationDrainTests.cs']
MEASURED=SOURCE+['src/TurboTest.EFCore/Internal/TtCapacityPolicy.cs']
os.chdir(ROOT);sys.path.insert(0,str(ROOT/'scripts'));import verify
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args]).decode()
assert git('rev-parse','HEAD').strip()==BASE and git('branch','--show-current').strip()=='master'
assert not git('remote').strip() and len(git('worktree','list','--porcelain').split('worktree '))==2
run=OUT/'final-all';result=json.loads((run/'verification.json').read_text());assert result['result']=='PASS'
assert result['tests']['fast']['passed']==314 and result['tests']['slow']['passed']==170
assert result['resourceSettlement']['before']==result['resourceSettlement']['after']
binding=json.loads((run/'source-identity.json').read_text());assert binding==verify.source_identity()==json.loads((OUT/'owning-source.json').read_text())
owning=json.loads((OUT/'owning-coverage.json').read_text());assert owning['exitCode']==0 and not owning['deadlineExceeded'] and owning['processGroupStopped']
assert json.loads((OUT/'owning-resource-settlement.json').read_text())['equal']
catalog=json.loads((run/'test-catalog.json').read_text())
owners=tuple('TurboTest.Tests.'+name+'.' for name in ['SlotPreparationDrainTests','SlotParkingTests','SlotIdleRecoveryTests','AdaptiveSlotTests','CapacityPolicyTests','PreparedRewarmRecoveryTests','PreparedMaintenanceDrainTests','PreparedDrainRetryTests'])
expected={r['id'] for r in catalog['all'] if r['name'].startswith(owners)}
rows=E.parse(OUT/'owning-coverage/results.trx').findall('.//{*}UnitTestResult');assert len(expected)==len(rows)==65
assert {r.get('testId') for r in rows}==expected and all(r.get('outcome')=='Passed' for r in rows)
for name,controls in [('cancellation',11),('capability',8),('policy',19),('floor',8)]:
    c=OUT/('final-'+name+'-calibration');r=json.loads((c/'result.json').read_text())
    assert len(r['failed'])==1 and r['controlsPassed']==controls and r['primaryInputsUnchanged']
    assert json.loads((c/'binding.json').read_text())['sourceIdentity']==binding
assert json.loads((OUT/'restored-calibration-build/result.json').read_text())['restoredFinalOriginalProductInputs']
for name in MEASURED:
    p=OUT/'candidate-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
for name,digest in binding['resolvedDependencies'].items():
    assert sha(ROOT/name)==digest
    p=OUT/'resolved-dependencies'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
retain=ROOT/'docs/issues/evidence/2026-10-22/warm-callback-contracts';retain.mkdir(parents=True,exist_ok=False)
excluded={'candidate.json','candidate.sha256','packet.json','envelope-completion.json','independent-pass.json','publication.json','tracker-receipt.json','final-inspection.json'}
items=sorted((p for p in OUT.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts),key=lambda p:str(p.relative_to(ROOT/'artifacts/tt-024')).encode())
entries=[];archive=retain/'runs.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in items:
        assert not p.is_symlink() and p.resolve().is_relative_to(OUT.resolve())
        name=str(p.relative_to(ROOT/'artifacts/tt-024'));tar.add(p,arcname=name,recursive=False);entries.append({'path':name,'sha256':sha(p),'bytes':p.stat().st_size})
with tarfile.open(archive) as tar:
    assert len(tar.getmembers())==len(entries)
    for r in entries:assert hashlib.sha256(tar.extractfile(r['path']).read()).hexdigest()==r['sha256']
limits=[
    'TT024 bounded slice: original1448,1372,1373,1374,263,1265;38prior+6candidate decisions leave4unresolved. Issue14/checklists remain open.',
    'Four characterization tests protect existing contracts; no new product-defect RED. Initial FIFO/collector setup and stale reader count corrections retained separately.',
    '1372/1373 terminal checks removed under current three-caller/atomic flag-and-empty-waiter proof. Default/nonreentrant clocks; arbitrary internal reentry excluded. Capability/demand/warm guards retained.',
    '1374,263,1265 distinguish coherent actual internal optional capabilities. Public prepared producers always supply park/rewarm; no public reachability or broad internal-equivalence claim.',
    '1448 prevents resource-factory invocation after ledger closure; separate public stop also blocks reserve and later canceled permit blocks backend preparation. No post-close Docker CREATE claim.',
    'Final exact1448/263/1265faults and corresponding1374null-capability fault each reject owning assertion;11/19/8/8 controls pass. No historical replay/status changes or whole-session mutation score.',
    'Final owning65passes=53fast+12native andcomplete484=314fast+170native bind identical source/runtime/dependency inputs. Actual native resource inventories match retained unknown stopped baseline.',
    'No public API/package/lane/concurrency/budget/existing deadline change. Warm isolated calibration build restored to final original inputs.',
    'Whole-session mutation pending after final coding-session snapshot. Ordinary local runs do not claim hosted CI execution.',
    'Local source commits only; no code remote. Tracker append after exact independent PASS/commit/fresh comparison/readback, no checkbox/state changes; inspect-only cleanup retains unknown baseline/caches/evidence.'
]
save(retain/'manifest.json',{'schemaVersion':1,'slice':'TT024 queued retry and optional callback contracts','baseCommit':BASE,'candidateSource':{n:binding['files'][n] for n in MEASURED},'archive':{'path':'runs.tar.gz','sha256':sha(archive),'bytes':archive.stat().st_size},'files':entries,'verification':result,'limits':limits})
text=(OUT/'results-draft.md').read_text()+f'\n## Final ordinary gate\n\n**314 fast + 170 PostgreSQL = 484 passed**, no failures/skips. Total {result["elapsedSeconds"]:.3f}s. Solution and separate example builds pass without warnings/errors. Exact discovery/execution IDs, source/runtime/dependency inputs, stopped owned command groups and matching labelled Docker inventories are retained. Final owning coverage has 65 passing rows (53 fast, 12 native) on identical inputs. Independent verdict is recorded separately in `completion.json`.\n'
(retain/'results.md').write_text(text)
investigation='docs/issues/open/api/TT-024-resolve-retained-state-cleanup-and-reentrancy-invariants.md';p=ROOT/investigation
p.write_text(p.read_text()+'\n- **2026-10-22 — Queued retry and optional callback contracts:** [Source-bound evidence](../../evidence/2026-10-22/warm-callback-contracts/manifest.json) protects completed-timer retry cancellation and useful internal absent-rewarm, direct-evaluation and deferred-maintenance contracts. Repeated ClaimParked terminal checks are removed under actual caller/atomic queue-transition proof; capability/demand/admission checks remain. Six more bounded decisions leave4 of48 unresolved (466,1202,1208,1211). Initial FIFO/collector and reader-count corrections are retained separately. Final verification is484 ordinary passes and65 owning coverage rows; independent verdict is in `completion.json`. The investigation stays open, historical mutation statuses are unchanged and GitHub owns the partial checklist.\n')
p=ROOT/'docs/issues/README.md';old=p.read_text();new=old.replace('**480 tests**','**484 tests**',1).replace('**310 fast checks**','**314 fast checks**',1);assert new!=old;p.write_text(new)
subprocess.run(['git','add',*SOURCE,investigation,'docs/issues/README.md',str(retain.relative_to(ROOT))],check=True)
index={}
for r in git('ls-files','--stage','-z').split('\0'):
    if not r:continue
    meta,n=r.split('\t',1);mode,oid,stage=meta.split();assert stage=='0';index[n]=(mode,oid)
statuses={r[3:]:r[:2] for r in git('status','--porcelain=v1','-z').split('\0') if r}
paths=[p for p in git('diff','--name-only','-z',BASE).split('\0') if p]
expected=set(SOURCE+[investigation,'docs/issues/README.md']+[str((retain/n).relative_to(ROOT)) for n in ['runs.tar.gz','manifest.json','results.md']]);assert set(paths)==set(statuses)==expected
records=[]
for n in sorted(paths,key=lambda s:s.encode()):
    mode,oid=index[n];assert mode=='100644' and not (ROOT/n).is_symlink()
    change='M' if subprocess.run(['git','cat-file','-e',BASE+':'+n],capture_output=True).returncode==0 else 'A'
    records.append({'path':n,'change':change,'status':statuses[n],'mode':mode,'sha256':sha(ROOT/n),'stagedObject':oid})
candidate={'schemaVersion':1,'base':BASE,'current':BASE,'branch':'master','upstream':None,'integrationBase':BASE,'paths':records,'excludedUnrelated':[]}
raw=(json.dumps(candidate,sort_keys=True,indent=2)+'\n').encode();(OUT/'candidate.json').write_bytes(raw);fingerprint=hashlib.sha256(raw).hexdigest();(OUT/'candidate.sha256').write_text(fingerprint+'\n')
save(OUT/'envelope-completion.json',{'slice':'TT024 queued retry and optional callback contracts','independentVerdict':'PASS','reviewer':'/root/tt024_warm_callback_review','reviewedCandidateSha256':fingerprint,'baseCommit':BASE,'ordinaryTests':484,'issuesRemainOpen':[14],'wholeSessionMutation':'pending after final coding-session snapshot','publication':'local source commit only'})
d=json.loads((OUT/'tracker-14-draft.json').read_text())
packet={'slice':'TT024 queued retry and optional callback contracts','acceptedScopeAndCriteria':str((retain/'results.md').relative_to(ROOT)),'candidate':str((OUT/'candidate.json').relative_to(ROOT)),'candidateSha256':fingerprint,'base':BASE,'upstream':None,'integrationPolicy':'Local source commits only, docs/issues/README.md','evidence':str(retain.relative_to(ROOT)),'limits':limits,'envelope':{'write':[{'from':str((OUT/'envelope-completion.json').relative_to(ROOT)),'to':str((retain/'completion.json').relative_to(ROOT)),'sha256':sha(OUT/'envelope-completion.json'),'mode':'100644'}],'validation':['reconstruct candidate manifest and archive hashes','git diff --check','match final tree to candidate plus exact completion write','match full source/runtime/dependency identity and exact packet hash'],'commit':'Protect queued retry cancellation and optional pool capabilities','push':'none: local source policy','trackerUpdate':[{'issue':14,'draft':str((OUT/'tracker-14-draft.json').relative_to(ROOT)),'sha256':sha(OUT/'tracker-14-draft.json'),'expectedBodySha256':hashlib.sha256(d['expectedBody'].encode()).hexdigest(),'resultingBodySha256':hashlib.sha256(d['resultingBody'].encode()).hexdigest(),'condition':'Fresh open issue must equal expectedBody, body-only resultingBody update preserves other fields, independent exact readback. Already-result is idempotent; conflicting edits require reconciliation/review.'}],'cleanup':'Inspect only; preserve unknown stopped baseline, reusable caches and evidence. No deletions.'},'finalizer':{'path':str((OUT/'finalize.py').relative_to(ROOT)),'sha256':sha(OUT/'finalize.py')}}
save(OUT/'packet.json',packet)
print(json.dumps({'candidateSha256':fingerprint,'paths':len(records),'archiveMembers':len(entries),'archiveBytes':archive.stat().st_size,'packetSha256':sha(OUT/'packet.json')}))
