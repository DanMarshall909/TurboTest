"""Bounded original263 omission; isolated compiled outputs, no historical replay."""
from pathlib import Path
import hashlib,importlib.util,json,os,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest'); OUT=ROOT/'artifacts/tt-024/queued-retry/policy-calibration'
OUT.mkdir()
s=importlib.util.spec_from_file_location('v',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
before=v.source_identity();source=ROOT/'src/TurboTest.EFCore/Internal/TtCapacityPolicy.cs';original=source.read_text()
old='        ObserveDemand(state);'
assert original.count(old)==1
fault=OUT/source.name;fault.write_text(original.replace(old,'                    // Exact early cancellation omission.'))
targets=OUT/'Fault.targets'
targets.write_text(f'''<Project><ItemGroup Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore'"><Compile Remove="Internal/TtCapacityPolicy.cs"/><Compile Include="{fault}"/></ItemGroup><Target Name="RecordFaultCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore' Or '$(MSBuildProjectName)' == 'TurboTest.Tests'"><WriteLinesToFile File="{OUT}/$(MSBuildProjectName)-compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
build=ROOT/'artifacts/tt-024/lifetimes/calibration-build';env=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1')
v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],OUT,180,env)
product=(OUT/'TurboTest.EFCore-compile.txt').read_text().splitlines();tests=(OUT/'TurboTest.Tests-compile.txt').read_text().splitlines()
assert str(fault) in product and str(source) not in product
assert not any('PrivateNodeProbe.cs' in p for p in tests)
dll=build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'
v.write_json(OUT/'binding.json',{'sourceIdentity':before,'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'faultSha256':hashlib.sha256(fault.read_bytes()).hexdigest(),'productCompile':product,'testCompile':tests,'compiledInputs':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dll.parent.rglob('*')) if p.is_file() and (p.suffix=='.dll' or p.name.endswith(('.deps.json','.runtimeconfig.json')))}})
try:v.run_phase('test',['dotnet','test',str(dll),'--filter','FullyQualifiedName~CapacityPolicyTests','--results-directory',str(OUT/'results'),'--logger','trx;LogFileName=results.trx'],OUT,30,env)
except v.VerificationError:pass
r=json.loads((OUT/'test.json').read_text());assert r['exitCode']==1 and not r['deadlineExceeded'] and r['processGroupStopped']
rows=E.parse(OUT/'results/results.trx').findall('.//{*}UnitTestResult');assert len(rows)==20
failed=[{'name':r.get('testName'),'message':r.findtext('.//{*}Message')} for r in rows if r.get('outcome')=='Failed']
assert len(failed)==1 and 'Evaluation_starts_the_pressure_window' in failed[0]['name']
assert 'GrowthStabilizing' in failed[0]['message'] and 'NoDemand' in failed[0]['message'] and 'TimeoutException' not in failed[0]['message']
assert before==v.source_identity() and source.read_text()==original
v.write_json(OUT/'result.json',{'question':263,'failed':failed,'controlsPassed':19,'primaryInputsUnchanged':True,'qualification':'Exact current Evaluate observation omission; meaningful internal direct-evaluation input contract, not a claim every public caller distinguishes or historical mutation replay'})
print('263 intended policy reason assertion rejected omission; 19controls passed',flush=True)
