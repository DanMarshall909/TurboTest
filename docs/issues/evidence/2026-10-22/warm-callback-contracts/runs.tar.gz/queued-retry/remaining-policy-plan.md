# Remaining policy questions — source investigation only

Original questions 1202 and 1211 have meaningful publicly reachable differences, but accepted TT008/009 evidence does not promise either every-tick expiry or demand-free restoration after configuration discard. Do not infer intended behavior solely from a current test or mutation.

- 1202: target/minimum one; context rejection discards its slot without queued demand. A Held tick currently leaves capacity absent; `>=` refills it. Decide whether warm target is an always-realized desired count or an admission limit after such discard, then characterize the chosen cadence and later demand.
- 1208/1211: legitimate shrink from three to minimum two leaves a parked resource. After expiry, a Held tick currently retains it; OR/less-or-equal faults retire it. `IdleDatabaseLifetime` and TT008 specify idle maintenance; TT009 adds monitoring/shrink without an explicit every-tick expiry promise. Choose the monitoring cadence explicitly before asserting a policy.
- 1208 additionally violates the retained nullable-park contract: an OR gate claims shrink work while park is null, then never executes/settles that claim. A future bounded calibration must account for orphaned settlement during failing-test cleanup, preserving the named state assertion and confirming owned-worker termination. No execution/resolution claimed here.
- 466: use a genuine alternate EF provider to distinguish safe ContextConfiguration ownership rejection from raw ContextInitialize. No new provider dependency has been added in this slice.

Read-only independent investigation: `/root/tt024_pg_drop_trace`; actual source TT008 lines39–44/116–123, TT00959–79, TtOptions IdleDatabaseLifetime, README maintenance/adaptive sections. This capsule is not an accepted change to those policy contracts.
