"""Final-source fault calibration, restore warm isolated build, ordinary owning coverage."""
from pathlib import Path
import importlib.util,os,json,subprocess,xml.etree.ElementTree as E
ROOT=Path('/home/dan/code/TurboTest');OUT=ROOT/'artifacts/tt-024/queued-retry'
s=importlib.util.spec_from_file_location('v',ROOT/'scripts/verify.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
before=v.source_identity()
for script,old,new in [('calibrate.py','/calibration\'','/final-cancellation-calibration\''),('calibrate-capability.py','/capability-calibration\'','/final-capability-calibration\''),('calibrate-policy.py','/policy-calibration\'','/final-policy-calibration\''),('calibrate-floor.py','/floor-calibration\'','/final-floor-calibration\'')]:
    source=(OUT/script).read_text();assert source.count(old)==1
    path=OUT/('final-'+script);path.write_text(source.replace(old,new));subprocess.run(['python3',str(path)],cwd=ROOT,check=True)
assert before==v.source_identity()
build=ROOT/'artifacts/tt-024/lifetimes/calibration-build';restore=OUT/'restored-calibration-build';restore.mkdir()
targets=restore/'Original.targets'
targets.write_text(f'''<Project><Target Name="RecordOriginalCompile" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'TurboTest.EFCore' Or '$(MSBuildProjectName)' == 'TurboTest.Tests'"><WriteLinesToFile File="{restore}/$(MSBuildProjectName)-compile.txt" Lines="@(Compile->'%(FullPath)')" Overwrite="true"/></Target></Project>''')
env=dict(os.environ,DOTNET_CLI_USE_MSBUILD_SERVER='0',MSBUILDDISABLENODEREUSE='1')
v.run_phase('build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','--artifacts-path',str(build),'-p:CustomBeforeMicrosoftCommonTargets='+str(targets),'-nr:false','-p:UseSharedCompilation=false'],restore,180,env)
inputs=(restore/'TurboTest.EFCore-compile.txt').read_text().splitlines();tests=(restore/'TurboTest.Tests-compile.txt').read_text().splitlines()
assert str(ROOT/'src/TurboTest.EFCore/Internal/TtSlotPool.cs') in inputs and str(ROOT/'src/TurboTest.EFCore/Internal/TtCapacityPolicy.cs') in inputs
assert not any('/artifacts/' in p for p in inputs if not '/obj/' in p)
assert not any('PrivateNodeProbe' in p for p in tests)
selection='FullyQualifiedName~A_retry_queued_before_shutdown|FullyQualifiedName~Parking_without_a_rewarm_capability|FullyQualifiedName~Evaluation_starts_the_pressure_window|FullyQualifiedName~Deferred_shrink_maintenance_counts_leased_commitments'
v.run_phase('test',['dotnet','test',str(build/'bin/TurboTest.Tests/release/TurboTest.Tests.dll'),'--filter',selection,'--results-directory',str(restore/'results'),'--logger','trx;LogFileName=results.trx'],restore,30,env)
rows=E.parse(restore/'results/results.trx').findall('.//{*}UnitTestResult');assert len(rows)==4 and all(r.get('outcome')=='Passed' for r in rows)
v.write_json(restore/'result.json',{'restoredFinalOriginalProductInputs':True,'passed':4,'productCompile':inputs,'testCompile':tests})
v.run_phase('owning-build',['dotnet','build',v.PROJECT,'--no-restore','-c','Release','-nr:false','-p:UseSharedCompilation=false'],OUT,180,env)
binding=v.source_identity();assert binding==before;v.write_json(OUT/'owning-source.json',binding)
env['DOCKER_HOST']=v.DOCKER_HOST
resources=v.docker_inventory(OUT,'owning-resources-before',env)
selection='FullyQualifiedName~SlotPreparationDrainTests|FullyQualifiedName~SlotParkingTests|FullyQualifiedName~SlotIdleRecoveryTests|FullyQualifiedName~AdaptiveSlotTests|FullyQualifiedName~CapacityPolicyTests|FullyQualifiedName~PreparedRewarmRecoveryTests|FullyQualifiedName~PreparedMaintenanceDrainTests|FullyQualifiedName~PreparedDrainRetryTests'
try:v.run_phase('owning-coverage',['dotnet','test',v.PROJECT,'--no-build','--no-restore','-c','Release','--filter',selection,'--collect','Code Coverage;Format=cobertura','--results-directory',str(OUT/'owning-coverage'),'--logger','trx;LogFileName=results.trx'],OUT,300,env)
finally:
    after=v.docker_inventory(OUT,'owning-resources-after',env)
    v.write_json(OUT/'owning-resource-settlement.json',{'before':sorted(resources),'after':sorted(after),'equal':resources==after,'automaticDeletion':False})
assert resources==after and binding==v.source_identity()
print('Final-source calibration and restored owning coverage terminal PASS',flush=True)
