"""Audit and summarize the separate paired sensitivity phase."""
import collections,hashlib,itertools,json,pathlib,runpy,statistics
base=pathlib.Path('artifacts/tt032');root=base/'lifetime250';stats=runpy.run_path(str(base/'analyze-final-draft.py'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((root/'plan.json').read_text());receipts=json.loads((root/'receipts.json').read_text());manifest=json.loads((root/'manifest.json').read_text());completion=json.loads((root/'completion.json').read_text())
assert len(receipts)==len(plan)==completion['completed']==completion['planned']
assert [r['case'] for r in receipts]==plan and digest(root/'plan.json')==manifest['plan_sha256']
assert digest(base/'run_lifetime250.py')==manifest['driver_sha256']
assert all(digest(pathlib.Path(p))==h for p,h in manifest['extra_inputs'].items())
inventory=json.loads((root/'initial-containers.json').read_text());groups=collections.defaultdict(lambda:collections.defaultdict(list));common=None;failures=[];samples=0
for index,r in enumerate(receipts):
    paths=list(root.glob(f'{index:03d}-*/report.json'));assert len(paths)==1
    path=paths[0];p=json.loads(path.read_text());c=r['case']
    assert digest(path)==r['report_sha256'] and r['inputs_unchanged'] and r['binding_matches_experiment'] and r['image_binding_matches']
    assert p['CleanupCompleted'] and all(x['Absent'] for x in p['Cleanup']) and r['post_containers']==inventory
    if common is None:common=p['Binding']
    assert p['Binding']==common
    if c['contender']=='integresql':assert p['InitialState']['LifetimeMs']==c['lifetime_ms']
    passed=r['exit_code']==0 and p['Succeeded'];samples+=len(p['Samples'])
    if passed:assert len(p['Samples'])==c['count'] and len(p['RestoredDatabases'])==c['capacity']
    else:failures.append({'index':index,'case':c,'errors':p['Failures'],'samples':len(p['Samples']),'cleanup_completed':True})
    key=tuple(c[k] for k in ['configuration','count','workers','mode'])
    groups[key][c['variant']].append({'round':c['round'],'contender':c['contender'],'succeeded':passed,'primary_ms':r['process_wall_ms'] if c['mode']=='fresh' else p.get('SuiteMs'),'path':str(path)})
rows=[]
for key,variants in sorted(groups.items()):
    item=dict(zip(['configuration','count','workers','mode'],key));item['variants']={};item['complete_pairs']=0
    for variant,cases in variants.items():
        assert len(cases)==5 and {c['round'] for c in cases}==set(range(5))
        values=[c['primary_ms'] for c in cases if c['succeeded']]
        item['variants'][variant]={'contender':cases[0]['contender'],'attempted':len(cases),'succeeded':len(values),'primary_ms':stats['describe'](values) if values else None,'raw':cases}
    by_round={variant:{c['round']:c for c in cases} for variant,cases in variants.items()}
    pairs=[(by_round['lifetime250'][r]['primary_ms'],by_round['reference'][r]['primary_ms']) for r in range(5) if by_round['lifetime250'][r]['succeeded'] and by_round['reference'][r]['succeeded']]
    item['complete_pairs']=len(pairs);item['ranking_eligible']=len(pairs)==5
    if pairs:
        ratios=sorted(statistics.median(pairs[i][0] for i in indices)/statistics.median(pairs[i][1] for i in indices) for indices in itertools.product(range(len(pairs)),repeat=len(pairs)))
        item['paired_ratio_of_medians_95']=[stats['percentile'](ratios,.025),stats['percentile'](ratios,.975)]
        item['ratio_of_medians']=statistics.median(a for a,b in pairs)/statistics.median(b for a,b in pairs)
        item['timing_condition']='All five pairs succeeded' if len(pairs)==5 else 'Conditional on successful complete pairs'
    rows.append(item)
assert completion['all_passed']==(not failures)
result={'audit_passed':True,'attempted':len(receipts),'succeeded':len(receipts)-len(failures),'failed':len(failures),'recorded_samples':samples,'scenarios':rows,'failures':failures,'selection':json.loads((root/'selection.json').read_text()),'method':'Ratio-of-medians uncertainty uses exact paired empirical bootstrap over the five round pairs. Separate phase; no pooling with25ms matrix. Small n, no population or familywise guarantee.','receipts_sha256':digest(root/'receipts.json')}
(base/'lifetime250-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k in ['audit_passed','attempted','succeeded','failed','recorded_samples']}))
