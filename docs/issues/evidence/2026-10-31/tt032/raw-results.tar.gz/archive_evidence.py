"""Create a deterministic public measurement archive, excluding private handoffs/caches."""
import gzip,hashlib,io,json,pathlib,re,tarfile
base=pathlib.Path('artifacts/tt032');out=pathlib.Path('docs/issues/evidence/2026-10-31/tt032')
excluded_roots={'upstream'}
excluded_files={'session-handoff.txt','current-run-handoff.txt','report-notes.txt','verification-unit.stdout.txt','experiment-final-build.stdout.txt'}
files=[]
for p in sorted(base.rglob('*')):
    rel=p.relative_to(base)
    if not p.is_file() or p.is_symlink() or rel.parts[0] in excluded_roots or p.name in excluded_files or '__pycache__' in rel.parts:continue
    if str(rel)=='environment/ambient-processes.txt':continue
    if p.suffix not in {'.json','.jsonl','.txt','.py','.patch','.cs'}:continue
    files.append((p,str(rel)))
assert files and all('..' not in pathlib.PurePosixPath(r).parts for _,r in files)
# Known access-token formats are never expected in experiment evidence.
for p,r in files:
    data=p.read_bytes()
    assert not re.search(rb'(?:ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16}|sk-proj-[A-Za-z0-9_-]{30,})',data),'Potential secret: '+r
records=[{'path':r,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p,r in files]
archive=out/'raw-results.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w|') as tar:
            for p,r in files:
                data=p.read_bytes();info=tarfile.TarInfo(r);info.size=len(data);info.mtime=0;info.mode=0o644;info.uid=info.gid=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers();assert [m.name for m in members]==[r['path'] for r in records]
    for member,record in zip(members,records):assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==record['sha256']
manifest={'archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'file_count':len(records),'uncompressed_bytes':sum(r['bytes'] for r in records),'archive_paths_relative_to':'artifacts/tt032','files':records,'excluded':['downloaded upstream source/cache','private session handoffs and prose notes','unrelated process command lines','verification outputs (separate validation archive)'],'measurement_source':'f077440782fd742144c89b86577c2d798e18e4ad','production_source':'221493ba28fa0f2d152563766dcafd3652796994'}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k in ['archive_bytes','file_count','uncompressed_bytes','archive_sha256']}))
