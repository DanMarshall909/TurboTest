"""Audit completed TT-032 receipts; benchmark failures are data, not audit success."""
import collections,hashlib,json,pathlib,sys
root=pathlib.Path('artifacts/tt032/representative')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,name):
    if not ok:raise ValueError(name)
plan=json.loads((root/'plan.json').read_text());receipts=json.loads((root/'receipts.json').read_text())
manifest=json.loads((root/'manifest.json').read_text());completion=json.loads((root/'completion.json').read_text())
require(len(receipts)==len(plan)==240,'CompleteMatrix')
require(completion['completed']==completion['planned']==240,'CompletionReceipt')
require(digest(root/'plan.json')==manifest['plan_sha256'],'PlanHash')
require([r['case'] for r in receipts]==plan,'PlanCoverage')
old=json.loads((root/'receipts-before-continuation.json').read_text())
require(receipts[:22]==old,'OriginalReceiptPreservation')
continuation=json.loads((root/'continuation-manifest.json').read_text())
require(digest(root/'receipts-before-continuation.json')==continuation['original_receipts_sha256'],'OriginalReceiptHash')
require(digest(root/'manifest.json')==continuation['original_manifest_sha256'],'OriginalManifestHash')
require(digest(root.parent/'continue_experiment.py')==continuation['driver_sha256'],'ContinuationDriverHash')
images={i['Id'] for i in manifest['images']};inventory=json.loads((root/'initial-containers.json').read_text())
common=None;total_samples=0;failures=[];resources=[];by_name=collections.defaultdict(lambda:{'attempted':0,'succeeded':0,'samples':0})
for index,receipt in enumerate(receipts):
    paths=list(root.glob(f'{index:03d}-*/report.json'));require(len(paths)==1,'UniqueReport')
    path=paths[0];report=json.loads(path.read_text());case=receipt['case']
    require(digest(path)==receipt['report_sha256'],'ReportHash')
    require(receipt['inputs_unchanged'] and receipt['binding_matches_experiment'],'InputBinding')
    if common is None:common=report['Binding']
    require(report['Binding']==common,'CommonBinding')
    require(receipt['post_containers']==inventory,'ExactResourceInventory')
    require(report['CleanupCompleted'] and report['Cleanup'] and all(c['Absent'] for c in report['Cleanup']),'CleanupEvidence')
    require('InitialResources' in report,'InitialImageEvidence')
    if report['Succeeded']:require('FinalResources' in report,'FinalImageEvidence')
    for boundary in ['InitialResources','FinalResources']:
        if boundary not in report:continue
        for container in report[boundary]['containers']:
            require(container['Image'] in images,'ImageBinding')
            expected=64*2**20 if container['Name'].endswith('_controller') else 256*2**20
            require(container['Memory']==expected,'MemoryBudget')
    require((report['Contender'],report['Configuration'],report['Count'],report['Workers'],report['Mode'],report['ResetWorkers'],report['Capacity'])==(case['contender'],case['configuration'],case['count'],case['workers'],case['mode'],case['reset_workers'],case['capacity']),'CaseReportIdentity')
    ordinals=[s['Ordinal'] for s in report['Samples']]
    require(len(ordinals)==len(set(ordinals)) and all(0<=n<case['count'] for n in ordinals),'SampleMembership')
    if report['Succeeded']:
        require(receipt['exit_code']==0 and len(ordinals)==case['count'],'CompleteSamples')
        require(len(report['RestoredDatabases'])==case['capacity'],'RestoredCapacity')
        require(not report['Failures'] and not report['WorkerFailures'],'NoHiddenFailures')
        require(len(report['InitialResources']['Postgres']['databases'])==len(report['FinalResources']['Postgres']['databases']),'StableDatabaseCount')
    else:
        require(receipt['exit_code']!=0 and report['Failures'],'VisibleFailure')
        failures.append({'index':index,'case':case,'samples':len(ordinals),'failures':report['Failures'],'cleanup_completed':True})
    group=by_name[case['contender']];group['attempted']+=1;group['succeeded']+=int(report['Succeeded']);group['samples']+=len(ordinals);total_samples+=len(ordinals)
require(completion['all_passed']==(not failures),'HonestCompletionOutcome')
result={'audit_passed':True,'attempted':len(receipts),'succeeded':len(receipts)-len(failures),'failed':len(failures),'planned_samples':sum(c['count'] for c in plan),'recorded_samples':total_samples,'by_contender':dict(by_name),'failures':failures,'checks':['complete_fixed_plan','original_receipts_preserved','all_report_hashes','common_source_binary_binding','image_memory_identity','sample_membership','restored_capacity_for_success','stable_database_count_for_success','every_owned_cleanup','exact_global_inventory'],'receipts_sha256':digest(root/'receipts.json'),'plan_sha256':digest(root/'plan.json')}
(root/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['failures','checks']}))
