"""Controls for post-measurement reporting fixes; no Docker or measured input mutation."""
import hashlib,json,pathlib,runpy
root=pathlib.Path.cwd();supervisor=root/'experiments/tt032/tools/run_experiment.py';analyzer=root/'experiments/tt032/tools/analyze.py'
m=runpy.run_path(str(supervisor));a=runpy.run_path(str(analyzer));checks=[]
def check(name,condition):
    assert condition,name
    checks.append(name)
good={'containers':[{'Image':'expected'}]};bad={'containers':[{'Image':'wrong'}]};f=m['image_binding']
check('failed_initial_only_image_proof',f({'Succeeded':False,'InitialResources':good},{'expected'}))
check('successful_final_image_required',not f({'Succeeded':True,'InitialResources':good},{'expected'}))
check('initial_image_mismatch_rejected',not f({'Succeeded':False,'InitialResources':bad},{'expected'}))
check('available_final_image_mismatch_rejected',not f({'Succeeded':False,'InitialResources':good,'FinalResources':bad},{'expected'}))
valid={'CleanupCompleted':True,'Cleanup':[{'Absent':True}]};m['require_cleanup'](valid,['old'],['old'])
for name,report,observed in [('cleanup_flag',{'CleanupCompleted':False,'Cleanup':[{'Absent':True}]},['old']),('volume_absence',{'CleanupCompleted':True,'Cleanup':[{'Absent':False}]},['old']),('missing_cleanup',{'CleanupCompleted':True},['old']),('inventory_drift',valid,['old','new'])]:
    try:m['require_cleanup'](report,observed,['old'])
    except RuntimeError as error:check(name+'_named_rejection',str(error)=='UnsettledResourceInventory')
    else:raise AssertionError(name+' accepted')
check('constant_ratio_interval',a['ratio_interval']([2]*5,[4]*5)==[.5,.5])
check('median_interval',a['interval']([1,2,3,4,5])==[1,5])
check('nearest_rank_p95',a['percentile']([1,2,3,4,5],.95)==5)
check('median',a['describe']([2,4,6,8,10])['median']==6)
actual=a['representative'](pathlib.Path('artifacts/tt032/representative'));expected=json.loads((root/'artifacts/tt032/representative-summary.json').read_text())
check('final_analyzer_preserves_bound_selection_numbers',{k:v for k,v in actual.items() if k!='uncertainty'}=={k:v for k,v in expected.items() if k!='uncertainty'})
check('conditional_interval_scope_is_explicit','available successful' in actual['uncertainty'])
row=next(r for r in actual['scenarios'] if r['contender']=='integresql' and r['configuration']=='durable' and r['count']==100 and r['mode']=='fresh')
check('failed_cell_not_eligible',not row['eligible'] and row['succeeded']==2 and row['primary_ms']['n']==2)
files=[supervisor,analyzer,pathlib.Path(__file__).resolve()]
result={'passed':True,'checks':checks,'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(root/'artifacts/tt032/reporting-calibration.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':True,'controls':len(checks)}))
