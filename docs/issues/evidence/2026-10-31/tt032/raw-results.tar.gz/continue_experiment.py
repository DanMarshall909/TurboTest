#!/usr/bin/env python3
"""TT-032 one-off experiment supervisor. Retains every attempt; never retries cases."""
import argparse, hashlib, itertools, json, os, pathlib, random, signal, subprocess, sys, time
ROOT = pathlib.Path.cwd().resolve()
DLL = ROOT / 'experiments/tt032/bin/Release/net10.0/CompetitiveBaseline.dll'
NAMES = ['native-template', 'integresql', 'respawn', 'turbotest']

def command(*args):
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()

def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs():
    paths = [p for p in command('git','ls-files').splitlines()
             if p.startswith(('src/', 'experiments/tt032/')) or p in ('Directory.Build.props','global.json','.ai-rules.json')]
    binaries = sorted(DLL.parent.glob('*.dll')) + sorted(DLL.parent.glob('*.json'))
    return {'head': command('git','rev-parse','HEAD'), 'tree':command('git','rev-parse','HEAD^{tree}'),
            'status':command('git','status','--porcelain'),
            'files':{p:digest(ROOT/p) for p in paths},
            'binaries':{str(p.relative_to(ROOT)):digest(p) for p in binaries},
            'sdk':command('dotnet','--version')}

def require_identity(bound, stage):
    if inputs()!=bound: raise RuntimeError('ExperimentInputDrift:'+stage)

def inventory():
    return sorted(command('docker','--host','unix:///var/run/docker.sock','ps','-a','--format','{{.ID}} {{.Names}}').splitlines())

def make_plan(phase, rounds, selections):
    rng = random.Random(20261031)
    scenarios = [('durable',1,1),('durable',20,1),('durable',100,4),
                 ('relaxed',1,1),('relaxed',20,1),('relaxed',1000,4)]
    if phase=='tune': scenarios=[('durable',20,4),('relaxed',100,4)]
    plan=[]
    for round_id in range(rounds):
        groups=list(itertools.product(scenarios, ['warm'] if phase=='tune' else ['fresh','warm']))
        rng.shuffle(groups)
        for scenario,mode in groups:
            configuration,count,workers=scenario
            base_order=list(NAMES);random.Random(20261031).shuffle(base_order)
            order=base_order[round_id%4:]+base_order[:round_id%4]
            if (round_id//4)%2: order=list(reversed(order))
            for name in order:
                settings=[1,4] if phase=='tune' else [selections[configuration][name] if workers==4 else 1]
                if round_id%2: settings.reverse()
                for reset in settings:
                    plan.append(dict(round=round_id,contender=name,configuration=configuration,count=count,
                                     workers=workers,capacity=workers,mode=mode,reset_workers=reset,lifetime_ms=25))
    return plan

def validate_plan(plan,phase,rounds):
    expected_per_round=16 if phase=='tune' else 48
    assert len(plan)==rounds*expected_per_round, 'PlanCount'
    keys=[tuple(x.items()) for x in plan]
    assert len(keys)==len(set(keys)), 'DuplicateCase'
    for r in range(rounds):
        rows=[x for x in plan if x['round']==r]
        assert len(rows)==expected_per_round, 'RoundCount'
        assert {x['contender'] for x in rows}==set(NAMES), 'ContenderMembership'
        for name in NAMES: assert sum(x['contender']==name for x in rows)==expected_per_round//4, 'ContenderBalance'
    if phase=='representative':
        for scenario in {(x['configuration'],x['count'],x['workers'],x['mode']) for x in plan}:
            positions={name:[0,0,0,0] for name in NAMES}
            for r in range(rounds):
                rows=[x for x in plan if x['round']==r and (x['configuration'],x['count'],x['workers'],x['mode'])==scenario]
                assert len(rows)==4, 'ScenarioMembership'
                for position,row in enumerate(rows):positions[row['contender']][position]+=1
            for values in positions.values():assert max(values)-min(values)<=1, 'OrderPositionBalance'


def image_binding(report, image_ids):
    if 'InitialResources' not in report:return False
    if report['Succeeded'] and 'FinalResources' not in report:return False
    observations=[report[k]['containers'] for k in ['InitialResources','FinalResources'] if k in report]
    return all(cs and all(c['Image'] in image_ids for c in cs) for cs in observations)

def validate_prefix(plan, receipts, expected_count=22):
    if len(receipts)!=expected_count:raise ValueError('ContinuationPrefixCount')
    if [r['case'] for r in receipts]!=plan[:expected_count]:raise ValueError('ContinuationPrefixCases')

def main():
    out=ROOT/'artifacts/tt032/representative'
    manifest=json.loads((out/'manifest.json').read_text());bound=manifest['inputs']
    require_identity(bound,'ContinuationPreflight')
    plan=json.loads((out/'plan.json').read_text());validate_plan(plan,'representative',5)
    if digest(out/'plan.json')!=manifest['plan_sha256']:raise ValueError('ContinuationPlanHash')
    receipts=json.loads((out/'receipts.json').read_text());validate_prefix(plan,receipts)
    baseline_inventory=json.loads((out/'initial-containers.json').read_text())
    if inventory()!=baseline_inventory:raise ValueError('ContinuationResourceInventory')
    image_ids={i['Id'] for i in manifest['images']}
    common_binding=None
    for index,r in enumerate(receipts):
        c=r['case']
        directory=out/f'{index:03d}-{c["contender"]}-{c["configuration"]}-{c["mode"]}-{c["count"]}-r{c["round"]}-w{c["reset_workers"]}'
        path=directory/'report.json'
        if digest(path)!=r['report_sha256']:raise ValueError('ContinuationReportHash')
        report=json.loads(path.read_text())
        if common_binding is None:common_binding=report['Binding']
        if not r['inputs_unchanged'] or not r['binding_matches_experiment'] or report['Binding']!=common_binding:raise ValueError('ContinuationInputBinding')
        if not image_binding(report,image_ids):raise ValueError('ContinuationImageBinding')
        if r['post_containers']!=baseline_inventory or not report['CleanupCompleted']:raise ValueError('ContinuationCleanup')
    start=len(receipts)
    for index in range(start,len(plan)):
        if list(out.glob(f'{index:03d}-*')) or (out/f'{index:03d}.stdout.txt').exists():raise ValueError('ContinuationOutputExists')
    driver=pathlib.Path(__file__).resolve();driver_sha=digest(driver)
    checkpoint=out/'receipts-before-continuation.json'
    with checkpoint.open('xb') as f:f.write((out/'receipts.json').read_bytes())
    correction={'original_manifest_sha256':digest(out/'manifest.json'),'original_receipts_sha256':digest(checkpoint),
                'driver_sha256':driver_sha,'start_index':start,'end_index':len(plan)-1,
                'source_and_binaries_unchanged':True,'no_attempt_retried':True,
                'correction':'Failed cases require matching InitialResources and every available image observation; successful cases require both boundaries. Original receipt021 is preserved unchanged.',
                'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    with (out/'continuation-manifest.json').open('x') as f:f.write(json.dumps(correction,indent=2)+'\n')
    for index,case in enumerate(plan[start:],start=start):
        require_identity(bound, 'BeforeCase')
        if digest(driver)!=driver_sha:raise RuntimeError('ContinuationDriverDrift')
        case_dir=out/f'{index:03d}-{case["contender"]}-{case["configuration"]}-{case["mode"]}-{case["count"]}-r{case["round"]}-w{case["reset_workers"]}'
        argv=['dotnet',str(DLL),'run',case['contender'],str(case['count']),str(case['workers']),case['mode'],str(case_dir),str(case['lifetime_ms']),case['configuration']]
        env=dict(os.environ,TT032_RESET_WORKERS=str(case['reset_workers']),TT032_CAPACITY=str(case['capacity']),TT032_TRACE='0')
        receipt={'case':case,'command':argv,'cwd':str(ROOT),'environment':{k:env[k] for k in ['TT032_RESET_WORKERS','TT032_CAPACITY']},
                 'before_loadavg':pathlib.Path('/proc/loadavg').read_text().strip(),'timeout_seconds':1500}
        started=time.perf_counter()
        with open(out/f'{index:03d}.stdout.txt','w') as log:
            child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            receipt['pid']=child.pid
            try: code=child.wait(timeout=1500)
            except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
                receipt['interruption']=type(error).__name__;os.killpg(child.pid,signal.SIGINT)
                try: code=child.wait(timeout=60)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid,signal.SIGKILL);code=child.wait();receipt['forced_kill']=True
        receipt.update(exit_code=code,process_wall_ms=(time.perf_counter()-started)*1000,
                       after_loadavg=pathlib.Path('/proc/loadavg').read_text().strip(),post_containers=inventory())
        receipt['inputs_unchanged']=inputs()==bound
        if digest(driver)!=driver_sha:raise RuntimeError('ContinuationDriverDrift')
        report_path=case_dir/'report.json'
        if report_path.exists():
            report=json.loads(report_path.read_text());receipt['report_succeeded']=report['Succeeded'];receipt['report_sha256']=digest(report_path)
            binding=report['Binding']
            if common_binding is None:common_binding=binding
            receipt['binding_matches_experiment']=binding==common_binding and binding['AssemblySha'].lower()==bound['binaries'][str(DLL.relative_to(ROOT))] and binding['TurboSha'].lower()==bound['binaries'][str((DLL.parent/'TurboTest.EFCore.dll').relative_to(ROOT))]
            image_ids={i['Id'] for i in manifest['images']}
            receipt['image_binding_matches']=image_binding(report,image_ids)
        else: receipt['report_succeeded']=False;receipt['missing_report']=True
        receipts.append(receipt);save(out/'receipts.json',receipts)
        print(json.dumps({'finished':index+1,'planned':len(plan),**case,'exit':code,'wall_ms':receipt['process_wall_ms'],'succeeded':receipt['report_succeeded']}),flush=True)
        if not receipt['inputs_unchanged'] or not receipt.get('binding_matches_experiment',False) or not receipt.get('image_binding_matches',False):raise RuntimeError('ExperimentIdentityRejected')
        if receipt['post_containers']!=baseline_inventory:raise RuntimeError('UnsettledResourceInventory')
        if 'interruption' in receipt:raise RuntimeError('ExperimentInterrupted; no cases retried')
    save(out/'completion.json',{'completed':len(receipts),'planned':len(plan),'all_passed':all(r['exit_code']==0 and r['report_succeeded'] for r in receipts),'ended_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    return 0 if all(r['exit_code']==0 and r['report_succeeded'] for r in receipts) else 1

if __name__=='__main__':sys.exit(main())
