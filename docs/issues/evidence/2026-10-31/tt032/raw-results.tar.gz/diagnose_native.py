import datetime,json,os,pathlib,subprocess,time
root=pathlib.Path('artifacts/tt032/native-drop-diagnostic');root.mkdir(exist_ok=False)
base=['docker','--host','unix:///var/run/docker.sock']
def invoke(args):
 p=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
 return {'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
before=invoke(base+['ps','-aq','--filter','label=tt032.owner']);assert before['exit']==0 and not before['stdout'].strip()
(root/'before.json').write_text(json.dumps(before))
cmd=['dotnet','experiments/tt032/bin/Release/net10.0/CompetitiveBaseline.dll','qualify','native-template',str(root/'qualification'),'25']
env=dict(os.environ,TT032_RESET_WORKERS='4',TT032_CAPACITY='4')
records=[]
with open(root/'stdout.txt','w') as log:
 child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 while child.poll() is None:
  record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  inventory=invoke(base+['ps','--filter','label=tt032.owner','--format','{{.ID}} {{.Names}}']);record['inventory']=inventory
  for row in inventory['stdout'].splitlines():
   cid,name=row.split(' ',1)
   if not name.endswith('_pg'):continue
   sql="SELECT json_build_object('activity',(SELECT json_agg(json_build_object('pid',pid,'database',datname,'backend_type',backend_type,'state',state,'wait_type',wait_event_type,'wait',wait_event,'query_start',query_start,'xact_start',xact_start)) FROM pg_stat_activity),'checkpoints',(SELECT row_to_json(b) FROM pg_stat_bgwriter b))::text"
   record['postgres']=invoke(base+['exec',cid,'psql','-U','postgres','-d','postgres','-At','-c',sql])
   record['logs']=invoke(base+['logs','--tail','100',cid])
  records.append(record)
  (root/'observations.json').write_text(json.dumps(records,indent=2))
  time.sleep(.5)
 result=child.wait()
(root/'completion.json').write_text(json.dumps({'command':cmd,'exit':result,'observations':len(records),'after':invoke(base+['ps','-aq','--filter','label=tt032.owner'])},indent=2))
print(json.dumps({'exit':result,'observations':len(records)}))
