"""Separate diagnostic profiles; never pooled into performance ranking."""
import json,os,pathlib,subprocess,time
root=pathlib.Path.cwd();base=root/'artifacts/tt032';docker=['docker','--host','unix:///var/run/docker.sock']
def command(args):
    p=subprocess.run(args,capture_output=True,text=True,timeout=15);return {'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
def inventory():return sorted(command(docker+['ps','-a','--format','{{.ID}} {{.Names}}'])['stdout'].splitlines())
before=inventory();receipts=[]
for configuration in ['durable','relaxed']:
    output=base/f'profile-turbo-{configuration}';assert not output.exists()
    argv=['dotnet','experiments/tt032/bin/Release/net10.0/CompetitiveBaseline.dll','run','turbotest','100','4','warm',str(output),'25',configuration]
    env=dict(os.environ,TT032_RESET_WORKERS='4',TT032_CAPACITY='4',TT032_TRACE='1')
    start=time.perf_counter();observations=[];observed=False
    with (base/f'profile-turbo-{configuration}.stdout.txt').open('x') as log:
        child=subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
        while child.poll() is None:
            if not observed:
                live=command(docker+['ps','--filter','name=tt032_','--format','{{.ID}} {{.Names}}'])['stdout'].splitlines()
                assert len(live)<=1
                if live:
                    identity=live[0].split()[0]
                    sql="SELECT json_build_object('fsync',current_setting('fsync'),'synchronous_commit',current_setting('synchronous_commit'),'full_page_writes',current_setting('full_page_writes'),'roles',(SELECT json_agg(json_build_object('name',rolname,'superuser',rolsuper,'createdb',rolcreatedb,'createrole',rolcreaterole,'replication',rolreplication,'bypassrls',rolbypassrls)) FROM pg_roles WHERE rolcanlogin))::text"
                    # Only the role name is read from the owned container; no environment/password dump.
                    r=command(docker+['exec',identity,'sh','-c','exec psql -U "$POSTGRES_USER" -d postgres -At -c "$1"','tt032-settings',sql])
                    observations.append({'elapsed_ms':(time.perf_counter()-start)*1000,'container':identity,**r})
                    if r['exit']==0:
                        data=json.loads(r['stdout']);desired='on' if configuration=='durable' else 'off'
                        observed=all(data[k]==desired for k in ['fsync','synchronous_commit','full_page_writes'])
            time.sleep(.25)
        code=child.wait()
    assert inventory()==before
    report=json.loads((output/'report.json').read_text())
    receipt={'configuration':configuration,'command':argv,'trace':True,'exit':code,'settings_observed':observed,'observations':observations,'cleanup_completed':report['CleanupCompleted'],'ranking_eligible':False,'limitation':'Diagnostic logging enabled; one successful settings observation may overlap this diagnostic run. Do not compare its wall time with ranking runs.'}
    (output/'diagnostic-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');receipts.append(receipt)
    print(json.dumps({'configuration':configuration,'exit':code,'settings_observed':observed,'succeeded':report['Succeeded']}),flush=True)
    assert code==0 and report['Succeeded'] and report['CleanupCompleted'] and observed
