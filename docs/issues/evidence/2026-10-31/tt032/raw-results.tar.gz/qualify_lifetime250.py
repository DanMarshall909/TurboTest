"""Run the predeclared250ms lifetime prerequisites once, retaining any failure."""
import hashlib,json,os,pathlib,runpy,signal,subprocess,time
root=pathlib.Path.cwd();base=root/'artifacts/tt032';original=base/'representative'
helper=runpy.run_path(str(base/'continue_experiment.py'))
bound=json.loads((original/'manifest.json').read_text())['inputs']
completion=json.loads((original/'completion.json').read_text())
assert completion['completed']==completion['planned']==240
helper['require_identity'](bound,'LifetimePrerequisites')
inventory=json.loads((original/'initial-containers.json').read_text());assert helper['inventory']()==inventory
receipt_path=base/'lifetime250-prerequisites.json';assert not receipt_path.exists()
result={};env=dict(os.environ,TT032_RESET_WORKERS='4',TT032_CAPACITY='4',TT032_TRACE='0')
for kind,args,relative in [
 ('qualification',['qualify','integresql'],'artifacts/tt032/lifetime250-qualification'),
 ('stress',['run','integresql','100','4','fresh'],'artifacts/tt032/lifetime250-stress')]:
    output=root/relative;assert not output.exists()
    command=['dotnet','experiments/tt032/bin/Release/net10.0/CompetitiveBaseline.dll',*args,relative,'250']
    if kind=='stress':command.append('durable')
    started=time.perf_counter();utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    with (base/f'lifetime250-{kind}.stdout.txt').open('x') as log:
        child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:code=child.wait(timeout=1500)
        except (subprocess.TimeoutExpired,KeyboardInterrupt):
            os.killpg(child.pid,signal.SIGINT)
            try:code=child.wait(timeout=60)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
            raise RuntimeError('Interrupted lifetime prerequisite; retain output, do not retry')
    helper['require_identity'](bound,'AfterLifetimePrerequisite')
    path=output/('qualification.json' if kind=='qualification' else 'report.json');report=json.loads(path.read_text())
    assert helper['inventory']()==inventory
    assert report['Cleanup'] and all(c['Absent'] for c in report['Cleanup'])
    result[kind]={'command':command,'environment':{k:env[k] for k in ['TT032_RESET_WORKERS','TT032_CAPACITY','TT032_TRACE']},'started_utc':utc,'exit_code':code,'process_wall_ms':(time.perf_counter()-started)*1000,'report_path':str(path.relative_to(root)),'report_sha256':helper['digest'](path),'lifetime_ms':250,'capacity':4,'reset_workers':4,'succeeded':report['Succeeded'],'cleanup_verified':True}
    receipt_path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'kind':kind,'exit':code,'succeeded':report['Succeeded']}),flush=True)
raise SystemExit(0 if all(r['succeeded'] for r in result.values()) else 1)
