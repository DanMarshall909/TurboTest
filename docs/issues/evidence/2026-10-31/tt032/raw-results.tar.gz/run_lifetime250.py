#!/usr/bin/env python3
"""TT-032 one-off experiment supervisor. Retains every attempt; never retries cases."""
import argparse, hashlib, itertools, json, os, pathlib, random, signal, subprocess, sys, time
ROOT = pathlib.Path.cwd().resolve()
DLL = ROOT / 'experiments/tt032/bin/Release/net10.0/CompetitiveBaseline.dll'
NAMES = ['native-template', 'integresql', 'respawn', 'turbotest']

def command(*args):
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()

def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs():
    paths = [p for p in command('git','ls-files').splitlines()
             if p.startswith(('src/', 'experiments/tt032/')) or p in ('Directory.Build.props','global.json','.ai-rules.json')]
    binaries = sorted(DLL.parent.glob('*.dll')) + sorted(DLL.parent.glob('*.json'))
    return {'head': command('git','rev-parse','HEAD'), 'tree':command('git','rev-parse','HEAD^{tree}'),
            'status':command('git','status','--porcelain'),
            'files':{p:digest(ROOT/p) for p in paths},
            'binaries':{str(p.relative_to(ROOT)):digest(p) for p in binaries},
            'sdk':command('dotnet','--version')}

def require_identity(bound, stage):
    if inputs()!=bound: raise RuntimeError('ExperimentInputDrift:'+stage)

def inventory():
    return sorted(command('docker','--host','unix:///var/run/docker.sock','ps','-a','--format','{{.ID}} {{.Names}}').splitlines())

def make_plan(phase, rounds, selections):
    rng = random.Random(20261031)
    scenarios = [('durable',1,1),('durable',20,1),('durable',100,4),
                 ('relaxed',1,1),('relaxed',20,1),('relaxed',1000,4)]
    if phase=='tune': scenarios=[('durable',20,4),('relaxed',100,4)]
    plan=[]
    for round_id in range(rounds):
        groups=list(itertools.product(scenarios, ['warm'] if phase=='tune' else ['fresh','warm']))
        rng.shuffle(groups)
        for scenario,mode in groups:
            configuration,count,workers=scenario
            base_order=list(NAMES);random.Random(20261031).shuffle(base_order)
            order=base_order[round_id%4:]+base_order[:round_id%4]
            if (round_id//4)%2: order=list(reversed(order))
            for name in order:
                settings=[1,4] if phase=='tune' else [selections[configuration][name] if workers==4 else 1]
                if round_id%2: settings.reverse()
                for reset in settings:
                    plan.append(dict(round=round_id,contender=name,configuration=configuration,count=count,
                                     workers=workers,capacity=workers,mode=mode,reset_workers=reset,lifetime_ms=25))
    return plan

def validate_plan(plan,phase,rounds):
    expected_per_round=16 if phase=='tune' else 48
    assert len(plan)==rounds*expected_per_round, 'PlanCount'
    keys=[tuple(x.items()) for x in plan]
    assert len(keys)==len(set(keys)), 'DuplicateCase'
    for r in range(rounds):
        rows=[x for x in plan if x['round']==r]
        assert len(rows)==expected_per_round, 'RoundCount'
        assert {x['contender'] for x in rows}==set(NAMES), 'ContenderMembership'
        for name in NAMES: assert sum(x['contender']==name for x in rows)==expected_per_round//4, 'ContenderBalance'
    if phase=='representative':
        for scenario in {(x['configuration'],x['count'],x['workers'],x['mode']) for x in plan}:
            positions={name:[0,0,0,0] for name in NAMES}
            for r in range(rounds):
                rows=[x for x in plan if x['round']==r and (x['configuration'],x['count'],x['workers'],x['mode'])==scenario]
                assert len(rows)==4, 'ScenarioMembership'
                for position,row in enumerate(rows):positions[row['contender']][position]+=1
            for values in positions.values():assert max(values)-min(values)<=1, 'OrderPositionBalance'


def image_binding(report, image_ids):
    if 'InitialResources' not in report:return False
    if report['Succeeded'] and 'FinalResources' not in report:return False
    observations=[report[k]['containers'] for k in ['InitialResources','FinalResources'] if k in report]
    return all(cs and all(c['Image'] in image_ids for c in cs) for cs in observations)

def validate_prefix(plan, receipts, expected_count=22):
    if len(receipts)!=expected_count:raise ValueError('ContinuationPrefixCount')
    if [r['case'] for r in receipts]!=plan[:expected_count]:raise ValueError('ContinuationPrefixCases')

def main():
    original=ROOT/'artifacts/tt032/representative'
    completion=json.loads((original/'completion.json').read_text())
    if completion['completed']!=completion['planned'] or completion['planned']!=240:raise ValueError('OriginalMatrixIncomplete')
    analysis_path=ROOT/'artifacts/tt032/representative-summary.json'
    protocol=ROOT/'artifacts/tt032/supplement-protocol.json'
    provenance=ROOT/'artifacts/tt032/analysis-provenance.json'
    qualification_receipt=ROOT/'artifacts/tt032/lifetime250-prerequisites.json'
    proof=json.loads(provenance.read_text())
    if digest(analysis_path)!=proof['summary_sha256'] or digest(original/'receipts.json')!=proof['receipts_sha256']:raise ValueError('SummaryProvenance')
    original_receipts=json.loads((original/'receipts.json').read_text())
    original_plan=json.loads((original/'plan.json').read_text())
    if len(original_receipts)!=240 or [r['case'] for r in original_receipts]!=original_plan:raise ValueError('OriginalReceiptPlan')
    for index,r in enumerate(original_receipts):
        reports=list(original.glob(f'{index:03d}-*/report.json'))
        if len(reports)!=1 or digest(reports[0])!=r['report_sha256'] or proof['report_sha256'][str(index)]!=r['report_sha256']:raise ValueError('OriginalReportProvenance')
    prerequisites=json.loads(qualification_receipt.read_text())
    first_report=json.loads(next(original.glob('000-*/report.json')).read_text())
    for kind in ['qualification','stress']:
        q=prerequisites[kind];qp=ROOT/q['report_path'];data=json.loads(qp.read_text())
        if digest(qp)!=q['report_sha256'] or data['Binding']!=first_report['Binding']:raise ValueError('SupplementQualificationBinding')
        if q['lifetime_ms']!=250 or q['capacity']!=4 or q['reset_workers']!=4:raise ValueError('SupplementQualificationConfiguration')
        if not data['Cleanup'] or not all(c['Absent'] for c in data['Cleanup']):raise ValueError('SupplementQualificationCleanup')
        if kind=='stress' and (data['Count'],data['Workers'],data['Mode'],data['Configuration'])!=(100,4,'fresh','durable'):raise ValueError('SupplementStressScenario')
    summary=json.loads(analysis_path.read_text())
    original_manifest=json.loads((original/'manifest.json').read_text());bound=original_manifest['inputs']
    require_identity(bound,'SupplementPreflight')
    scenarios=[];decisions=[]
    for leader in summary['leaderboard']:
        key=tuple(leader[k] for k in ['configuration','count','workers','mode'])
        candidates=[r for r in summary['scenarios'] if tuple(r[k] for k in ['configuration','count','workers','mode'])==key and r['contender']!='turbotest' and r['eligible']]
        if not candidates:raise ValueError('NoQualifiedReference:'+str(key))
        anchor=min(candidates,key=lambda r:r['primary_ms']['median'])
        floor=((leader['count']+leader['workers']-1)//leader['workers'])*250
        included=anchor['primary_ms']['bootstrap_median_95'][1]>=floor
        decision={'scenario':dict(zip(['configuration','count','workers','mode'],key)),'reference':anchor['contender'],'reference_upper_ms':anchor['primary_ms']['bootstrap_median_95'][1],'floor_ms':floor,'measure':included}
        decisions.append(decision)
        if included:scenarios.append(decision)
    plan=[];rng=random.Random(20261101)
    for round_id in range(5):
        order=list(scenarios);rng.shuffle(order)
        for d in order:
            s=d['scenario'];variants=[('lifetime250','integresql',250),('reference',d['reference'],25)]
            if round_id%2:variants.reverse()
            for variant,name,lifetime in variants:
                reset=original_manifest['selections'][s['configuration']][name] if s['workers']==4 else 1
                plan.append(dict(round=round_id,contender=name,**s,capacity=s['workers'],reset_workers=reset,lifetime_ms=lifetime,variant=variant))
    if len(plan)!=len(scenarios)*10 or len({tuple(c.items()) for c in plan})!=len(plan):raise ValueError('SupplementPlanCount')
    out=ROOT/'artifacts/tt032/lifetime250';out.mkdir(exist_ok=False)
    save(out/'plan.json',plan);save(out/'selection.json',decisions)
    baseline_inventory=inventory();save(out/'initial-containers.json',baseline_inventory)
    if baseline_inventory!=json.loads((original/'initial-containers.json').read_text()):raise ValueError('SupplementInventoryDrift')
    driver=pathlib.Path(__file__).resolve();driver_sha=digest(driver)
    extra_inputs={str(p):digest(p) for p in [analysis_path,protocol,provenance,qualification_receipt]}
    manifest={'inputs':bound,'images':original_manifest['images'],'plan_sha256':digest(out/'plan.json'),'driver_sha256':driver_sha,
              'extra_inputs':extra_inputs,'original_manifest_sha256':digest(original/'manifest.json'),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
              'interpretation':'Separate paired sensitivity phase. No pooling with original25ms cases. Analytic exclusions apply only to bounded automatic recreation at250ms.'}
    save(out/'manifest.json',manifest)
    receipts=[];common_binding=None;start=0
    for index,case in enumerate(plan[start:],start=start):
        require_identity(bound, 'BeforeCase')
        if digest(driver)!=driver_sha or any(digest(pathlib.Path(p))!=h for p,h in extra_inputs.items()):raise RuntimeError('SupplementInputDrift')
        case_dir=out/f'{index:03d}-{case["contender"]}-{case["configuration"]}-{case["mode"]}-{case["count"]}-r{case["round"]}-w{case["reset_workers"]}-{case["variant"]}'
        argv=['dotnet',str(DLL),'run',case['contender'],str(case['count']),str(case['workers']),case['mode'],str(case_dir),str(case['lifetime_ms']),case['configuration']]
        env=dict(os.environ,TT032_RESET_WORKERS=str(case['reset_workers']),TT032_CAPACITY=str(case['capacity']),TT032_TRACE='0')
        receipt={'case':case,'command':argv,'cwd':str(ROOT),'environment':{k:env[k] for k in ['TT032_RESET_WORKERS','TT032_CAPACITY']},
                 'before_loadavg':pathlib.Path('/proc/loadavg').read_text().strip(),'timeout_seconds':1500}
        started=time.perf_counter()
        with open(out/f'{index:03d}.stdout.txt','w') as log:
            child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            receipt['pid']=child.pid
            try: code=child.wait(timeout=1500)
            except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
                receipt['interruption']=type(error).__name__;os.killpg(child.pid,signal.SIGINT)
                try: code=child.wait(timeout=60)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid,signal.SIGKILL);code=child.wait();receipt['forced_kill']=True
        receipt.update(exit_code=code,process_wall_ms=(time.perf_counter()-started)*1000,
                       after_loadavg=pathlib.Path('/proc/loadavg').read_text().strip(),post_containers=inventory())
        receipt['inputs_unchanged']=inputs()==bound
        if digest(driver)!=driver_sha or any(digest(pathlib.Path(p))!=h for p,h in extra_inputs.items()):raise RuntimeError('SupplementInputDrift')
        report_path=case_dir/'report.json'
        if report_path.exists():
            report=json.loads(report_path.read_text());receipt['report_succeeded']=report['Succeeded'];receipt['report_sha256']=digest(report_path)
            binding=report['Binding']
            if common_binding is None:common_binding=binding
            receipt['binding_matches_experiment']=binding==common_binding and binding['AssemblySha'].lower()==bound['binaries'][str(DLL.relative_to(ROOT))] and binding['TurboSha'].lower()==bound['binaries'][str((DLL.parent/'TurboTest.EFCore.dll').relative_to(ROOT))]
            image_ids={i['Id'] for i in manifest['images']}
            receipt['image_binding_matches']=image_binding(report,image_ids)
        else: receipt['report_succeeded']=False;receipt['missing_report']=True
        receipts.append(receipt);save(out/'receipts.json',receipts)
        print(json.dumps({'finished':index+1,'planned':len(plan),**case,'exit':code,'wall_ms':receipt['process_wall_ms'],'succeeded':receipt['report_succeeded']}),flush=True)
        if not receipt['inputs_unchanged'] or not receipt.get('binding_matches_experiment',False) or not receipt.get('image_binding_matches',False):raise RuntimeError('ExperimentIdentityRejected')
        if receipt['post_containers']!=baseline_inventory or not report.get('CleanupCompleted',False):raise RuntimeError('UnsettledResourceInventory')
        if 'interruption' in receipt:raise RuntimeError('ExperimentInterrupted; no cases retried')
    save(out/'completion.json',{'completed':len(receipts),'planned':len(plan),'all_passed':all(r['exit_code']==0 and r['report_succeeded'] for r in receipts),'ended_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    return 0 if all(r['exit_code']==0 and r['report_succeeded'] for r in receipts) else 1

if __name__=='__main__':sys.exit(main())
