"""Read-only receipt observer; interrupt owned supervisor if cleanup proof fails."""
import json,os,pathlib,signal,sys,time
pid=int(sys.argv[1]);root=pathlib.Path.cwd();out=root/'artifacts/tt032/representative'
expected=b'python3\0artifacts/tt032/continue_experiment.py\0';proc=pathlib.Path(f'/proc/{pid}');checked=0
assert (proc/'cmdline').read_bytes()==expected
assert (proc/'cwd').resolve()==root
while proc.exists() and (proc/'cmdline').read_bytes()==expected:
    try: rows=json.loads((out/'receipts.json').read_text())
    except json.JSONDecodeError: time.sleep(.5);continue
    for index,row in enumerate(rows[checked:],checked):
        paths=list(out.glob(f'{index:03d}-*/report.json'))
        report=json.loads(paths[0].read_text()) if len(paths)==1 else {}
        if not report.get('CleanupCompleted'):
            (out/'cleanup-watch-stop.json').write_text(json.dumps({'index':index,'supervisor_pid':pid,'reason':'Missing or failed cleanup proof'},indent=2)+'\n')
            os.kill(pid,signal.SIGINT);sys.exit(1)
        checked=index+1
    time.sleep(.5)
(out/'cleanup-watch-completion.json').write_text(json.dumps({'checked_receipts':checked,'supervisor_pid':pid,'failed_cleanup_observed':False},indent=2)+'\n')
print(f'Cleanup observer ended after {checked} receipts')
