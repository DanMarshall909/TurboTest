using TurboTest.EFCore.Internal;

foreach (var registerAfterAcquisition in new[] { false, true })
{
    await using var slots = new TtSlotPool<object>(1, 1, _ => new object(),
        (_, _) => Task.CompletedTask, _ => Task.CompletedTask);
    _ = await slots.AcquireAsync();
    using var cancellation = new CancellationTokenSource();
    var entered = 0;
    var context = new ImmediatePostContext();
    var previous = SynchronizationContext.Current;
    Task waiting;
    SynchronizationContext.SetSynchronizationContext(context);
    try { waiting = AcquireWithRegistration(); }
    finally { SynchronizationContext.SetSynchronizationContext(previous); }
    await cancellation.CancelAsync();
    try { await waiting; }
    catch (OperationCanceledException) { }
    Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(new
    {
        registerAfterAcquisition, injectedCallbacks = entered,
        canceled = waiting.IsCanceled, immediatePosts = context.Posts
    }));
    if (entered != (registerAfterAcquisition ? 1 : 0) || !waiting.IsCanceled)
        throw new Exception("The predicted registration lifetime race was not reproduced.");

    async Task AcquireWithRegistration()
    {
        var acquisition = registerAfterAcquisition ? slots.AcquireAsync(cancellation.Token) : null;
        using var callback = cancellation.Token.Register(() => Interlocked.Increment(ref entered));
        acquisition ??= slots.AcquireAsync(cancellation.Token);
        _ = await acquisition;
    }
}

sealed class ImmediatePostContext : SynchronizationContext
{
    public int Posts;
    public override void Post(SendOrPostCallback callback, object? state)
    {
        Interlocked.Increment(ref Posts);
        // Force the legal ordering in which the acquisition continuation wins
        // before cancellation dispatch reaches an earlier registration.
        callback(state);
    }
}
