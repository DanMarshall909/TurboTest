import gzip, hashlib, io, json, pathlib, tarfile
root = pathlib.Path('artifacts/tt033')
verification = pathlib.Path('artifacts/tt033-verification-ci-repair')
out = pathlib.Path('docs/issues/evidence/2026-11-01/tt033')
sha = lambda b: hashlib.sha256(b).hexdigest()
proof = json.loads((verification/'verification.json').read_text())
assert proof['result'] == 'PASS'
assert all(v['failed'] == v['skipped'] == 0 for v in proof['tests'].values())
original = json.loads(pathlib.Path('artifacts/tt033-verification/source-identity.json').read_text())
current = json.loads((verification/'source-identity.json').read_text())
changed = [p for p,h in current['files'].items() if original['files'].get(p) != h]
assert changed == ['tests/TurboTest.Tests/FactoryBackpressureTests.cs'], changed
assert current['resolvedDependencies'] == original['resolvedDependencies']
for p,h in current['files'].items(): assert sha(pathlib.Path(p).read_bytes()) == h, p
failed = root/'ci-attempt1/correctness-evidence.zip'
assert sha(failed.read_bytes()) == 'a5fb0bc84e53917aca7a67e0f6cd3ab25f2e2f50db29eed0ebe4348c57ad9436'
diag = [json.loads(x) for x in (root/'ci-race-diagnostic/result.log').read_text().splitlines()]
assert [(x['registerAfterAcquisition'],x['injectedCallbacks'],x['canceled']) for x in diag] == [(False,0,True),(True,1,True)]
files = [(p,'verification/'+str(p.relative_to(verification))) for p in verification.rglob('*') if p.is_file()]
for name in ['ci-attempt1/correctness-evidence.zip','ci-attempt1/failed-job.log','ci-attempt1/run-metadata.json','ci-race-diagnostic/Program.cs','ci-race-diagnostic/Diagnostic.csproj','ci-race-diagnostic/result.log','ci-race-diagnostic/restore-network-failure.log','ci-race-diagnostic/fixture-repair.patch','ci-repair-verification.log','package_ci_repair.py']:
 files.append((root/name,name))
archive = out/'ci-repair-evidence.tar.gz'; inventory=[]
with archive.open('wb') as target, gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as gz, tarfile.open(fileobj=gz,mode='w') as tar:
 for path,name in sorted(files,key=lambda x:x[1]):
  assert not path.is_symlink(); data=path.read_bytes(); entry=tarfile.TarInfo(name); entry.size=len(data); entry.mode=0o644; entry.mtime=0
  tar.addfile(entry,io.BytesIO(data)); inventory.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive) as tar:
 assert sorted(tar.getnames()) == sorted(f['path'] for f in inventory)
 for f in inventory: assert sha(tar.extractfile(f['path']).read()) == f['sha256']
result={'maintained_verification':proof,'changed_maintained_inputs':changed,'resolved_dependencies_changed':False,
 'diagnostic':diag,'original_hosted_failure':{'url':'https://github.com/DanMarshall909/TurboTest/actions/runs/41252036297','candidate':'44bb7ff3a4022b6fd02b790de1056e92a081a082','fast_passed':364,'fast_failed':1,'slow_executed':False,'rerun':False},
 'lane_wall_seconds':{lane:json.loads((verification/('test-'+lane+'.json')).read_text())['elapsedSeconds'] for lane in ['fast','slow']},
 'lane_review':'Membership and deadlines unchanged. Both blocking-callback theory cases pass around the intentional 100 ms drain deadline. The fast lane remains a few seconds; native contracts remain slow. No evidence justifies a lane change.',
 'production_changes':False,'experiment_changes':False,'coverage_and_mutation':'Existing behavioral assertions retained. Forced-order diagnostic reproduces fixture precondition defect; no new numerical coverage/mutation claim and no changed production scope.',
 'archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'files':inventory}
(out/'ci-repair-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['files','maintained_verification']}))
