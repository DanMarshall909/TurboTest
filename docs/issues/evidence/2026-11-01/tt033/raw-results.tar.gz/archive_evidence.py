import gzip,hashlib,io,json,pathlib,tarfile
root=pathlib.Path('artifacts/tt033');out=pathlib.Path('docs/issues/evidence/2026-11-01/tt033')
names=['archive_evidence.py','calibrate.py','calibration-01.json','calibration-final.json','calibration-before-provenance-fix.stdout.json','build-01.log','build-02.log','build-03.log','storage-preflight.json','qualification-01.stdout.txt','paired-01.stdout.txt','summary.json','reset-costs.json','source.patch']
paths=[root/n for n in names]
for folder in ['qualification-01','paired-01']:paths.extend(p for p in (root/folder).rglob('*') if p.is_file())
paths=sorted(paths,key=lambda p:str(p.relative_to(root)))
def sha(data):return hashlib.sha256(data).hexdigest()
inventory=[]
archive=out/'raw-results.tar.gz'
with archive.open('wb') as target,gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in paths:
  assert p.is_file() and not p.is_symlink(),p
  data=p.read_bytes();name=str(p.relative_to(root));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(data));inventory.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive) as tar:
 assert sorted(tar.getnames())==sorted(x['path'] for x in inventory)
 for f in inventory:assert sha(tar.extractfile(f['path']).read())==f['sha256']
result={'archive':archive.name,'archive_paths_relative_to':'artifacts/tt033','archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'file_count':len(paths),'uncompressed_bytes':sum(x['bytes'] for x in inventory),'files':inventory}
(out/'evidence-manifest.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files'}))
