import copy,hashlib,json,pathlib,sys,tempfile
root=pathlib.Path.cwd();sys.path.insert(0,str(root/'experiments/tt032/tools'))
import run_compiled as run,analyze_compiled as analyze,run_experiment as common
checks=[]
run.validate_plan(run.plan());checks.append('fixed_ten_case_plan')
def reject(label,expected,action):
    try:action()
    except (ValueError,RuntimeError) as e:
        assert str(e)==expected,(label,str(e));checks.append(label);return
    raise AssertionError('FaultAccepted:'+label)
for fault,change in [('duplicate',lambda p:p.__setitem__(1,p[0])),('order',lambda p:p.reverse()),('count',lambda p:p[0].__setitem__('count',999))]:
    p=copy.deepcopy(run.plan());change(p);reject('reject_'+fault,'PairedPlanMismatch',lambda:run.validate_plan(p))
assert analyze.paired_interval([.5]*5,[1]*5)==[.5,.5];checks.append('constant_half_ratio')
assert analyze.paired_interval([1,2,3,4,5],[2,4,6,8,10])==[.5,.5];checks.append('paired_resampling_preserves_relation')
case=run.plan()[0]
report={k:case[v] for k,v in {'Contender':'contender','Configuration':'configuration','Count':'count','Workers':'workers','Capacity':'capacity','ResetWorkers':'reset_workers','Mode':'mode'}.items()}
resource={'containers':[{'Image':'pg'}],'Postgres':dict.fromkeys(['fsync','synchronous_commit','full_page_writes'],'off')}
report.update(Succeeded=True,InitialResources=resource,FinalResources=copy.deepcopy(resource),Samples=[{}]*1000,SettledState={'Ready':4,'ResetFailures':0})
run.validate_run(report,case,{'pg'});checks.append('complete_run_accepted')
for label,change,diagnostic in [
 ('wrong_count',lambda p:p.__setitem__('Count',999),'RunScenarioMismatch'),
 ('wrong_durability',lambda p:p['InitialResources']['Postgres'].__setitem__('full_page_writes','on'),'DurabilityMismatch'),
 ('wrong_image',lambda p:p['InitialResources']['containers'][0].__setitem__('Image','other'),'ImageBindingRejected'),
 ('recovered_failure',lambda p:p['SettledState'].__setitem__('ResetFailures',1),'CompleteWorkflowRejected'),
 ('missing_sample',lambda p:p['Samples'].pop(),'CompleteWorkflowRejected'),
 ('unsettled_capacity',lambda p:p['SettledState'].__setitem__('Ready',3),'CompleteWorkflowRejected')]:
    p=copy.deepcopy(report);change(p);reject('reject_'+label,diagnostic,lambda:run.validate_run(p,case,{'pg'}))
assert common.image_binding({'Succeeded':False,'InitialResources':{'containers':[{'Image':'pg'}]}},{'pg'});checks.append('failed_initial_image_allowed')
for i,p in enumerate([{'CleanupCompleted':False,'Cleanup':[{'Absent':True}]},{'CleanupCompleted':True,'Cleanup':[{'Absent':False}]},{'CleanupCompleted':True,'Cleanup':[]}]):
    reject('reject_cleanup_'+str(i),'UnsettledResourceInventory',lambda:common.require_cleanup(p,[],[]))
for p in pathlib.Path('experiments/tt032/tools').glob('*.py'):compile(p.read_text(),str(p),'exec')
checks.append('python_syntax')
with tempfile.TemporaryDirectory(prefix='tt033-calibration-') as scratch:
    p=pathlib.Path(scratch)/'qualification.json';p.write_text(json.dumps({'Succeeded':True,'Failures':[],'Contender':'respawn'}))
    reject('reject_wrong_qualification_contender','QualificationContender',lambda:run.qualification_report(p,{},set(),'compiled'))
    bad={'qualification':[{'report':str(p),'sha256':'wrong','recovery':str(p),'recovery_sha256':'wrong'}]*2}
    reject('reject_changed_qualification_evidence','QualificationEvidenceDigest',lambda:analyze.validate_qualification_evidence(bad))
    bad['qualification'][0]['report']=str(pathlib.Path(scratch)/'missing')
    reject('reject_missing_qualification_evidence','QualificationEvidenceMissing',lambda:analyze.validate_qualification_evidence(bad))
files=['experiments/tt032/tools/run_compiled.py','experiments/tt032/tools/analyze_compiled.py','experiments/tt032/tools/run_experiment.py','artifacts/tt033/calibrate.py']
receipt={'passed':True,'checks':checks,'sha256':{p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in files}}
pathlib.Path('artifacts/tt033/calibration-final.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
