import gzip,hashlib,io,json,pathlib,tarfile
root=pathlib.Path('artifacts/tt033'); verification=pathlib.Path('artifacts/tt033-verification-startup-repair');out=pathlib.Path('docs/issues/evidence/2026-11-01/tt033')
sha=lambda b:hashlib.sha256(b).hexdigest()
proof=json.loads((verification/'verification.json').read_text());assert proof['lane']=='fast' and proof['result']=='PASS' and proof['tests']['fast']['passed']==365
prior=json.loads(pathlib.Path('artifacts/tt033-verification-ci-repair/source-identity.json').read_text());current=json.loads((verification/'source-identity.json').read_text())
changed=[p for p,h in current['files'].items() if prior['files'].get(p)!=h];assert changed==['tests/TurboTest.Tests/StartupLateDrainTests.cs'];assert current['resolvedDependencies']==prior['resolvedDependencies']
for p,h in current['files'].items():assert sha(pathlib.Path(p).read_bytes())==h,p
assert sha((root/'ci-attempt2/correctness-evidence.zip').read_bytes())=='60fd81c274cf5436c9aac80cd64e77f8556c7af592c2e170e0c658c5fa29b9c4'
diag=[json.loads(line) for line in (root/'startup-race-diagnostic/result.log').read_text().splitlines()]
assert [(r['callbacks'],r['cleanupStage'],r['remaining']) for r in diag]==[(0,None,0),(1,'StartupCancellation',0)]
files=[(p,'verification/'+str(p.relative_to(verification))) for p in verification.rglob('*') if p.is_file()]
for name in ['ci-attempt2/correctness-evidence.zip','ci-attempt2/failed-job.log','ci-attempt2/run-metadata.json','startup-race-diagnostic/Program.cs','startup-race-diagnostic/Diagnostic.csproj','startup-race-diagnostic/result.log','startup-race-diagnostic/fixture-repair.patch','startup-repair-verification.log','package_startup_repair.py']:files.append((root/name,name))
archive=out/'startup-repair-evidence.tar.gz';inventory=[]
with archive.open('wb') as target,gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p,name in sorted(files,key=lambda x:x[1]):
  assert not p.is_symlink();data=p.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;tar.addfile(entry,io.BytesIO(data));inventory.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive) as tar:
 assert sorted(tar.getnames())==sorted(f['path'] for f in inventory)
 for f in inventory:assert sha(tar.extractfile(f['path']).read())==f['sha256']
result={'maintained_verification':proof,'changed_inputs_since_first_repair':changed,'production_changes':False,'experiment_changes':False,'dependency_changes':False,'diagnostic':diag,
'failed_hosted_run':'https://github.com/DanMarshall909/TurboTest/actions/runs/41253502713','failed_hosted_candidate':'04ec654ae9b1f79922b954fbbd234284d70fc101','failed_hosted_fast':{'passed':364,'failed':1,'slow_executed':False},'rerun_failed_attempt':False,
'validation_scope':'Current source: complete local fast365PASS. Previous all541PASS remains source-bound to the first repair and is not claimed as a full run on this second repair. Merge requires renewed exact-candidate review and complete hosted fast+slow verification. Native test, production, experiment, dependencies and lane inputs unchanged; only fast startup fixture precondition changed.',
'coverage_and_refactor':'All existing failure/ownership/retry assertions retained; entry signal establishes injected fault before releasing registration lifetime. Actual startup implementation diagnostic contrasts forced old/repaired schedules. No production refactor or numerical coverage/mutation claim.',
'archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'files':inventory}
(out/'startup-repair-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'result':proof['result'],'members':len(inventory),'archive_sha256':result['archive_sha256'],'archive_bytes':result['archive_bytes']}))
