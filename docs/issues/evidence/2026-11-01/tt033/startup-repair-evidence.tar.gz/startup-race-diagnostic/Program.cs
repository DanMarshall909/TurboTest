using TurboTest.EFCore;
using TurboTest.EFCore.Internal;

foreach (var waitForCallback in new[] { false, true })
{
    using var caller = new CancellationTokenSource();
    using var dispatch = new ManualResetEventSlim();
    var initialized = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var release = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var exited = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var dispatchEntered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var callbackEntered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var callbacks = 0;
    CancellationTokenRegistration blocker = default;
    var pool = new DiagnosticPool();
    var startup = Tt.InitializeOwnedPoolAsync(pool, new TtOptions(), Initialize, "TestInitialize", caller.Token);
    await initialized.Task;
    caller.Cancel();
    TtLifecycleException interrupted;
    try { await startup; throw new Exception("Expected startup interruption."); }
    catch (TtLifecycleException error) { interrupted = error; }
    await dispatchEntered.Task.WaitAsync(TimeSpan.FromSeconds(2));
    if (waitForCallback)
    {
        dispatch.Set();
        await callbackEntered.Task.WaitAsync(TimeSpan.FromSeconds(2));
        release.SetResult();
    }
    else
    {
        release.SetResult();
        await exited.Task.WaitAsync(TimeSpan.FromSeconds(2));
        dispatch.Set();
    }
    string? cleanupStage = null;
    try { await interrupted.Cleanup!.RetryCleanupAsync().WaitAsync(TimeSpan.FromSeconds(2)); }
    catch (TtLifecycleException error) { cleanupStage = error.Stage; }
    await interrupted.Cleanup!.RetryCleanupAsync();
    blocker.Dispose();
    Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(new { waitForCallback, callbacks, interrupted.Stage, cleanupStage, remaining = pool.Snapshot.Reserved }));
    if (callbacks != (waitForCallback ? 1 : 0) || cleanupStage != (waitForCallback ? "StartupCancellation" : null) || pool.Snapshot.Reserved != 0)
        throw new Exception("The predicted startup registration-lifetime mechanism was not reproduced.");

    async Task Initialize(CancellationToken token)
    {
        using (token.Register(() => { callbacks++; callbackEntered.TrySetResult(); throw new NotSupportedException("diagnostic callback"); }))
        {
            // Hold dispatch before the injected callback, modelling delayed async cancellation.
            blocker = token.Register(() => { dispatchEntered.TrySetResult(); dispatch.Wait(); });
            await pool.Slots.WarmAsync(1, default);
            initialized.SetResult();
            await release.Task;
        }
        exited.SetResult();
    }
}
sealed class DiagnosticPool : ITtDatabasePool
{
    internal TtSlotPool<object> Slots { get; } = new(1, 1, _ => new object(), (_, _) => Task.CompletedTask, _ => Task.CompletedTask);
    public TtPoolSnapshot Snapshot => Slots.Snapshot;
    public TtResourceBudget Budget => TtResourceBudget.Create(new TtOptions { PoolSize = 1 }, true);
    public IReadOnlyList<string> OwnedResourceIds => Snapshot.Reserved == 0 ? [] : [Snapshot.OwnerId.ToString("N")];
    public Task<TtDatabase> GetDatabaseAsync(CancellationToken cancellationToken = default) => throw new NotSupportedException();
    public ValueTask DisposeAsync() => Slots.DisposeAsync();
    public Task RetryCleanupAsync() => Slots.RetryCleanupAsync();
}
