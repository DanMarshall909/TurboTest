import gzip,hashlib,io,json,pathlib,tarfile
root=pathlib.Path('artifacts/tt033-verification');work=pathlib.Path('artifacts/tt033');out=pathlib.Path('docs/issues/evidence/2026-11-01/tt033')
proof=json.loads((root/'verification.json').read_text());assert proof['result']=='PASS'
for lane in proof['tests'].values():assert lane['failed']==lane['skipped']==0
calibration=json.loads((work/'calibration-final.json').read_text());assert calibration['passed']
sha=lambda b:hashlib.sha256(b).hexdigest()
for path,digest in calibration['sha256'].items():assert sha(pathlib.Path(path).read_bytes())==digest
files=[(p,'verification/'+str(p.relative_to(root))) for p in root.rglob('*') if p.is_file()]
files.extend((work/name,name) for name in ['verification-unit.log','verification.log','verification-storage.json','package_validation.py'])
inventory=[];archive=out/'validation-results.tar.gz'
with archive.open('wb') as target,gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p,name in sorted(files,key=lambda x:x[1]):
  assert not p.is_symlink();data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));inventory.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(inventory)
 for f in inventory:assert sha(tar.extractfile(f['path']).read())==f['sha256']
result={'maintained_verification':proof,'commands':[{'command':'python3 -m unittest discover -s scripts -p test_verify.py','exit_code':0,'passed':10},{'command':'python3 scripts/verify.py all --output artifacts/tt033-verification','exit_code':0},{'command':'dotnet build experiments/tt032/CompetitiveBaseline.csproj -c Release --no-restore','exit_code':0,'warnings':0,'errors':0},{'command':'python3 artifacts/tt033/calibrate.py','exit_code':0,'controls':len(calibration['checks'])},{'command':'git diff --check','exit_code':0}],
 'lane_wall_seconds':{lane:json.loads((root/('test-'+lane+'.json')).read_text())['elapsedSeconds'] for lane in ['fast','slow']},
 'lane_review':'No maintained tests or lanes changed. Fast feedback remains a few seconds; slow PostgreSQL contracts retain intentional lifecycle waits. No lane move is justified by this single run.',
 'production_sources_and_tests_changed':False,'mutation':'No changed maintained production/test scope; isolated experiment qualified with real PostgreSQL and deliberate faults. No mutation score claimed.',
 'calibration':calibration,'archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'files':inventory,
 'completion_review':'Independent GPT-6 Astra exact-candidate review and actual publication/CI are recorded on the PR linked from issue27. This receipt does not self-approve.'}
(out/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'result':proof['result'],'tests':proof['tests'],'archive_bytes':result['archive_bytes'],'archive_sha256':result['archive_sha256'],'members':len(inventory)}))
