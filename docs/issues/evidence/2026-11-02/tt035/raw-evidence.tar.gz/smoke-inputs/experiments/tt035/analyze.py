"""Summarize the predeclared paired experiment, retaining rounds as sampling units."""
import json, pathlib, random, statistics, sys

out=pathlib.Path(sys.argv[1])
assert json.loads((out/'completed.json').read_text())=={'completed':True,'failures':[]}
rows=[]; samples={'respawn':[], 'cached':[]}; configs=[]; sql=set()
for pair in range(5):
    row={'pair':pair}
    for contender in ['respawn','cached']:
        folder=out/f'{pair}-{contender}'
        r=json.loads((folder/'report.json').read_text()); receipt=json.loads((folder/'receipt.json').read_text())
        assert r['Succeeded'] and r['Count']==1000 and r['Parallelism']==4
        assert receipt['cleanup'] and receipt['exit_code']==0 and receipt['inputs_unchanged'] and 'failure' not in receipt
        assert all(w['Qualification'] and len(w['Samples'])==250 for w in r['Workers'])
        configs.append((receipt['configuration'],r['Settings']))
        sql.update(w['CachedSql'] for w in r['Workers'])
        for w in r['Workers']:samples[contender].extend(w['Samples'])
        row[contender]=r['SuiteMs']
    row['ratio']=row['cached']/row['respawn'];rows.append(row)
assert all(c==configs[0] for c in configs) and len(sql)==1,'Matched inputs'
medians={c:statistics.median(r[c] for r in rows) for c in samples}
rng=random.Random(35035); ratios=[]
for _ in range(20000):
    picked=[rng.choice(rows) for _ in rows]
    ratios.append(statistics.median(r['cached'] for r in picked)/statistics.median(r['respawn'] for r in picked))
ratios.sort();interval=[ratios[int(.025*len(ratios))],ratios[int(.975*len(ratios))-1]]
result={'pairs':rows,'suite_medians_ms':medians,'candidate_reference_ratio':medians['cached']/medians['respawn'],
        'paired_bootstrap_95':interval,'bootstrap':{'seed':35035,'resamples':20000,'unit':'paired round','statistic':'ratio of medians'},
        'cycle_medians_ms':{c:{k:statistics.median(s[k] for s in v) for k in ['OpenMs','ApplicationMs','ResetMs','CycleMs']} for c,v in samples.items()},
        'decision':'2x supported' if interval[1]<.5 else 'gain supported; 2x not supported' if interval[1]<1 else 'no demonstrated gain; not equivalence',
        'validated':{'runs':10,'measured_cycles':10000,'identical_configurations':True,'identical_cached_sql':True,'all_successful_and_cleaned':True}}
(out/'summary.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
