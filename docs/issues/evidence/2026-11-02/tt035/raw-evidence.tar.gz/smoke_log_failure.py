"""One-off calibration: fail the first Docker log capture; owned cleanup must still run."""
import importlib.util, json, pathlib, subprocess, sys
root=pathlib.Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('tt035_run',root/'experiments/tt035/run.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=subprocess.run
injected=[]
def run(command,**kwargs):
    if command[:4]==module.DOCKER+['logs'] and not injected:
        injected.append(command[-1])
        raise subprocess.TimeoutExpired(command,30)
    return original(command,**kwargs)
subprocess.run=run
sys.argv=['run.py','--smoke','--output','artifacts/tt035/smoke-final']
module.main()
assert len(injected)==1
out=root/'artifacts/tt035/smoke-final'
receipts=[json.loads(p.read_text()) for p in out.glob('*/receipt.json')]
assert len(receipts)==2 and all(r['cleanup'] and r['exit_code']==0 for r in receipts)
assert sum('log_error' in r for r in receipts)==1
(out/'fault-calibration.json').write_text(json.dumps({'fault':'Docker logs timeout','container_id':injected[0],'owned_cleanup_verified':True},indent=2))
