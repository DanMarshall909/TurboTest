using System;
using System.IO;
public class StartupHook
{
    private static readonly object Gate = new object();
    public static void Initialize()
    {
        var path = Environment.GetEnvironmentVariable("TT037_SAFE_FAILURE_LOG");
        if (String.IsNullOrEmpty(path)) return;
        File.AppendAllText(path, "Startup hook loaded\n");
        AppDomain.CurrentDomain.FirstChanceException += (sender, args) =>
        {
            if (args.Exception.GetType().FullName != "TurboTest.EFCore.TtLifecycleException") return;
            try { lock (Gate) File.AppendAllText(path, DateTime.UtcNow.ToString("O") + " " + args.Exception.Message + "\n"); }
            catch { }
        };
    }
}
