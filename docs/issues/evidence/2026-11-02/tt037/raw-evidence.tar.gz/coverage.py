"""One-off source-bound coverage diagnostic for the completed TT-037 change."""
import json
import os
from pathlib import Path
import sys
sys.path.insert(0, str(Path.cwd()))
from scripts import verify
out = Path('artifacts/tt037/coverage').resolve()
out.mkdir()
env = dict(os.environ, DOCKER_HOST='unix:///var/run/docker.sock')
binding = verify.source_identity()
verify.write_json(out / 'source-identity.json', binding)
fast = json.loads(Path('artifacts/tt037/final-repaired/fast-results.json').read_text())
slow = json.loads(Path('artifacts/tt037/final-repaired/slow-results.json').read_text())
prefixes = ['PreparedBackgroundReturnTests.', 'ResetTimingTests.',
            'DrainDeadlineTests.A_timed_out_prepared_drain',
            'BenchmarkRunnerTests.Comparison_preflight']
selection = '|'.join('FullyQualifiedName~' + name for name in prefixes)
expected = {'fast': [r['name'] for r in fast],
            'native': [r['name'] for r in slow if any(p in r['name'] for p in prefixes)]}
before = verify.docker_inventory(out, 'before', env)
try:
    for lane, expression in [('fast', 'Category!=PostgreSQL'), ('native', selection)]:
        results = out / lane
        verify.run_phase(lane, ['dotnet', 'test', 'tests/TurboTest.Tests/TurboTest.Tests.csproj', '--no-build',
            '-c', 'Release', '--filter', expression, '--results-directory', str(results),
            '--logger', 'trx;LogFileName=results.trx', '--logger', 'console;verbosity=normal',
            '--collect', 'Code Coverage;Format=cobertura', '--blame-hang-timeout', '60s',
            '--blame-hang-dump-type', 'none'], out, 120 if lane == 'fast' else 300, env)
        rows = verify.read_results(results / 'results.trx', expected[lane])
        verify.write_json(out / (lane + '-results.json'), rows)
        print(lane, len(rows), 'passed', flush=True)
    assert binding == verify.source_identity(), 'SourceChanged'
finally:
    after = verify.docker_inventory(out, 'after', env)
    verify.write_json(out / 'settlement.json', {'unchanged': before == after})
    assert before == after
