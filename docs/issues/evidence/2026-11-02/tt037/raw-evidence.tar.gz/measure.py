"""One-off TT-037 comparison; contract fixed before the first timed run."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import sys
sys.path.insert(0, str(Path.cwd()))
from scripts import verify

root = Path('artifacts/tt037').resolve()
contract = json.loads((root / 'measurement-contract.json').read_text())
out = root / 'measurement'
out.mkdir()
env = dict(os.environ, DOCKER_HOST='unix:///var/run/docker.sock')
baseline = root / 'runtime-baseline'
candidate = root / 'runtime-candidate'
shutil.copytree('tests/TurboTest.Tests/bin/Release/net10.0', candidate)
verify.write_json(out / 'candidate-source-identity.json', verify.source_identity())
old_binding = json.loads((root / 'baseline/source-identity.json').read_text())
for path, digest in old_binding['compiledInputs'].items():
    relative = Path(path).relative_to('tests/TurboTest.Tests/bin/Release/net10.0')
    assert hashlib.sha256((baseline / relative).read_bytes()).hexdigest() == digest, path
runtimes = {'baseline': baseline, 'candidate': candidate}
def runtime_identity():
    return {name: {str(p.relative_to(directory)): hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in sorted(directory.rglob('*')) if p.is_file()}
            for name, directory in runtimes.items()}
identity = runtime_identity()
verify.write_json(out / 'runtime-identity.json', identity)
before = verify.docker_inventory(out, 'before', env)
volumes_before = verify.run_phase('volumes-before', ['docker', '--host', env['DOCKER_HOST'], 'volume', 'ls', '--format', '{{.Name}}'], out, 30, env)
verify.run_phase('image', ['docker', '--host', env['DOCKER_HOST'], 'image', 'inspect', 'postgres:16-alpine', '--format', '{{.Id}}'], out, 30, env)
rows = []
try:
    selection = '|'.join('FullyQualifiedName=' + name for name in contract['tests'])
    for pair, order in enumerate(contract['pairs']):
        for name in order:
            phase = f'pair{pair}-{name}'
            results = out / phase
            command = ['dotnet', 'vstest', str(runtimes[name] / 'TurboTest.Tests.dll'),
                       '--TestCaseFilter:' + selection, '--ResultsDirectory:' + str(results),
                       '--logger:trx;LogFileName=results.trx', '--logger:console;verbosity=normal']
            verify.run_phase(phase, command, out, contract['deadlinePerInvocationSeconds'], env)
            tests = verify.read_results(results / 'results.trx', contract['tests'])
            receipt = json.loads((out / (phase + '.json')).read_text())
            row = {'pair': pair, 'runtime': name, 'wallSeconds': receipt['elapsedSeconds'], 'tests': tests}
            rows.append(row)
            verify.write_json(out / 'attempts.json', rows)
            print(phase, round(row['wallSeconds'], 3), flush=True)
    assert identity == runtime_identity(), 'RuntimeChanged'
    ratios = []
    for pair in range(len(contract['pairs'])):
        pair_rows = {r['runtime']: r['wallSeconds'] for r in rows if r['pair'] == pair}
        ratios.append(pair_rows['candidate'] / pair_rows['baseline'])
    verify.write_json(out / 'summary.json', {'pairs': len(ratios), 'candidateOverBaselineWallRatios': ratios,
        'medianRatio': statistics.median(ratios), 'attempts': rows, 'limits': contract['limits']})
finally:
    after = verify.docker_inventory(out, 'after', env)
    volumes_after = verify.run_phase('volumes-after', ['docker', '--host', env['DOCKER_HOST'], 'volume', 'ls', '--format', '{{.Name}}'], out, 30, env)
    verify.write_json(out / 'settlement.json', {'containersUnchanged': before == after,
        'volumesUnchanged': sorted(volumes_before.splitlines()) == sorted(volumes_after.splitlines())})
    assert before == after
    assert sorted(volumes_before.splitlines()) == sorted(volumes_after.splitlines())
