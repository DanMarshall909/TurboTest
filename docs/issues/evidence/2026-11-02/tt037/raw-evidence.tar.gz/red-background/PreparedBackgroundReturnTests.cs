using Microsoft.EntityFrameworkCore;
using TurboTest.EFCore;

namespace TurboTest.Tests;

public class PreparedBackgroundReturnTests
{
    [Fact]
    [Trait("Category", "PostgreSQL")]
    public async Task A_return_releases_the_test_while_the_pool_owns_reset_and_shutdown_waits_for_it()
    {
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var release = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var resets = 0;
        var baseline = new TtBaselineDefinition<TestDbContext>("background-return-v1", TtSchemaInitialization.EnsureCreated,
            async (context, token) =>
            {
                context.Users.Add(new User { Email = "background-seed@example.test" });
                await context.SaveChangesAsync(token);
            });
        var fixture = await Tt.CreatePreparedFactoryAsync(new TtOptions { PoolSize = 2 }, baseline, default,
            afterRowCommit: async _ =>
            {
                if (Interlocked.Increment(ref resets) != 1) return;
                entered.TrySetResult();
                await release.Task;
            });
        var dirty = await fixture.CreateLeaseAsync();
        var dirtyName = dirty.Context.Database.GetDbConnection().Database;
        await dirty.Context.Users.ExecuteDeleteAsync();
        Task? shutdown = null;
        try
        {
            var returning = dirty.DisposeAsync().AsTask();
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(10));
            await returning.WaitAsync(TimeSpan.FromSeconds(1));
            await Task.WhenAll(Enumerable.Range(0, 8).Select(_ => dirty.DisposeAsync().AsTask()));
            Assert.Throws<ObjectDisposedException>(() => dirty.Context.Users);

            await using var clean = await fixture.CreateLeaseAsync();
            Assert.NotEqual(dirtyName, clean.Context.Database.GetDbConnection().Database);
            Assert.Equal("background-seed@example.test", (await clean.Context.Users.SingleAsync()).Email);
            using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(10));
            var waiting = fixture.CreateLeaseAsync(cancellationToken: deadline.Token);
            Assert.False(waiting.IsCompleted);
            Assert.Equal(1, fixture.PoolState.ExecutingResets);
            shutdown = fixture.DisposeAsync().AsTask();
            await Assert.ThrowsAsync<ObjectDisposedException>(() => waiting);
            Assert.False(shutdown.IsCompleted);
            release.TrySetResult();
            await shutdown.WaitAsync(TimeSpan.FromSeconds(20));
            Assert.Equal(0, fixture.PoolState.Reserved);
            Assert.Equal(1, resets);
        }
        finally
        {
            release.TrySetResult();
            await dirty.DisposeAsync();
            await (shutdown ?? fixture.DisposeAsync().AsTask());
        }
    }
}
