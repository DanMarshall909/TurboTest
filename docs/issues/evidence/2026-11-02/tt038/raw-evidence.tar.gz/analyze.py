"""Offline recomputation of the fixed TT-038 v4 production-pool experiment."""
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics
import sys

TASK = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
ROOT = TASK / 'v4'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
contract = read(ROOT/'contract.json')
assert sha(ROOT/'contract.json') == read(ROOT/'contract-binding.json')['sha256']
ids = read(ROOT/'runtime-identity.json')
assert ids['awaited'].keys() == ids['background'].keys()
for mode, files in ids.items():
    assert files == {str(p.relative_to(ROOT/('runtime-'+mode))):sha(p)
                     for p in sorted((ROOT/('runtime-'+mode)).rglob('*')) if p.is_file()}
assert [p for p in ids['awaited'] if ids['awaited'][p] != ids['background'][p]] == ['TurboTest.EFCore.dll']
for path, digest in read(ROOT/'source-identity.json').items():
    assert sha(ROOT/'sources'/path) == digest
rows = []
limits = []
owned_containers = set()
owned_volumes = set()
total_resets = 0
initial_inventory = read(ROOT/contract['cases'][0]['name']/'before.json')
def summary(values):
    values = sorted(values)
    return {'count':len(values),'p50':statistics.median(values),
            'p95':values[math.ceil(.95*len(values))-1], 'max':max(values)}

for case in contract['cases']:
    folder = ROOT/case['name']
    report = read(folder/'report.json')
    receipt = read(folder/'process.json')
    assert receipt['exitCode'] == 0 and receipt['processGroupStopped'] and not receipt['deadlineExceeded']
    assert report['Succeeded'] and report['CleanupCompleted'] and report['IsolationChecked']
    assert report['Mode'] == case['mode'] and report['AddedWaitMilliseconds'] == case['waitMilliseconds']
    assert report['ExpectedCycles'] == contract['cycles'] and report['Warmups'] == contract['warmups']
    samples = report['Samples']
    assert sorted(s['Ordinal'] for s in samples) == list(range(contract['cycles']))
    assert len(report['KnownDatabases']) == contract['slots']
    assert len(report['Resets']) == 16 + contract['warmups'] + contract['cycles']
    assert all(r['Succeeded'] and r['Strategy'] == 'Rows' for r in report['Resets'])
    for state in [report['PreflightState'], report['FinalState']]:
        assert state['Ready'] == state['Reserved'] == contract['slots']
        assert all(state[k]==0 for k in ['Leased','Preparing','WaitingResets','ExecutingResets','Quarantined',
                                        'Parked','Retiring','QueuedAcquisitions','Parking','Rewarming','ExecutingCleanup'])
    by_database = {}
    for sample in samples:
        assert sample['Worker'] == sample['Ordinal'] % contract['workers']
        assert sample['Started'] <= sample['Acquired'] <= sample['Returning'] <= sample['Returned']
        assert report['SuiteStartedMilliseconds'] <= sample['Started']
        assert sample['Returned'] <= report['LastTestFinishedMilliseconds'] <= report['FinalResetsFinishedMilliseconds']
        assert report['KnownDatabases'][sample['Database']] == sample['Oid']
        by_database.setdefault(sample['Database'],[]).append(sample)
    for group in by_database.values():
        group.sort(key=lambda s:s['Acquired'])
        assert all(a['Returning'] <= b['Acquired'] for a,b in zip(group,group[1:])), 'Overlapping application use'
    resets = report['Resets'][8+contract['warmups']:8+contract['warmups']+contract['cycles']]
    assert len(resets) == contract['cycles']
    assert all(report['SuiteStartedMilliseconds'] <= r['At'] <= report['FinalResetsFinishedMilliseconds'] for r in resets)
    assert abs(report['SuiteMilliseconds'] - (report['FinalResetsFinishedMilliseconds']-report['SuiteStartedMilliseconds'])) < 1e-5
    resources = read(folder/'resources.json')
    assert len(resources['hosts']) == 1 and not resources['monitorErrors']
    host = resources['hosts'][0]
    assert host['image'] == read(ROOT/'image.json')['Id']
    assert host['id'] not in owned_containers
    owned_containers.add(host['id'])
    volumes = {m['Name'] for m in host['mounts'] if m['Type']=='volume'}
    owned_volumes |= volumes
    before,after = read(folder/'before.json'),read(folder/'after.json')
    assert before == after and read(folder/'settlement.json')['unchanged']
    assert before == initial_inventory, 'Inventory changed between cases'
    assert host['id'] not in after['containers'] and not (volumes & set(after['volumes']))
    limits.append((report['Budget'],host['resources']))
    for state in report['States']:
        assert state['Snapshot']['Reserved'] <= contract['slots']
        assert state['Snapshot']['ExecutingResets'] <= contract['resetConcurrency']
        assert state['Snapshot']['ExecutingCleanup'] <= contract['resetConcurrency']
    row = {**case, 'suiteMilliseconds':report['SuiteMilliseconds'],
           'processWallMilliseconds':receipt['elapsedSeconds']*1000,
           'startupMilliseconds':report['StartupMilliseconds'],
           'preflightMilliseconds':report['PreflightMilliseconds'],
           'finalResetWaitMilliseconds':report['FinalResetWaitMilliseconds'],
           'finalAuditMilliseconds':report['FinalAuditMilliseconds'],
           'disposalMilliseconds':report['DisposalMilliseconds'],
           'throughputPerSecond':contract['cycles']*1000/report['SuiteMilliseconds'],
           'checkoutMilliseconds':[s['Acquired']-s['Started'] for s in samples],
           'returnMilliseconds':[s['Returned']-s['Returning'] for s in samples],
           'bodyMilliseconds':[s['Returning']-s['Acquired'] for s in samples],
           'resetMilliseconds':[r['ExecutionMilliseconds'] for r in resets],
           'resetPermitWaitMilliseconds':[r['PermitWaitMilliseconds'] for r in resets],
           'resetValidationMilliseconds':[r['ValidationMilliseconds'] for r in resets]}
    rows.append(row)
    total_resets += len(report['Resets'])
assert all(x == limits[0] for x in limits)
comparisons = []
for wait in contract['additionalAsyncWaitMilliseconds']:
    pairs=[]
    orders=[]
    for pair in range(contract['pairsPerWait']):
        selected=[r for r in rows if r['pair']==pair and r['waitMilliseconds']==wait]
        assert len(selected)==2 and {r['mode'] for r in selected}=={'awaited','background'}
        orders.append([r['mode'] for r in selected])
        values={r['mode']:r['suiteMilliseconds'] for r in selected}
        pairs.append({'pair':pair,**values,'backgroundOverAwaited':values['background']/values['awaited']})
    assert all(a==b[::-1] for a,b in zip(orders,orders[1:]))
    old=statistics.median(p['awaited'] for p in pairs)
    new=statistics.median(p['background'] for p in pairs)
    # Exact paired bootstrap, ratio of medians, nearest-rank pointwise endpoints.
    bootstrap=[]
    for indices in itertools.product(range(len(pairs)),repeat=len(pairs)):
        bootstrap.append(statistics.median(pairs[i]['background'] for i in indices)/
                         statistics.median(pairs[i]['awaited'] for i in indices))
    bootstrap.sort()
    comparison={'additionalWaitMilliseconds':wait,'pairs':pairs,'awaitedMedianSuiteMilliseconds':old,
        'backgroundMedianSuiteMilliseconds':new,'ratioOfMedians':new/old,'lowerSuiteTimePercent':100*(1-new/old),
        'backgroundWins':sum(p['backgroundOverAwaited']<1 for p in pairs),
        'pairedRatioRange':[min(p['backgroundOverAwaited'] for p in pairs),max(p['backgroundOverAwaited'] for p in pairs)],
        'exactPairedBootstrapPointwise95Interval':[bootstrap[math.ceil(.025*len(bootstrap))-1],bootstrap[math.ceil(.975*len(bootstrap))-1]],
        'bootstrapOrderedResamples':len(bootstrap),'modeSummaries':{}}
    for mode in ['awaited','background']:
        selected=[r for r in rows if r['mode']==mode and r['waitMilliseconds']==wait]
        comparison['modeSummaries'][mode]={key:summary([x for r in selected for x in r[key]])
            for key in ['checkoutMilliseconds','returnMilliseconds','bodyMilliseconds','resetMilliseconds',
                        'resetPermitWaitMilliseconds','resetValidationMilliseconds']}
        for key in ['processWallMilliseconds','startupMilliseconds','preflightMilliseconds','finalResetWaitMilliseconds','finalAuditMilliseconds','disposalMilliseconds','throughputPerSecond']:
            comparison['modeSummaries'][mode][key]=summary([r[key] for r in selected])
    comparisons.append(comparison)
output={'result':'PASS','cases':len(rows),'measuredCycles':len(rows)*contract['cycles'],
        'warmupCycles':len(rows)*contract['warmups'],'allSuccessfulRowsResetsIncludingAudits':total_resets,
        'uniqueOwnedContainers':len(owned_containers),'uniqueOwnedVolumes':len(owned_volumes),
        'allCaseResourceInventoriesUnchanged':True,'equalResourceLimits':limits[0],
        'comparisons':comparisons,'attempts':[{k:v for k,v in r.items() if not isinstance(v,list)} for r in rows],
        'qualifications':['Added waits are synthetic asynchronous waits beyond real DB work, not measured application/CPU work.',
                          'Five pairs on one uncontrolled shared host; intervals are pointwise with no multiplicity adjustment.',
                          'Physical-reset suite endpoint and complete process/host-disposal endpoint are separate.',
                          'Resource observations show equal configured quotas, not measured CPU or peak memory consumption.',
                          'All v3 order-confounded cases and earlier OID qualification failure are retained separately.']}
(TASK/'summary.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'result':'PASS','cases':len(rows),'cycles':len(rows)*contract['cycles'],
    'comparisons':[{k:c[k] for k in ['additionalWaitMilliseconds','awaitedMedianSuiteMilliseconds',
        'backgroundMedianSuiteMilliseconds','lowerSuiteTimePercent','backgroundWins','pairedRatioRange']} for c in comparisons]},indent=2))
