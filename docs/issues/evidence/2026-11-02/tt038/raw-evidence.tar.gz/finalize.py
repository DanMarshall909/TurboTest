"""Retain TT-038 experiment evidence after the fixed run and offline analysis."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

task = Path(__file__).resolve().parent
repo = task.parent.parent
destination = repo/'docs/issues/evidence/2026-11-02/tt038'
destination.mkdir(parents=True,exist_ok=True)
read = lambda p:json.loads(p.read_text())
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary = read(task/'summary.json')
assert summary['result']=='PASS' and summary['cases']==40
receipt=read(task/'v4/measurement.json')
assert receipt['exitCode']==0 and receipt['processGroupStopped'] and not receipt['deadlineExceeded']
owned=set();volumes=set();reports=[]
for path in task.rglob('resources.json'):
    for host in read(path)['hosts']:
        owned.add(host['id'])
        volumes|={m['Name'] for m in host['mounts'] if m['Type']=='volume'}
for path in task.rglob('report.json'):
    d=read(path)
    assert d['CleanupCompleted']
    if (path.parent/'settlement.json').exists():assert read(path.parent/'settlement.json')['unchanged']
    process=read(path.parent/'process.json')
    assert process['processGroupStopped']
    reports.append({'path':str(path.relative_to(task)),'succeeded':d['Succeeded'],
                    'measuredSampleCount':len(d['Samples']),'failures':d['Failures']})
last = read(task/'v4'/read(task/'v4/contract.json')['cases'][-1]['name']/'after.json')
assert not owned & set(last['containers'])
assert not volumes & set(last['volumes'])
validation={'result':'PASS','classification':'one-off experiment, no production or maintained test changes',
            'primaryCases':40,'primaryMeasuredCycles':10240,'primaryWarmupCycles':1280,
            'primarySuccessfulRowsResetsIncludingAudits':summary['allSuccessfulRowsResetsIncludingAudits'],
            'controllerReceipt':receipt,'allAttempts':reports,
            'ownedContainers':sorted(owned),'ownedVolumes':sorted(volumes),
            'ownedResourcesAbsentAtEnd':True,
            'qualification':'Two16-cycle smokes plus two intentional WorkloadDistribution controls; exact v3/v4 native runtime hashes match.',
            'retainedNonPrimary':'One OID-mapping harness setup failure; eight v3 order-confounded cases (2048 cycles) stopped cleanly at the next source admission.',
            'coverageMutation':'No new production behavior or maintained code. Existing 554-test source-identical correctness/pack gates passed; this experiment claims native qualification and offline analysis, not new maintained-suite coverage or mutation.'}
(task/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
for name in ['summary.json','validation.json']:
    shutil.copyfile(task/name,destination/name)

# Reusable frozen runtimes, exact sources, raw reports/logs/receipts and failed
# attempts are retained. Generated build caches are redundant with the runtimes.
files=[]
for p in sorted(task.rglob('*')):
    if not p.is_file():continue
    relative=p.relative_to(task)
    if '__pycache__' in relative.parts:continue
    if relative.parts[:2] in [('harness','obj'),('harness','bin')]:continue
    files.append(p)
manifest={str(p.relative_to(task)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files}
(destination/'raw-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
archive=destination/'raw-evidence.tar.gz'
canonical={}
duplicates=0
with tarfile.open(archive,'w:gz',compresslevel=6) as output:
    for path in files:
        name=str(path.relative_to(task))
        key=(manifest[name]['sha256'],manifest[name]['bytes'])
        if key in canonical:
            # Content-identical frozen files share bytes inside the archive.
            # Source/runtime files on disk remain independent, unchanged files.
            entry=output.gettarinfo(str(path),arcname=name)
            entry.type=tarfile.LNKTYPE;entry.linkname=canonical[key];entry.size=0
            output.addfile(entry);duplicates+=1
        else:
            output.add(path,arcname=name,recursive=False);canonical[key]=name
with tarfile.open(archive,'r:gz') as source:
    members=source.getmembers()
    assert len(members)==len(manifest)
    for member in members:
        data=source.extractfile(member).read()
        assert len(data)==manifest[member.name]['bytes']
        assert hashlib.sha256(data).hexdigest()==manifest[member.name]['sha256']
metadata={'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),
          'contentIdenticalArchiveHardlinks':duplicates,
          'allMembersRehashedAfterArchiving':True,'excluded':'Redundant harness/bin and harness/obj build caches, Python __pycache__ only; frozen runtime versions are included.'}
(destination/'archive.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({'archive':metadata,'allAttempts':len(reports),'ownedContainers':len(owned),'ownedVolumes':len(volumes)},indent=2))
