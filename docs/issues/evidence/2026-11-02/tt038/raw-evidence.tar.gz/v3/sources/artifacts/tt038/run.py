"""One-off source-bound TT-038 production pool comparison; not a maintained runner."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time

TASK = Path(__file__).resolve().parent
ROOT = TASK / 'v3'
REPO = TASK.parent.parent
sys.path.insert(0, str(REPO))
from scripts import verify

ENV = dict(os.environ, DOCKER_HOST='unix:///var/run/docker.sock')
DOCKER = ['docker', '--host', ENV['DOCKER_HOST']]

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def identity(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}

def docker(*args):
    return subprocess.check_output(DOCKER + list(args), text=True, timeout=15)

def inventory():
    return {'containers': sorted(docker('ps', '--all', '--no-trunc', '--format', '{{.ID}}').splitlines()),
            'volumes': sorted(docker('volume', 'ls', '--format', '{{.Name}}').splitlines())}

def prepare():
    ROOT.mkdir()
    build = ROOT / 'build'
    build.mkdir()
    verify.run_phase('build', ['dotnet', 'build', str(TASK/'harness/PoolScreen.csproj'), '--no-restore',
        '-c', 'Release', '-nr:false', '-p:UseSharedCompilation=false'], build, 180, ENV)
    for mode, previous in [('awaited', 'baseline'), ('background', 'candidate')]:
        destination = ROOT / ('runtime-' + mode)
        shutil.copytree(TASK/'harness/bin/Release/net10.0', destination)
        (destination/'TurboTest.EFCore.pdb').unlink(missing_ok=True)
        source = REPO / f'artifacts/tt037/runtime-{previous}/TurboTest.EFCore.dll'
        receipt_path = REPO / f'artifacts/tt037/measurement/runtime-identity.json'
        assert digest(source) == json.loads(receipt_path.read_text())[previous]['TurboTest.EFCore.dll']
        shutil.copyfile(source, destination/'TurboTest.EFCore.dll')
    ids = {mode: identity(ROOT/('runtime-'+mode)) for mode in ['awaited', 'background']}
    difference = [name for name in ids['awaited'] if ids['awaited'][name] != ids['background'][name]]
    assert difference == ['TurboTest.EFCore.dll'], difference
    verify.write_json(ROOT/'runtime-identity.json', ids)
    sources = ['artifacts/tt038/harness/Program.cs', 'artifacts/tt038/harness/PoolScreen.csproj',
               'artifacts/tt038/run.py', 'benchmarks/TurboTest.Benchmarks/BenchmarkWorkload.cs',
               'benchmarks/TurboTest.Benchmarks/WorkloadMix.cs', 'scripts/verify.py', 'global.json', 'Directory.Build.props']
    snapshots = ROOT/'sources'; snapshots.mkdir()
    for path in sources:
        target = snapshots/path; target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO/path, target)
    verify.write_json(ROOT/'source-identity.json', {path: digest(REPO/path) for path in sources})
    verify.write_json(ROOT/'image.json', json.loads(docker('image', 'inspect', 'postgres:16-alpine'))[0])
    print('Prepared immutable common harness; only TurboTest.EFCore.dll differs', flush=True)

def run_case(name, mode, delay, cycles, warmups, fault=None):
    out = ROOT/name; out.mkdir()
    expected = json.loads((ROOT/'runtime-identity.json').read_text())
    assert identity(ROOT/('runtime-'+mode)) == expected[mode]
    for path, value in json.loads((ROOT/'source-identity.json').read_text()).items():
        assert digest(REPO/path) == value, path
    before = inventory()
    verify.write_json(out/'before.json', before)
    image_id = json.loads(docker('image', 'inspect', 'postgres:16-alpine'))[0]['Id']
    assert image_id == json.loads((ROOT/'image.json').read_text())['Id']
    verify.write_json(out/'host.json', {'loadAverage': os.getloadavg(), 'logicalCpuCount': os.cpu_count()})
    stopped = threading.Event(); observations = []; monitor_errors = []
    def monitor():
        known = set()
        while not stopped.wait(.5):
            try:
                progress = out/'progress.json'
                if not progress.exists(): continue
                prefix = json.loads(progress.read_text())['Prefix']
                ids = docker('ps', '--all', '--filter', 'name='+prefix, '--format', '{{.ID}}').splitlines()
                for cid in ids:
                    if cid in known: continue
                    data = json.loads(docker('inspect', cid))[0]
                    host = data['HostConfig']
                    observations.append({'id': data['Id'], 'name': data['Name'], 'image': data['Image'],
                        'mounts': [{k:m.get(k) for k in ['Type','Name','Destination']} for m in data['Mounts']],
                        'resources': {k:host.get(k) for k in ['Memory','MemorySwap','NanoCpus','CpuQuota','CpuPeriod','CpuShares','NetworkMode']}})
                    known.add(cid)
            except Exception as error:
                monitor_errors.append(type(error).__name__+': '+str(error))
    thread = threading.Thread(target=monitor); thread.start()
    failed = None
    try:
        command = ['dotnet', str(ROOT/('runtime-'+mode)/'PoolScreen.dll'), str(out), mode, str(delay), str(cycles), str(warmups)]
        if fault: command.append(fault)
        verify.run_phase('process', command, out, 300, ENV)
    except verify.VerificationError as error:
        failed = str(error)
    finally:
        stopped.set(); thread.join(timeout=20)
        assert not thread.is_alive(), 'MonitorWorkers'
        after = inventory()
        verify.write_json(out/'after.json', after)
        verify.write_json(out/'resources.json', {'hosts': observations, 'monitorErrors': monitor_errors})
        verify.write_json(out/'settlement.json', {'unchanged': before == after})
        assert before == after, 'ResourceSettlement'
        assert identity(ROOT/('runtime-'+mode)) == expected[mode]
    result = json.loads((out/'report.json').read_text())
    if fault:
        assert failed and not result['Succeeded'] and result['CleanupCompleted'], result
        assert any('WorkloadDistribution' in error for error in result['Failures']), result['Failures']
    else:
        assert failed is None, failed
        assert result['Succeeded'] and result['CleanupCompleted'] and result['IsolationChecked']
        assert len(result['Samples']) == cycles
        assert len(result['Resets']) == 8 + warmups + cycles + 8
        assert len(result['KnownDatabases']) == 8
        assert all(r['Succeeded'] and r['Strategy'] == 'Rows' for r in result['Resets'])
    assert len(observations) == 1, observations
    assert observations[0]['image'] == image_id
    limits = observations[0]['resources']
    assert limits['Memory'] == 1024*1024*1024
    print(name, 'PASS' if not fault else 'EXPECTED FAULT', 'suiteMs', round(result['SuiteMilliseconds'], 2), flush=True)
    return result

if __name__ == '__main__':
    os.chdir(REPO)
    if sys.argv[1] == 'prepare': prepare()
    elif sys.argv[1] == 'qualify':
        for mode in ['awaited', 'background']:
            run_case('smoke-'+mode, mode, 0, 16, 8)
            run_case('fault-'+mode, mode, 0, 8, 4, 'distribution')
    elif sys.argv[1] == 'measure':
        contract = json.loads((ROOT/'contract.json').read_text())
        for case in contract['cases']:
            run_case(case['name'], case['mode'], case['waitMilliseconds'], contract['cycles'], contract['warmups'])
