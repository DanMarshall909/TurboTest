"""One-off retention of the frozen TT-039 revision-2 attempt and diagnostics."""
from pathlib import Path
import datetime,gzip,hashlib,json,shutil,tarfile
root=Path('artifacts/tt039-r2');out=Path('docs/issues/evidence/2026-11-03/tt039-r2')
archive=out/'raw-evidence.tar.gz';assert not archive.exists()
files=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 relative=p.relative_to(root)
 if relative.parts[0]=='runtime' or '__pycache__' in relative.parts or p.suffix in {'.dll','.pdb','.so','.pyc'}:continue
 files.append((p,relative.as_posix()))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identities={name:sha(path) for path,name in files}
with archive.open('xb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
  with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for path,name in files:
    info=tar.gettarinfo(str(path),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with path.open('rb') as payload:tar.addfile(info,payload)
contract=json.loads((root/'contract.json').read_text())
inputs=['contract.json','source-identity.json','runtime-identity.json','image.json','fit.json','forecast.json','evaluation.json']
inputs += [r['name']+'/'+n for r in contract['cases'] for n in ['report.json','process.json']]
manifest=dict(createdAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 sourceFreeze='d19174075ad4a657f70ec3864fb4f88cf49c38a1',forecastFreeze='24adde27293f5e2d217ec399fff6922865f935a9',
 qualification='FAIL; no policy search',archiveSha256=sha(archive),files=identities,modelInputs=sorted(inputs),
 exclusions=['compiled runtime DLLs/PDBs retained locally with identities; reusable dependencies and caches',
  'Python bytecode caches; post-export verification output is retained separately'])
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
for name in ['evaluation.json','forecast.json','cleanup.json','final-fast.json']:
 shutil.copyfile(root/name,out/name)
shutil.copyfile(root/'final-fast.log',out/'final-fast.log.txt')
print('Archived files:',len(files),'bytes:',archive.stat().st_size,'model input files:',len(inputs))
