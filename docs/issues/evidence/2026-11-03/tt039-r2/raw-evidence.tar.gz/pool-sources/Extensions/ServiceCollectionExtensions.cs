using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.DependencyInjection.Extensions;
using TurboTest.EFCore.Internal;

namespace TurboTest.EFCore.Extensions;

/// <summary>
/// Extension methods for IServiceCollection to register TurboTest services
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>Initializes this scope's leased context before synchronous service resolution.</summary>
    public static Task InitializeTurboTestAsync<TContext>(this IServiceProvider services,
        CancellationToken cancellationToken = default) where TContext : DbContext
    {
        cancellationToken.ThrowIfCancellationRequested();
        return services.GetRequiredService<TtScopedLease<TContext>>().InitializeAsync().WaitAsync(cancellationToken);
    }

    /// <summary>
    /// Adds TurboTest services to the DI container.
    /// Uses familiar ASP.NET Core patterns for configuration.
    /// </summary>
    /// <param name="services">The service collection</param>
    /// <param name="configuration">Configuration instance (optional)</param>
    /// <returns>Service collection for chaining</returns>
    public static IServiceCollection AddTurboTest(
        this IServiceCollection services,
        IConfiguration? configuration = null)
    {
        // Configure options from configuration section if provided
        if (configuration != null)
        {
            services.Configure<TtOptions>(configuration.GetSection(TtOptions.SectionName));
        }
        else
        {
            services.Configure<TtOptions>(_ => { });
        }

        // Register the service factory
        services.TryAddSingleton<ITtServiceFactory, TtServiceFactory>();

        return services;
    }

    /// <summary>
    /// Adds TurboTest services with explicit configuration.
    /// </summary>
    /// <param name="services">The service collection</param>
    /// <param name="configure">Configuration action</param>
    /// <returns>Service collection for chaining</returns>
    public static IServiceCollection AddTurboTest(
        this IServiceCollection services,
        Action<TtOptions> configure)
    {
        services.Configure(configure);
        services.TryAddSingleton<ITtServiceFactory, TtServiceFactory>();
        return services;
    }

    /// <summary>
    /// Registers a TtLease of the context type for testing.
    /// Await InitializeTurboTestAsync in a CreateAsyncScope before resolving the lease.
    /// Dispose the scope and provider asynchronously to await return and drain.
    /// </summary>
    /// <typeparam name="TContext">The DbContext type</typeparam>
    /// <param name="services">The service collection</param>
    /// <param name="configure">Optional context configuration</param>
    /// <returns>Service collection for chaining</returns>
    public static IServiceCollection AddTurboTestDbContext<TContext>(
        this IServiceCollection services,
        Action<DbContextOptionsBuilder>? configure = null)
        where TContext : DbContext
    {
        // Ensure TurboTest is registered
        if (!services.Any(s => s.ServiceType == typeof(ITtServiceFactory)))
        {
            services.AddTurboTest();
        }

        services.AddScoped(provider => new TtScopedLease<TContext>(
            provider.GetRequiredService<ITtServiceFactory>(), configure));
        services.AddScoped(provider => provider.GetRequiredService<TtScopedLease<TContext>>().Lease);

        return services;
    }
}
