"""Post-result semantic diagnostic; uses observed services, never qualifies predictions."""
from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,'benchmarks/scheduler-simulator')
from revised import read_trace
from model import Work,simulate
import statistics
root=Path('artifacts/tt039-r2');contract=json.loads((root/'contract.json').read_text())
settings={k:contract[k] for k in ('slots','workers','resetConcurrency','cycles')}
rows=[]
for case in contract['cases']:
 path=root/case['name']/'report.json';report=json.loads(path.read_text());trace=read_trace(report,settings)
 jobs=[]
 for ordinal in range(settings['cycles']):
  worker=ordinal%settings['workers'];values=trace['workers'][worker][ordinal//settings['workers']].copy()
  if ordinal<settings['workers']:values['dispatch_us']=trace['initial_us'][worker]
  jobs.append(Work(**values))
 replay=simulate(jobs,mode=case['mode'],slots=settings['slots'],workers=settings['workers'],reset_workers=settings['resetConcurrency'])
 predicted=replay['suite_us']/1000;observed=report['SuiteMilliseconds']
 rows.append(case|dict(observedSuiteMilliseconds=observed,replayedSuiteMilliseconds=predicted,
  signedRelativeError=predicted/observed-1,observedCleanStarvation=trace['observed']['clean_starvation'],
  replayedCleanStarvation=statistics.mean(t['queued_clean'] for t in replay['tests']),
  cleanStarvationDifference=statistics.mean(t['queued_clean'] for t in replay['tests'])-trace['observed']['clean_starvation'],reportSha256=hashlib.sha256(path.read_bytes()).hexdigest()))
result=dict(classification='Post-hoc observed-service replay, including validation services. Not a forecast or qualification gate.',
 sourceSha256={name:hashlib.sha256(Path('benchmarks/scheduler-simulator',name).read_bytes()).hexdigest() for name in ('revised.py','model.py')},
 rows=rows,maxAbsoluteRelativeError=max(abs(r['signedRelativeError']) for r in rows))
(root/'replay-diagnostic.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('Post-hoc observed-service replay maximum absolute suite error:',result['maxAbsoluteRelativeError'])
