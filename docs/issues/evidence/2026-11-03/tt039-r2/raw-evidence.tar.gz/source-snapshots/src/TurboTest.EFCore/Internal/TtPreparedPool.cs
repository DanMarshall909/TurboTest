using System.Security.Cryptography;
using System.Transactions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Npgsql;
using Microsoft.Extensions.Logging;

namespace TurboTest.EFCore.Internal;

/// <summary>One fixture host, one sealed baseline, and independently owned workload databases.</summary>
internal sealed class TtPreparedPool<TContext> : ITtDatabasePool where TContext : DbContext
{
    private sealed class Slot(string name, NpgsqlDataSource source)
    {
        internal string Name { get; } = name;
        internal NpgsqlDataSource Source { get; set; } = source;
        internal uint? DatabaseOid { get; set; }
    }
    private sealed record BaselineIdentity(Guid Owner, Type ContextType, TtSchemaInitialization Schema,
        string InitializerVersion, DbContextOptions<TContext> Configuration, Microsoft.EntityFrameworkCore.Metadata.IModel Model);

    private sealed class Login
    {
        private readonly string _password;
        internal string Name { get; }

        internal Login(string name, string password)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(name);
            ArgumentException.ThrowIfNullOrEmpty(password);
            Name = name;
            _password = password;
        }

        internal void ApplyTo(NpgsqlConnectionStringBuilder builder)
        {
            builder.Username = Name;
            builder.Password = _password;
        }

        internal async Task CreateWorkloadRoleAsync(NpgsqlConnection connection, CancellationToken cancellationToken)
        {
            // Server formatting quotes both parameters; never log the resulting SQL.
            await using var format = new NpgsqlCommand(
                "SELECT format('CREATE ROLE %I LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS PASSWORD %L', $1, $2)", connection);
            format.Parameters.Add(new NpgsqlParameter { Value = Name });
            format.Parameters.Add(new NpgsqlParameter { Value = _password });
            var sql = (string)(await format.ExecuteScalarAsync(cancellationToken))!;
            await using var role = new NpgsqlCommand(sql, connection);
            await role.ExecuteNonQueryAsync(cancellationToken);
        }
    }

    private readonly TtOptions _options;
    private readonly ILogger _logger;
    private readonly TimeProvider _clock;
    private readonly TtTelemetry _telemetry;
    private readonly TtBaselineDefinition<TContext> _definition;
    private readonly TtPool _host;
    private readonly Func<NpgsqlDataSource, Task>? _beforeVerification;
    private readonly Func<NpgsqlConnection, NpgsqlTransaction, Task>? _afterSequenceRestore;
    private readonly Func<NpgsqlConnection, Task>? _afterRowCommit;
    private readonly Func<NpgsqlConnection, string, Task>? _dropDatabase;
    private readonly Guid _owner = Guid.NewGuid();
    private readonly string _template;
    private readonly Login _workload;
    private readonly Login _adminLogin;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly TtSlotPool<Slot> _slots;
    private readonly TtAdaptiveConfiguration? _adaptive;
    private readonly TtCapacityMonitor? _monitor;
    private readonly TtAdministratorConnections _administrators;
    private readonly object _lifecycleGate = new();
    private readonly TtBackgroundReturns _returns = new();
    private NpgsqlDataSource? _administrator;
    private BaselineIdentity? _identity;
    private TtBaselineSnapshot? _snapshot;
    private TtBaselineSnapshot? _schemaSnapshot;
    private TtRowResetPlan? _rowReset;
    private Task? _disposal;
    private bool _stopping;

    public IReadOnlyList<string> OwnedResourceIds => _host.OwnedResourceIds;
    public TtResourceBudget Budget { get; }
    public TtPoolSnapshot Snapshot
    {
        get
        {
            var administrators = _administrators.Snapshot;
            return _slots.Snapshot with
            {
                ExecutingAdministratorConnections = administrators.Active,
                WaitingAdministratorConnections = administrators.Waiting
            };
        }
    }

    internal TtPreparedPool(TtOptions options, TtBaselineDefinition<TContext> definition,
        Func<NpgsqlDataSource, Task>? beforeVerification = null, Func<TtContainer, Task>? deleteHost = null,
        Func<string, Task>? prepareImage = null,
        Func<NpgsqlConnection, NpgsqlTransaction, Task>? afterSequenceRestore = null,
        Func<NpgsqlConnection, Task>? afterRowCommit = null,
        Func<NpgsqlConnection, string, Task>? dropDatabase = null, TimeProvider? timeProvider = null)
    {
        options = options.Snapshot();
        _clock = timeProvider ?? TimeProvider.System;
        TtPreparedConfiguration.Validate(options);
        _adaptive = TtAdaptiveConfiguration.Capture(options);
        Budget = TtResourceBudget.Create(options, prepared: true);
        ArgumentNullException.ThrowIfNull(definition);
        _options = options;
        _logger = new TtLogger(options.Logger ?? Microsoft.Extensions.Logging.Abstractions.NullLogger.Instance, options.LogLevel);
        _telemetry = new TtTelemetry(options.Logger, options.LogLevel, () => Snapshot, _clock);
        _definition = definition;
        _template = $"{options.DatabaseName}_baseline_{_owner:N}";
        _beforeVerification = beforeVerification;
        _afterSequenceRestore = afterSequenceRestore;
        _afterRowCommit = afterRowCommit;
        _dropDatabase = dropDatabase;
        _workload = new Login(options.Username ?? $"tt_workload_{Guid.NewGuid():N}",
            options.Password ?? Convert.ToHexString(RandomNumberGenerator.GetBytes(32)));
        var hostOptions = options.Snapshot();
        hostOptions.PoolSize = 1;
        hostOptions.AutoAllocateResources = false;
        hostOptions.EnableDynamicScaling = false;
        hostOptions.Username = $"tt_admin_{Guid.NewGuid():N}";
        hostOptions.Password = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
        _adminLogin = new Login(hostOptions.Username, hostOptions.Password);
        hostOptions.DatabaseName = "tt_control";
        hostOptions.ConnectionStringTemplate = null;
        _host = new TtPool(hostOptions, deleteHost, prepareImage, administratorHost: true);
        _administrators = new TtAdministratorConnections(options.MaxAdministratorConnections, CreateAdministratorConnection);
        _slots = new TtSlotPool<Slot>(options.PoolSize, options.PreparationConcurrency, ReserveSlot,
            (slot, token) => PrepareSlotAsync(slot, token), DeleteSlotAsync, options.ResetConcurrency, RewarmSlotAsync, timeProvider,
            options.Logger, options.LogLevel, _adaptive is null ? null : new TtCapacityPolicy(_adaptive, _clock));
        if (_adaptive is not null)
            _monitor = new TtCapacityMonitor(_adaptive.CheckInterval, _clock,
                token => _host.ReadOwnedHostMemoryAsync(_clock, token),
                memory => _slots.TickCapacityAsync(memory, ParkSlotAsync, _options.WarmFloor,
                    _options.MaxParkedDatabases, _options.IdleDatabaseLifetime));
    }

    internal async Task InitializeAsync(CancellationToken cancellationToken)
    {
        using var privateWork = new TransactionScope(TransactionScopeOption.Suppress, TransactionScopeAsyncFlowOption.Enabled);
        cancellationToken.ThrowIfCancellationRequested();
        await _host.InitializeAsync(cancellationToken);
        _administrator = (await _host.GetDatabaseAsync()).DataSource;
        await using (var administrative = await OpenAdministratorAsync(cancellationToken: cancellationToken))
        {
            var connection = administrative.Connection;
            await _workload.CreateWorkloadRoleAsync(connection, cancellationToken);
            await using var create = new NpgsqlCommand(
                $"CREATE DATABASE {Quote(_template)} OWNER {Quote(_workload.Name)} TEMPLATE template0", connection);
            await create.ExecuteNonQueryAsync(cancellationToken);
        }

        await using (var source = CreateWorkloadSource(_template))
        {
            var builder = new DbContextOptionsBuilder<TContext>().UseNpgsql(source);
            if (_options.EnableSensitiveDataLogging) builder.EnableSensitiveDataLogging();
            _definition.ConfigureContext?.Invoke(builder);
            await using var context = (TContext)(Activator.CreateInstance(typeof(TContext), builder.Options)
                ?? throw new InvalidOperationException("Could not construct the baseline context."));
            var configuration = OwnedOptions(context, source, "BaselineConfiguration");
            _identity = new BaselineIdentity(_owner, typeof(TContext), _definition.Schema, _definition.Identity,
                new DbContextOptionsBuilder<TContext>(configuration).UseModel(context.Model).Options, context.Model);
            if (_definition.Schema != TtSchemaInitialization.Caller &&
                !ModelColumns(context.Model).SequenceEqual(ModelColumns(
                    context.GetService<Microsoft.EntityFrameworkCore.Metadata.IDesignTimeModel>().Model)))
                throw new TtLifecycleException("BaselineConfiguration",
                    new InvalidOperationException("The runtime and schema models must have matching table and column mappings."));
            switch (_definition.Schema)
            {
                case TtSchemaInitialization.EnsureCreated:
                    await context.Database.EnsureCreatedAsync(cancellationToken);
                    break;
                case TtSchemaInitialization.Migrations:
                    await context.Database.MigrateAsync(cancellationToken);
                    break;
                case TtSchemaInitialization.Caller:
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(_definition.Schema));
            }
            if (_definition.SeedAsync is not null)
                await _definition.SeedAsync(context, cancellationToken);
        }

        // Disposal above drains every initialization connection before cloning.
        await using (var administrative = await OpenAdministratorAsync(cancellationToken: cancellationToken))
        {
            var connection = administrative.Connection;
            await connection.ExecuteNonQueryAsync(
                $"ALTER DATABASE {Quote(_template)} OWNER TO {Quote(connection.UserName!)}");
        }
        await using (var administrative = await OpenAdministratorAsync(_template, cancellationToken))
        {
            var connection = administrative.Connection;
            _snapshot = await TtBaselineSnapshot.CaptureAsync(connection, cancellationToken);
            _schemaSnapshot = _snapshot.Schema;
            _rowReset = await TtRowResetPlan.CaptureAsync(connection, cancellationToken);
        }
        await using (var administrative = await OpenAdministratorAsync(cancellationToken: cancellationToken))
            await administrative.Connection.ExecuteNonQueryAsync($"ALTER DATABASE {Quote(_template)} ALLOW_CONNECTIONS false");
        await _slots.WarmAsync(_adaptive?.Startup ?? _options.StartupWarmDatabases ?? _options.PoolSize, cancellationToken);
        cancellationToken.ThrowIfCancellationRequested();
        lock (_lifecycleGate)
        {
            ObjectDisposedException.ThrowIf(_stopping, this);
            _monitor?.Start();
        }
    }

    internal DbContextOptions<TContext> BuildOptions(NpgsqlDataSource source) =>
        new DbContextOptionsBuilder<TContext>(_identity!.Configuration).UseNpgsql(source).Options;

    internal void ValidateContext(TContext context, NpgsqlDataSource source)
    {
        OwnedOptions(context, source, "ContextConfiguration");
        if (!ReferenceEquals(context.Model, _identity!.Model))
            throw new TtLifecycleException("ContextConfiguration",
                new InvalidOperationException("The context must use its frozen fixture model."));
    }

    private static DbContextOptions<TContext> OwnedOptions(TContext context, NpgsqlDataSource source, string stage)
        => TtOwnedContextOptions.Read(context, source, stage);

    private static IEnumerable<(string Schema, string Table, string Column, string Type, bool Nullable)> ModelColumns(
        Microsoft.EntityFrameworkCore.Metadata.IModel model) => model.GetRelationalModel().Tables
        .SelectMany(table => table.Columns.Select(column =>
            (Schema: table.Schema ?? "public", Table: table.Name, Column: column.Name, Type: column.StoreType, Nullable: column.IsNullable)))
        .OrderBy(column => column.Schema, StringComparer.Ordinal)
        .ThenBy(column => column.Table, StringComparer.Ordinal)
        .ThenBy(column => column.Column, StringComparer.Ordinal)
        .ThenBy(column => column.Type, StringComparer.Ordinal)
        .ThenBy(column => column.Nullable);

    public async Task<TtDatabase> GetDatabaseAsync(CancellationToken cancellationToken = default)
    {
        var reservation = await _slots.AcquireAsync(cancellationToken);
        return new TtDatabase(reservation.Value.Source, () =>
        {
            _returns.Start(() => ReturnAsync(reservation));
            return Task.CompletedTask;
        }, () => _slots.DiscardAsync(reservation));
    }

    public Task MaintainIdleAsync(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Cancellation ends only caller observation. Every claimed closure is
        // retained by the slot ledger's settlement task until it actually ends.
        return _slots.ParkIdleAsync(_options.WarmFloor,
                ParkSlotAsync,
                _options.MaxParkedDatabases, _options.IdleDatabaseLifetime)
            .WaitAsync(cancellationToken);
    }

    private Task ParkSlotAsync(Slot slot, CancellationToken _) =>
        MeasureLifecycleAsync("Park", () => slot.Source.DisposeAsync().AsTask());

    public void StopAcceptingWork()
    {
        lock (_lifecycleGate)
        {
            _stopping = true;
            _slots.StopAcceptingWork();
            _monitor?.Stop();
        }
    }

    private Slot ReserveSlot(Guid _)
    {
        var name = $"{_options.DatabaseName}_slot_{Guid.NewGuid():N}";
        return new Slot(name, CreateWorkloadSource(name));
    }

    private async Task PrepareSlotAsync(Slot slot, CancellationToken cancellationToken, Action<TimeSpan>? observeValidation = null)
    {
        try
        {
            await using (var administrative = await OpenAdministratorAsync(cancellationToken: cancellationToken))
                await administrative.Connection.ExecuteNonQueryAsync(
                    $"CREATE DATABASE {Quote(slot.Name)} TEMPLATE {Quote(_template)} OWNER {Quote(_workload.Name)}");
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception error) { throw new TtLifecycleException("BaselineClone", error); }
        await VerifySlotAsync(slot, cancellationToken, observeValidation);
    }

    private Task RewarmSlotAsync(Slot slot, CancellationToken cancellationToken) =>
        MeasureLifecycleAsync("Rewarm", () => RewarmSlotCoreAsync(slot, cancellationToken));

    private async Task RewarmSlotCoreAsync(Slot slot, CancellationToken cancellationToken)
    {
        using var privateWork = new TransactionScope(TransactionScopeOption.Suppress, TransactionScopeAsyncFlowOption.Enabled);
        slot.Source = CreateWorkloadSource(slot.Name);
        await VerifySlotAsync(slot, cancellationToken, rewarming: true);
    }

    private async Task VerifySlotAsync(Slot slot, CancellationToken cancellationToken,
        Action<TimeSpan>? observeValidation = null, bool rewarming = false)
    {
        var stage = rewarming ? "BaselineRewarmOpen" : "BaselineClone";
        try
        {
            if (_beforeVerification is not null) await _beforeVerification(slot.Source);
            stage = rewarming ? "BaselineRewarmVerify" : "BaselineVerify";
            var validation = _clock.GetTimestamp();
            var validationOutcome = "Succeeded";
            try
            {
                await using var probe = await OpenAdministratorAsync(slot.Name, cancellationToken);
                _snapshot!.Verify(await TtBaselineSnapshot.CaptureAsync(probe.Connection, cancellationToken));
                await using (var identity = new NpgsqlCommand("SELECT oid FROM pg_database WHERE datname = $1", probe.Connection))
                {
                    identity.Parameters.Add(new NpgsqlParameter { Value = slot.Name });
                    var oid = (uint)(await identity.ExecuteScalarAsync(cancellationToken))!;
                    if (rewarming)
                    {
                        stage = "BaselineRewarmIdentity";
                        if (slot.DatabaseOid != oid)
                            throw new InvalidOperationException("The retained database identity has changed.");
                    }
                    else slot.DatabaseOid = oid;
                }
                stage = rewarming ? "BaselineRewarmWorkloadVerify" : "BaselineWorkloadVerify";
                await VerifyWorkloadAsync(slot);
            }
            catch (Exception error) { validationOutcome = TtTelemetry.Outcome(error); throw; }
            finally
            {
                var duration = _clock.GetElapsedTime(validation);
                observeValidation?.Invoke(duration);
                _telemetry.Record(rewarming ? "RewarmValidation" : "PreparationValidation", duration, validationOutcome);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception error)
        {
            throw new TtLifecycleException(stage, error);
        }
    }

    private NpgsqlDataSource CreateWorkloadSource(string database)
    {
        var builder = new NpgsqlConnectionStringBuilder(_administrator!.ConnectionString)
        {
            Database = database,
            IncludeErrorDetail = false,
            Pooling = true,
            Enlist = true,
            MinPoolSize = 0,
            MaxPoolSize = _options.MaxConnectionsPerDatabase
        };
        _workload.ApplyTo(builder);
        return NpgsqlDataSource.Create(builder.ConnectionString);
    }

    private async Task VerifyWorkloadAsync(Slot slot)
    {
        using var privateWork = new TransactionScope(TransactionScopeOption.Suppress, TransactionScopeAsyncFlowOption.Enabled);
        await using var workload = await slot.Source.OpenConnectionAsync();
        await using var identity = new NpgsqlCommand("SELECT current_database(), current_user", workload);
        await using var reader = await identity.ExecuteReaderAsync();
        if (!await reader.ReadAsync() || reader.GetString(0) != slot.Name || reader.GetString(1) != _workload.Name)
            throw new InvalidOperationException("The workload connection does not match its owned slot.");
    }

    private Task<TtAdministratorConnections.Lease> OpenAdministratorAsync(string? database = null,
        CancellationToken cancellationToken = default) => _administrators.OpenAsync(database, cancellationToken);

    private NpgsqlConnection CreateAdministratorConnection(string? database)
    {
        var builder = new NpgsqlConnectionStringBuilder(_administrator!.ConnectionString)
        {
            Pooling = false,
            Enlist = false
        };
        if (database is not null) builder.Database = database;
        _adminLogin.ApplyTo(builder);
        return new NpgsqlConnection(builder.ConnectionString);
    }

    private async Task ReturnAsync(TtSlotPool<Slot>.Reservation reservation)
    {
        var execution = TimeSpan.Zero;
        var wait = TimeSpan.Zero;
        var validation = TimeSpan.Zero;
        var recreationValidation = TimeSpan.Zero;
        var strategy = "Skipped";
        var succeeded = false;
        void ObserveValidation(TimeSpan duration) => validation += duration;
        try
        {
            await _slots.ReturnAsync(reservation, async (slot, _) =>
            {
                var executing = _clock.GetTimestamp();
                strategy = "Rows";
                var validationOutcome = "Succeeded";
                try
                {
                    var reusable = await TryResetRowsAsync(slot, ObserveValidation);
                    if (!reusable) { strategy = "Recreate"; validationOutcome = "Incompatible"; }
                    return reusable;
                }
                catch (Exception error)
                {
                    validationOutcome = TtTelemetry.Outcome(error);
                    throw new TtLifecycleException("BaselineRowReset", error);
                }
                finally
                {
                    execution = _clock.GetElapsedTime(executing);
                    _telemetry.Record("ResetValidation", validation, validationOutcome);
                }
            }, duration => wait = duration,
                (slot, token) => PrepareSlotAsync(slot, token, duration => recreationValidation += duration),
                backgroundReturn: true, stopOnFailure: _options.ResetFailurePolicy == TtResetFailurePolicy.StopFixture);
            succeeded = true;
        }
        finally
        {
            try
            {
                _logger.LogDebug(new EventId(400, "BaselineReset"),
                    "Baseline reset {OwnerId} {Strategy}: wait {ResetPermitWaitMilliseconds} ms, execution {ResetExecutionMilliseconds} ms, validation {ValidationMilliseconds} ms, recreation validation {RecreationValidationMilliseconds} ms, success {Succeeded}",
                    Snapshot.OwnerId, strategy, wait.TotalMilliseconds,
                    execution.TotalMilliseconds, validation.TotalMilliseconds, recreationValidation.TotalMilliseconds, succeeded);
            }
            catch (Exception) { /* Diagnostic consumers cannot replace the reset result. */ }
        }
    }

    private async Task<bool> TryResetRowsAsync(Slot slot, Action<TimeSpan> observeValidation)
    {
        if (_rowReset is null) return false;
        slot.Source.Clear();
        await using (var administrative = await OpenAdministratorAsync(slot.Name))
        {
            var connection = administrative.Connection;
            var validation = _clock.GetTimestamp();
            try { _schemaSnapshot!.Verify(await TtBaselineSnapshot.CaptureSchemaAsync(connection)); }
            catch (TtLifecycleException error) when (error.Stage is "BaselineVerify" or "BaselineUnsupportedCatalog")
            {
                // Changed/unsupported catalog requires whole-template recreation.
                return false;
            }
            finally { observeValidation(_clock.GetElapsedTime(validation)); }
            await _rowReset.RestoreAsync(connection, _afterSequenceRestore);
            if (_afterRowCommit is not null) await _afterRowCommit(connection);
            validation = _clock.GetTimestamp();
            try { _snapshot!.Verify(await TtBaselineSnapshot.CaptureAsync(connection)); }
            finally { observeValidation(_clock.GetElapsedTime(validation)); }
        }
        var workloadValidation = _clock.GetTimestamp();
        try { await VerifyWorkloadAsync(slot); }
        finally { observeValidation(_clock.GetElapsedTime(workloadValidation)); }
        return true;
    }

    private Task DeleteSlotAsync(Slot slot) => MeasureLifecycleAsync("Delete", () => DeleteSlotCoreAsync(slot));

    private async Task DeleteSlotCoreAsync(Slot slot)
    {
        await slot.Source.DisposeAsync();
        await using var administrative = await OpenAdministratorAsync();
        var connection = administrative.Connection;
        await using (var templateFlag = new NpgsqlCommand("SELECT datistemplate FROM pg_database WHERE datname = $1", connection))
        {
            templateFlag.Parameters.Add(new NpgsqlParameter { Value = slot.Name });
            if (await templateFlag.ExecuteScalarAsync() is true)
                await connection.ExecuteNonQueryAsync($"ALTER DATABASE {Quote(slot.Name)} IS_TEMPLATE false");
        }
        if (_dropDatabase is not null) await _dropDatabase(connection, slot.Name);
        else await connection.ExecuteNonQueryAsync($"DROP DATABASE IF EXISTS {Quote(slot.Name)} WITH (FORCE)");
    }

    public ValueTask DisposeAsync()
    {
        lock (_lifecycleGate)
        {
            _disposal ??= DisposeCoreAsync();
            return new ValueTask(_disposal);
        }
    }

    public Task RetryCleanupAsync()
    {
        lock (_lifecycleGate)
        {
            if (_disposal is null || _disposal.IsFaulted)
                _disposal = DisposeCoreAsync();
            return _disposal;
        }
    }

    private Task DisposeCoreAsync() => MeasureLifecycleAsync("Teardown", DrainCoreAsync);

    private async Task MeasureLifecycleAsync(string operation, Func<Task> action)
    {
        var started = _clock.GetTimestamp();
        var succeeded = false;
        try
        {
            await action();
            succeeded = true;
        }
        finally
        {
            var elapsed = _clock.GetElapsedTime(started);
            try
            {
                _logger.LogDebug(new EventId(401, "PreparedLifecycle"),
                    "Prepared lifecycle {OwnerId} {Operation}: duration {DurationMilliseconds} ms, success {Succeeded}",
                    Snapshot.OwnerId, operation, elapsed.TotalMilliseconds, succeeded);
            }
            catch (Exception) { /* Diagnostic consumers cannot replace the lifecycle result. */ }
        }
    }

    private async Task DrainCoreAsync()
    {
        StopAcceptingWork();
        await _gate.WaitAsync();
        try
        {
            // Factory drain has joined all lease handoffs. Seal the return ledger,
            // then cancel slot work so resets queued behind maintenance can settle.
            var returns = _returns.DrainAsync();
            Exception? first = null;
            try { await _slots.RetryCleanupAsync(); }
            catch (Exception error) { first ??= error; }
            await returns;
            // Slot drain cancels admitted lifecycle work before the monitor joins it.
            if (_monitor is not null) await _monitor.JoinAsync();
            if (first is null)
            {
                try { await _host.DisposeAsync(); }
                catch (Exception error) { first = error; }
            }
            if (first is null)
                _rowReset = null;
            var failures = _monitor?.TakeFailures().ToList() ?? [];
            failures.AddRange(_returns.TakeFailures());
            if (first is not null) failures.Insert(0, first);
            if (failures.Count > 0)
                throw new TtLifecycleException("PreparedPoolDispose", failures.Count == 1 ? failures[0] : new AggregateException(failures));
        }
        finally { _gate.Release(); }
    }

    private static string Quote(string identifier) => new NpgsqlCommandBuilder().QuoteIdentifier(identifier);
}
