# TT-039 continuing qualification — technical continuation

GitHub issue #38 owns live workflow status. Current goal remains active: qualify
an improved reference using a frozen protocol and fresh whole-run validation,
without policy search. Do not mark complete for another failed gate.

R2 is fully delivered and remains FAILED predictively:
- Published master feda6b60f54293da31e24877903e062cb3613c5e.
- Independent GPT-6 Astra engineering PASS, exact-head CI 41573896343 success,
  release skipped; issue handoff appended and exact readback verified.
- R2 source freeze d191740; forecast freeze 24adde2. Native 40 cases / 10240 tests
  passed. Three stratum failures retained: awaited/0 suite +10.21%, bg/25 suite
  +11.38%, bg/0 clean-starvation difference 0.1015625 >0.10. All 16 per-run suite
  checks pass. All 727 archive hashes and exact full fit/evaluation replay pass.
- docs/issues/evidence/2026-11-03/tt039-r2/ has complete report/archive/metadata.
- Post-hoc own-service replay <=0.73% suite, <=1.18 pp starvation; all gated
  metrics reconstruct within original allowances. This uses observed services,
  NOT predictive qualification. R2 source and data must remain unchanged.

R3 in progress (no result yet):
- Current master HEAD 0f3efc1ffca22eeea380c3a2292055181d201920, clean, two local
  commits ahead of published feda6b6. Source freeze
  1166be98f61f0ce5338c947ae56bb5b20fbb5843; forecast freeze 0f3efc1.
- New files trajectory.py / protocol-r3.md / test_trajectory.py /
  test_trajectory_collector.py / trajectory_contract.py in benchmarks/scheduler-simulator;
  collect_r3.py / contract-r3.json / collection-r3-binding.json in experiments/tt039.
- Unchanged model.py, revised.py, reference.py, protocol-r2.md retain exact R2
  replay. R3 selects one complete historical service path per seed, retaining
  worker order and initial offsets; no blocks/circular starts. 64 matched seed
  selections have only five independent source paths per stratum. Deterministic
  path results are locally cached per predict call; independent-worker-records
  sensitivity remains stochastic and explicitly outside baseline.
- All 40 observed R2 runs are R3 training; original historical roles remain
  unchanged under artifacts/tt039-r3/training/ and explicit projection manifest.
  Only fresh rounds 5/6 assess R3: 16 cases, same eight strata, 256 tests,
  32 warmups, slots8/workers4/reset4, unchanged limits and no policy search.
- Actual training fit 0.6149 s; forecast + six sensitivities 3.4892 s. Files at
  artifacts/tt039-r3/{fit.json,forecast.json,collection-freeze.json,forecast-freeze.json}.
- Both native routing smokes passed/settled; pre-freeze independent audit by
  /root/pre_collection_audit found no material defects. All 26 fast and six slow
  checks passed before actual fitting. Source-role, complete-path timing, future
  data exclusion, edited fit/forecast rejection, missing hash/file/source guards,
  real archive extraction and real Git record boundaries have owning tests.
- Native runtime is a read-only symlink to exact pinned artifacts/tt039-r2/runtime,
  with hash checks before/after each case. This is NOT CoW mutation isolation.
  Image and native sources unchanged; all freeze hashes verified before launch.

LIVE producer: exec session 28981. It runs scripts.verify.run_phase('validation',
['python3','experiments/tt039/collect_r3.py','validate'], artifacts/tt039-r3,
3600, DOCKER_HOST=unix:///var/run/docker.sock). Observe SAME handle; do not restart
on observation timeout. Terminal receipt will be artifacts/tt039-r3/validation.json;
full per-case progress is validation.log. Service is serial, per-case reader and
resource checks. Confirm terminal numeric exit + stopped before evaluation.

Next actions:
1. Poll session 28981 and/or actual producer state; preserve pending work.
2. After all16 terminal/success, run trajectory.py validate with saved fit/forecast
   to fresh evaluation.json through run_phase('evaluation-process',...). Exit2
   plus written gate false is a completed negative result; input errors are not.
3. Do NOT alter source, sampler, split or limits based on new validation. Retain
   all results. If FAIL, keep qualification goal active and diagnose openly.
4. Export R3 evidence/archive with model inputs including training/* and 16 new
   reports/receipts. Add full native archive replay to trajectory_contract.py;
   update lane counts/docs. R2 artifact replay must still pass.
5. Verify coverage, resources and immutable freezes. CoW remains unsupported
   (fresh R2 probe retained), no mutation score/full-copy fallback. Mutation waits
   for final whole-session snapshot; it does not block ordinary delivery.
6. Fetch/integrate, final local candidate, independent GPT-6 Astra review exact
   head/tree/base; normal publication only after PASS and finite envelope. Watch
   exact-head CI, update issue narrowly with fresh read and exact readback.
7. Goal completion requires actual predictive qualification and remaining delivery
   requirements; do not claim goal achieved merely for delivering a negative.

Agent context: completion_review_r2 independently PASSed Feda; pre_collection_audit
has R3 design/audit context. All agents are read-only, no source ownership conflicts.
Current writable root /home/dan/code/TurboTest; Git metadata/network need approved
escalation as before. Source/forecast freeze commits remain LOCAL until final review.
