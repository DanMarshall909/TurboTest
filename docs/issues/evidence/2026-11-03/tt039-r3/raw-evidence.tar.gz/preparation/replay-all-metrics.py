"""Development diagnostic with observed R2 services; never prospective qualification."""
from pathlib import Path
import hashlib,json,statistics,sys
sys.path.insert(0,'benchmarks/scheduler-simulator')
from revised import read_trace,assess
from reference import latency_metrics
from model import Work,simulate
source=Path('artifacts/tt039-r2');out=Path('artifacts/tt039-r3/preparation')
contract=json.loads((source/'contract.json').read_text());settings={k:contract[k] for k in ['slots','workers','resetConcurrency','cycles']}
rows=[]
for case in contract['cases']:
 report=json.loads((source/case['name']/'report.json').read_text());trace=read_trace(report,settings);jobs=[]
 for ordinal in range(settings['cycles']):
  w=ordinal%settings['workers'];record=trace['workers'][w][ordinal//settings['workers']].copy()
  if ordinal<settings['workers']:record['dispatch_us']=trace['initial_us'][w]
  jobs.append(Work(**record))
 replay=simulate(jobs,mode=case['mode'],slots=settings['slots'],workers=settings['workers'],reset_workers=settings['resetConcurrency'])
 tests,resets=replay['tests'],replay['resets']
 predicted=latency_metrics(replay['suite_us']/1000,[(r['acquired']-r['requested'])/1000 for r in tests],
  [(r['started']-r['queued'])/1000 for r in resets],replay['drain_us']/1000)
 predicted.update(clean_starvation=statistics.mean(r['queued_clean'] for r in tests),clean_queue_mean_ms=statistics.mean(r['queue_us'] for r in tests)/1000)
 rows.append(case|dict(observed=trace['observed'],predicted=predicted))
result=dict(classification='All 40 R2 runs are observed development data here. Their own services are supplied. NOT a prospective forecast or qualification.',
 sourceSha256={p:hashlib.sha256(Path('benchmarks/scheduler-simulator',p).read_bytes()).hexdigest() for p in ['model.py','revised.py']},
 rows=rows,conditionalReconstructionGate=assess(rows))
(out/'replay-all-metrics.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('Observed-service conditional reconstruction checks pass:',result['conditionalReconstructionGate']['qualified'])
print('Failed metrics:',[(s['mode'],s['waitMilliseconds'],k,v['signedError']) for s in result['conditionalReconstructionGate']['strata'] for k,v in s['metrics'].items() if not v['passed']])
