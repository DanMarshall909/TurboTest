"""One-off retention of the unchanged failed R3 experiment."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile

repo=Path.cwd();root=repo/'artifacts/tt039-r3'
out=repo/'docs/issues/evidence/2026-11-03/tt039-r3'
sys.path.insert(0,str(repo/'experiments/tt039'))
import collect_r3
collect_r3.check_freeze(root)
read=lambda p:json.loads(p.read_text())
write=lambda p,v:p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
evaluation=read(root/'evaluation.json');assert evaluation['gate']['qualified'] is False
cases=[r for r in read(root/'contract.json')['cases'] if r['split']=='validation']
native=[root/r['name'] for r in cases]
smokes=[root/'qualified-smoke-awaited',root/'qualified-smoke-background']
stopped=all(read(p/'process.json')['exitCode']==0 and read(p/'process.json')['processGroupStopped']
            and not read(p/'process.json')['deadlineExceeded'] for p in native+smokes)
settled=all(read(p/'before.json')==read(p/'after.json') and read(p/'settlement.json')['unchanged'] for p in native+smokes)
prefixes=sorted({read(p/'progress.json')['Prefix'] for p in native+smokes})
containers=subprocess.check_output(['docker','--host','unix:///var/run/docker.sock','ps','--all','--no-trunc','--format','{{.ID}} {{.Names}}'],text=True).splitlines()
remaining=[row for row in containers if any(prefix in row for prefix in prefixes)]
cleanup=dict(frozenInputsStillMatch=True,measuredCases=len(native),smokeCases=len(smokes),
             measuredProcessesStopped=stopped,perCaseInventoriesUnchanged=settled,
             ownedPrefixes=len(prefixes),remainingOwnedContainers=remaining,
             retainedRuntimeAndSharedCaches=True)
assert stopped and settled and not remaining,cleanup
write(root/'cleanup.json',cleanup)
budget=json.loads((repo/'.ai-rules.json').read_text())['resources']['disk']['workloads']['verification']
needed=(budget['reserveMiB']+budget['outputGrowthMiB']+budget['tempGrowthMiB'])*1024**2
free=shutil.disk_usage(root).free
assert free>=needed
write(root/'retention-storage.json',dict(availableBytes=free,requiredBytes=needed,
    root=str(root),temporary=str(Path('/tmp')),sameDevice=os.stat(root).st_dev==os.stat('/tmp').st_dev,
    reusableRuntime='Pinned R2 runtime retained read-only; no mutation isolation claim',deletions=[]))
archive=out/'raw-evidence.tar.gz';assert not archive.exists()
files=[]
for p in sorted(root.rglob('*')):
    if not p.is_file() or p.is_symlink():continue
    relative=p.relative_to(root)
    if relative.parts[0]=='runtime' or '__pycache__' in relative.parts or p.suffix in {'.dll','.pdb','.so','.pyc'}:continue
    files.append((p,relative.as_posix()))
identities={name:sha(path) for path,name in files}
with archive.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for path,name in files:
                info=tar.gettarinfo(str(path),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
                with path.open('rb') as payload:tar.addfile(info,payload)
inputs=['contract.json','source-identity.json','runtime-identity.json','image.json','training-provenance.json','fit.json','forecast.json','evaluation.json']
inputs += ['training/'+n for n in read(root/'training-provenance.json')['files']]
inputs += [r['name']+'/'+n for r in cases for n in ['report.json','process.json']]
assert len(inputs)==124 and set(inputs)<=identities.keys()
manifest=dict(createdAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    sourceFreeze='1166be98f61f0ce5338c947ae56bb5b20fbb5843',forecastFreeze='0f3efc1ffca22eeea380c3a2292055181d201920',
    qualification='FAIL; no policy search',archiveSha256=sha(archive),files=identities,modelInputs=sorted(inputs),
    exclusions=['Compiled native runtime retained locally with exact R2 identity; runtime symlink excluded',
                'Python bytecode; post-export verification output retained separately'])
write(out/'evidence-manifest.json',manifest)
with tarfile.open(archive) as retained:
    assert sorted(m.name for m in retained.getmembers())==sorted(identities)
    for name,expected in identities.items():
        assert hashlib.sha256(retained.extractfile(name).read()).hexdigest()==expected,name
for name in ['evaluation.json','forecast.json','cleanup.json','retention-storage.json','final-fast.json']:
    shutil.copyfile(root/name,out/name)
shutil.copyfile(root/'final-fast.log',out/'final-fast.log.txt')
print(json.dumps(dict(files=len(files),bytes=archive.stat().st_size,modelInputs=len(inputs),cleanup=cleanup)))
