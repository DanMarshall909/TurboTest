"""Retain the frozen TT-039 R4 attempt and its TT-038 comparison."""

from datetime import datetime, timezone
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile


ROOT = Path("artifacts/tt039-r4")
OUT = Path("docs/issues/evidence/2026-11-04/tt039-r4")
ARCHIVE = OUT / "raw-evidence.tar.gz"
TT038_ARCHIVE = Path("docs/issues/evidence/2026-11-02/tt038/raw-evidence.tar.gz")
TT038_MANIFEST = Path("docs/issues/evidence/2026-11-02/tt038/raw-manifest.json")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def add_file(files, path, name):
    if name in files:
        raise ValueError("duplicate archive member " + name)
    files[name] = Path(path)


OUT.mkdir(parents=True, exist_ok=False)
files = {}
for path in sorted(ROOT.rglob("*")):
    if not path.is_file() or path.is_symlink() or "__pycache__" in path.parts:
        continue
    add_file(files, path, path.relative_to(ROOT).as_posix())

# The TT-039 runtime is a read-only symlink during measurement. Archive its
# target bytes explicitly so the evidence is not a dangling symlink record.
runtime = (ROOT / "runtime").resolve(strict=True)
for path in sorted(runtime.rglob("*")):
    if path.is_file() and not path.is_symlink():
        add_file(files, path, "runtime/" + path.relative_to(runtime).as_posix())

for mode in ("awaited", "background"):
    runtime = (ROOT / f"tt038-baseline/v4/runtime-{mode}").resolve(strict=True)
    for path in sorted(runtime.rglob("*")):
        if path.is_file() and not path.is_symlink():
            add_file(
                files,
                path,
                f"tt038-baseline/v4/runtime-{mode}/" + path.relative_to(runtime).as_posix(),
            )

identities = {name: sha(path) for name, path in files.items()}
with ARCHIVE.open("xb") as raw:
    with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as zipped:
        with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as archive:
            for name, path in files.items():
                info = archive.gettarinfo(str(path), arcname=name)
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                info.mtime = 0
                with path.open("rb") as payload:
                    archive.addfile(info, payload)

fit = json.loads((ROOT / "fit.json").read_text())
evaluation = json.loads((ROOT / "evaluation.json").read_text())
model_inputs = sorted(
    set(fit["trainingFiles"])
    | set(evaluation["validationFiles"])
    | {"fit.json", "forecast.json", "evaluation.json"}
)
baseline_inputs = sorted(
    name for name in identities if name.startswith("tt038-baseline/v4/")
)
baseline_inputs.append("tt038-baseline/summary.json")
manifest = {
    "archiveSha256": sha(ARCHIVE),
    "collectionFreeze": json.loads((ROOT / "collection-freeze.json").read_text())["sourceCommit"],
    "createdAtUtc": datetime.now(timezone.utc).isoformat(),
    "dependencies": {
        "tt038RuntimeArchive": {
            "path": TT038_ARCHIVE.as_posix(),
            "sha256": sha(TT038_ARCHIVE),
        },
        "tt038RawManifest": {
            "path": TT038_MANIFEST.as_posix(),
            "sha256": sha(TT038_MANIFEST),
        },
    },
    "exclusions": [
        "Python bytecode caches",
        "The prior published TT-038 archive remains pinned as historical provenance; this archive embeds the exact rerun runtimes",
        "post-export verification and review outputs, retained as separate published files",
    ],
    "files": identities,
    "forecastFreeze": json.loads((ROOT / "forecast-freeze.json").read_text())["checkpoint"],
    "modelInputs": model_inputs,
    "baselineInputs": sorted(set(baseline_inputs)),
    "qualification": "FAIL; frozen TT-039 initial-two and full-cohort gates both failed; no policy search",
    "baselineRuntimeFiles": sorted(
        name
        for name in identities
        if any(
            name.startswith(f"tt038-baseline/v4/runtime-{mode}/")
            for mode in ("awaited", "background")
        )
    ),
    "runtimeFiles": sorted(name for name in identities if name.startswith("runtime/")),
    "sourceCheckpoint": json.loads((ROOT / "protocol-freeze.json").read_text())["checkpoint"],
}
(OUT / "evidence-manifest.json").write_text(
    json.dumps(manifest, indent=2, sort_keys=True) + "\n"
)
for name in (
    "cleanup.json",
    "evaluation.json",
    "forecast.json",
    "retention-storage.json",
):
    shutil.copyfile(ROOT / name, OUT / name)
shutil.copyfile(ROOT / "tt038-baseline/summary.json", OUT / "tt038-summary.json")
print(
    json.dumps(
        {
            "archiveBytes": ARCHIVE.stat().st_size,
            "archiveFiles": len(files),
            "baselineInputs": len(manifest["baselineInputs"]),
            "modelInputs": len(model_inputs),
            "runtimeFiles": len(manifest["runtimeFiles"]),
        },
        sort_keys=True,
    )
)
