# IMPORTANT: owner steering supersedes the earlier R4 checkpoint below

Dan requires ALL other work first and explicit confirmation before ANY further performance measurement. He confirmed rerun scope includes TT-038 baseline comparison PLUS all TT-039 timing/perturbation controls, entirely FRESH calibration and fresh validation. NO measurement approval has been given. No actual R4 fit or fresh native performance data exists. Continue offline code/tests/review only; ask for the concrete measurement window only after all other preparation is complete. Do not mark the whole goal paused; only performance is held.

R4 prototype is now being simplified to fit 56 NEW calibration cases at r0-r6, followed by 84 new validation cases r7-r27. Old 56 observed paths are development/history only, not training. `replicated.py` and its fixture now implement fresh-only fitting; synthetic tests pass. `collect_r4.py` has a tested `require_measurement_window` guard (Dan approval reference, scope, expiry, source checkpoint, STOP_PERFORMANCE), but its bootstrap/freeze wiring is still being reconciled with fresh calibration. The obsolete generic archive-training extractor was removed. Superseded prototype sources are retained in preparation/prototype-before-full-rerun.tar.gz.

Native context session48076 is TERMINAL PASS, exit0/stopped: all181native tests pass; labelled container before/after inventories equal. First CI-failing test passes6.56s in full context. Source/runtime discrepancy vsCI remains documented. No live native process remains. Existing first-test and both SDK probes also pass. Current C# sources are unchanged. No new production fix justified.

Canonical new files now also include test_replicated_collector.py and replicated_collection_contract.py; do not rely on obsolete artifact candidate tests. Latest functional runs before subsequent freeze rewiring: 36 fast pass, R4CLI1pass, realGit freezes3pass. Need rerun after unfinished collector changes. Earlier archive-training test classes were removed because new calibration must be fresh.

TT-038 offline inventory: use artifacts/tt038/v4/runtime-awaited and runtime-background (96 files each, exact hashes verified), NOT older root-level runtime directories. Only TurboTest.EFCore.dll differs and matches TT-037 baseline/candidate pins. Original source/controller is artifacts/tt038/run.py; harness Program.cs and project under artifacts/tt038/harness. All v4-bound source hashes match. TT-039 R2 runtime24files matches. Both image pins equal sha256:81bd698b4594e751a3269e4dcd3e03a4a0ec0daf7b72e7aa1abd43cce9887542. No Docker/native/fitting commands were used for inventory.

Remaining offline work: finish fresh-source protocol and contract (140 TT039 cases), baseline rerun wrapper/new output root (40 cases), route every timing control through same owner approval window, committed static protocol freeze before any approved control, collection-ready binding before fresh calibration, fit/forecast binding before validation. Add TT038/T039 controls plan, synthetic/real-Git boundaries, current lanes/docs, source snapshots and independent pre-collection review. Source/plan commit can be local before measurement; actual native controls are held until Dan confirms. Preserve both original first-two and full-cohort gates. No policy search.

User-requested complete rerun list: TT0382smokes16/8+2fault8/4 then40cases256/32; TT0392smokes16/8+2fault8/4+2held controls; probe enabled/disabled3rounds50000calls;6trace on/off cases64/32;56freshcalibration256/32;84freshvalidation256/32. Three primary cohorts180cases46080tests5760warmups, excluding controls. Historical timing estimates may guide budget only.

GitHub issue38 owns live work; owner hold section appended/readback verified. Issue37 stays historical completion; new rerun is within issue38. Agents remain read-only. No active producers or mutation workers.

---

# Technical recovery checkpoint, 2026-11-03

GitHub issue38 owns live workflow. Active goal is unchanged: positively qualify
the revised reference under frozen fresh data before policy search. Do not mark
complete for another failed prediction gate. No blocking audit applies: this
turn implemented/tested R4 and investigated an actual native CI failure.

## Published baseline

master/origin/master bfb717969ac712992a5966602e3f7018f0c8bb86,
tree5a98d42989c83eb37052ff5ee3276e4c9845b364, basefeda6b6. Independent GPT-6
Astra engineering PASS. R3 predictiveFAIL remains unchanged: awaited100 stratum
-11.85%, r6-w100-awaited -20.72%;63/64metrics and15/16individual suites pass.
All16nativecases4096tests and2smokes passed;18prefixes absent;387archive
hashes124modelInputs verified,26fast+7slow pass. Sourcefreeze1166be9,
forecastfreeze0f3efc1. Public report/archive docs/issues/evidence/2026-11-03/tt039-r3.
R2 Feda and first2ba887 remain unchanged failed archived attempts.

## R4 source in progress — four UNTRACKED files, not frozen/published

benchmarks/scheduler-simulator/{replicated.py,test_replicated.py,
replicated_contract.py,protocol-r4.md}. Last all-fast31pass1.655s; newCLI
boundary1pass0.935s. No actual R4 fit or native validation has occurred.
No collect_r4.py, contract-r4.json or freeze bindings exist yet.

Original optional user question about warmup-conditioned scope has no answer.
Default remains every forecast fixed BEFORE ALL fresh validation. Meaningful
safe progress is available; do not pretend this optional question blocks work.

R4 proposed schedule, implemented/tested in future_cases(strata):21epochs7–27;
each contains paired25 and one rotating paired0/100/500. /25has21visits per
mode; others7.84cases21504measured tests, same32warmups/256tests and exact R2
native executable/image/capacity. For index i, extra=(0,100,500)[i%3]; /25first
when i even, second otherwise. Mode order awaited/background if(i//2+position)%2
is0, reversed otherwise. First4cases r7-w25-awaited,background,r7-w0-background,
awaited. Complete literal manifest/order still needs generation and freeze.

REQUIRED conservative extension: BOTH unchanged original gate on FIRST TWO fresh
visits per stratum AND same gate on FULL fixed cohort must PASS. Every84individual
suite still20%. More visits cannot rescue first-two failure. No prediction-based
early stop, extensions, dropped cases or replacements. Correctness/cleanup/budget
failure leaves retained incomplete attempt, never qualifies subset.

replicated.forecast enumerates every complete source path exactly once and
averages its run-level metrics. This is an empirical EXPECTATION, not equality
to observed population median or pooled p95. Gate still uses original observed
medians/limits. Descriptive5th/95th empirical bounds, seven source paths, six
sensitivities retained; independent-worker probe64draws PER source path is outside
baseline. All body/reset/queue correlations and original worker offsets/order
remain together. Uses unchanged trajectory.predict, model, revised reader/gate.

replicated.fit uses all56known R3 archived runs, preserving every old role via
sourceSplit/historicalSplit. It reuses trajectory.fit to verify old40records,
then adds known R3fresh16. It pins124R3model-input JSON files/provenance, checks
exact projection/future schedule, rejects future-file reads/edited fit/forecast.
Synthetic fixture has14history+14future, seven paths each in two0waitstrata.
validate reports ALL history/future but gates only fresh cases; initialTwo and
fullCohort separately. CLI0qualified/success,2writtenfailedgate,1inputerror;
argparse2no report, existing outputs preserved.

Genuine REDs retained in artifacts/tt039-r4/preparation: ensemble-red,
original-gate-red,training-red,forecast-boundary-red,cli-red. Valid owning line
coverage reached100% of replicated decision code before CLI was added. Final
source-bound coverage/all slow lanes still required after collector complete.

Important corrected verification error: I edited while ensemble-green-coverage
was live. Its log actuallyFAILED but python -m trace returned0. It is INVALID
passing evidence, recorded in coverage-correction.json. strict-coverage.py now
traces canonical unittest discovery+runner and explicitly exits from
TestResult.wasSuccessful; before/after hashes require source stable. Unique
label argument separates coverage output. No edits until a launched run is
confirmed terminal. Later training/forecast-boundary coverage is valid.

## Development evidence / independent design audit

artifacts/tt039-next/{estimator-development.py,json,
constant-point-feasibility.json,replication-design.py,json,protocol-r4-draft.md}.
All56observed are development, never a fresh holdout.21overlapping leave-two-round
folds: seedmedian7/21pass, exactmedian8/21, exactmean7/21, each6individualsuite
failures; no demonstrated superiority. Preflight reset correlation modest and
outlier-sensitive, body proxy weak; pre-launch host signals fail to predict slow
run. No unsupported correction added.

Background25 native queued counts rounds0–6:167,136,91,166,93,140,121 /256.
Two-round observed medians span.359375(r2,r4)–.650390625(r0,r3). Any ONE fixed
stratum point has worst error at least.1455078125>.10 across those overlapping
past pairs. This does NOT rule out context-conditioned models or prove future
cohorts fail. Independent pre_collection_audit verified native counts/actualgate.

Conditional empirical order-statistic calculation estimates96.33%joint starvation
allowance probability atN21, versus79.59%atN2, under independent exchangeability
with seven source points. NOT population power/confidence/all-gate guarantee.
NIST primary median interval source consulted:
https://www.itl.nist.gov/div898/software/dataplot/refman1/auxillar/mediancl.htm

Astra design audit correctly warned changingN alone changes finite-cohort claim.
Resolved by ADDING full-cohort requirement while retaining first-two challenge.
Astra acknowledged disposition, not completion approval. It also required honest
expectation labels, fixed complete schedule/stopping, no estimator superiority
claim. Expected native84case runtime2102s from means/2296s historicalmaxima;
budget7200s, reserve480s before each new case, outer observer longer. Newretained
output budget1GiB, existing competitive-baseline growth/reserve7GiB required.

## CURRENT PRIORITY: actual R3 native CI failure

SupplementaryCI41582315618 atbfb finishedFAIL. All simulator lanes and373.NETfast
pass,171/181nativepass10fail. Pack/releaseSKIPPED. Never manually rerun/waitfor
CI per current shared rules; actual failures still need investigation.

Retained: artifacts/tt039-r3/hosted-ci/build.log; correctness-evidence.zip verified
SHA6f453ce42760961262d9b84086d7a7b1d1a71012fdddd507d8303bede7a37ba8,
artifactID13206890887; extracted correctness/ci/{slow/results.trx,test-slow.log,
resources-after-containers.json,source-identity.json,...}. Connector fetched
artifact, signedURL only used to download; local ZIP is authoritative, URLexpired.
All CI source file hashes match current files; no C# test/production source edits.

First failed test PreparedAdaptiveTests.A_failed_growth_observation_still_settles_
queued_demand_and_deletes_its_host at05:14:27.827–05:14:50.073. Stackline250 is
FinishGrowthFixtureAsync fixture-disposal outer10s wait; defaultfactory deadline
30s. Its rescue can assert before capability is published. Growthstabilization
1day means normal no growth. Nine later tests include TtCleanupRegistry.DrainAsync
and30s waits; one container created during first test remains in CI artifact.
This strongly suggests retained-owner cascade, exact blocked phase NOT known.
Do not call it environmental merely because source is unchanged. No rollback
of Python-only R3 can fix unchanged C# semantics. Do not blanket-increase timeout.

Local fresh build succeeded0warnings/errors. CI SDK/runtime10.0.403/10.0.14;
local10.0.301/10.0.9. Isolated first test passed9s (10.22total), exact before/after
Docker inventories unchanged. Receipts at hosted-ci/local-reproduction.

One-off loopback SDKprobe at hosted-ci/stats-probe (no maintained source edits,
no Docker resources): initial server-stages probe and stronger client-observed
probe BOTH cancel cleanly. Stronger waits for SDK progress after first parsed
stats record while body remains incomplete; Count1, TaskCanceledException~1.2ms,
reader/cancellation/server terminal. SourceProgram-server-stage-only.cs.txt
preserves earlier weaker probe. No demonstrated SDKcancellationcause; no spec-
ulative production patch justified by this probe.

LIVE native-context verification EXEC SESSION48076. Same handle only. It runs
scripts.verify.run_phase('native-context', ['python3','scripts/verify.py','slow',
'--output','artifacts/tt039-r3/hosted-ci/native-context/verification'],
artifacts/tt039-r3/hosted-ci/native-context,1500,DOCKER_HOST=unix:///var/run/docker.sock).
Nested driver native deadline900. It is a full native181 test context check AFTER
isolated test +SDKprobes, not a hostedCIrerun or new model-validation collection.
Observer receipt/log: native-context/{native-context.json,log}; native progress
under native-context/verification/test-slow.log, finalverification.json. Source
must stay stable until terminal. Preflight113GBfree>7.5GBrequired, /tmp/output/
Docker actual volume same filesystem. No cleanup/cache deletions.

NEXT: poll48076 (confirmed live at launch), inspect exact numeric terminal+stopped
and native/resource result. Preserve pending work on observation timeout. If fails,
inspect FIRST actual failure/owned resources; do not broad-delete unknown owners.
If passes, record local correctness scope and unresolvedCI/toolchain discrepancy;
decide bounded follow-up without stalling fixed nonadaptive reference indefinitely.
No actual R4 fit/forecast/native cohort before collector/bindings/test review ready.

## Remaining R4 engineering

Build collect_r4.py with TDD: exact R3archive124input extraction/hash/role checks,
readonly pinnedR2runtime and image, prepare source snapshots, ownROOT4;
reuse collect_r3.verify_files/committed_binding/native_driver with own R4tracked
binding paths, enforce full input/source/runtime/qualification/forecast freezes.
Budget checks stop between cases, refuse preexisting case dirs/resume, record
complete vs incomplete; run all84despite predictive misses, no partial PASS.
Calibrate stand-ins against real R3archive + realGit records + two native routing
smokes (same binary,16tests/8warmups) once native correctness is understood.
Generate literal contract-r4 from published R3contract + future_cases; do NOT fit
actual training before protocol/model/native/source/training freeze commit.
Then fit/forecast, freeze outputs/all hashes in secondcommit before84freshcases.
After native terminal evaluate bothgates, retainnegativeifneeded unchanged.
Archive/replay every input+result; updated README/CI lanes, source-bound ordinary
coverage, cleanup, independent Astra exact candidate review, normal publish,
issuefresh+exactreadback. HostedCIoptional, no release. Mutationpending safeCoW
unsupported, no score/fullcopyfallback. Keepgoalactive untilpositivequalification
AND required delivery conditions actually achieved; never shrink to failedslice.

Agents readonly: pre_collection_audit has all dev/nativeCIanalysis; Astra
completion_review_r2 has priorcompletion and newdesigncontext. No active agents
or mutationworkers. Git metadata/network requires approved escalation; git
prefix allowed. Worktree primaryonly, remotesfeaturetips allmerged, no local
featurebranches. Four task-owned untracked files must be preserved.


# Offline preparation completed, 2026-11-03

Source-only preparation published and remote-verified at37c1532f4ca931c923200a0c64bae60c8dadb3a7, treee3c5a5836a64f013fd7e42dba71bdc39f02ebb80. Independent GPT-6 Astra PASS,48fast+11slow checks pass at exact candidate. Previous review048 failed the incomplete-phase qualification seam; repaired via bound exact phase progress + successful stopped outer collector receipts, including baseline analysis. Full source/runtime/protocol bindings verify. Local tree clean. All owned verification producers terminal/stopped; no native/performance producer launched. Actual protocol-freeze points to37c1532. No measurement-window.json, real controls/calibration/validation/fit/forecast/evaluation exists. Next required action is asking Dan for the explicit quiet window for180primarycases+controls, up to3hours. All future performance remains held until an actual reply; scope agreement/readiness PASS/publication grants no permission. Goal still active and unqualified. Keep old failures immutable. Issue38 handoff updated separately/read back after publication.


## Goal continuation: approval impasse audit 1

Previous goal turn made concrete progress: published reviewed preparation37c1532 and verified issue38 handoff. Current continuation reverified clean HEAD/origin/master/protocol checkpoint37c1532, independent PASS, absent measurement-window.json and zero native R4 cases. No actual confirmation reply arrived. All authorized offline work is complete; no live worker/job is being waited on. This turn is no progress toward qualification, not a verified process wait. First consecutive impasse turn after readiness completion; leave goal active and keep the existing measurement confirmation question pending. Do not measure or repeat the question.


## Goal continuation: approval impasse audit 2

Previous continuation was no progress, not a process wait. Current state remains clean37c1532 with no actual approval. Read-only inspection found automatic push CI41602010774/job125802738170 live: all simulator/driver steps passed, native correctness in progress, no current failure. CI is supplementary and is not a delivery/measurement dependency; do not manually trigger/rerun or wait for green. This observation does not remove the explicit owner-confirmation blocker or change the next required action. No additional required offline work is available. Second consecutive approval-impasse turn after readiness completion. Keep existing question pending and goal active until blocked audit threshold is met. No timed native work launched.
