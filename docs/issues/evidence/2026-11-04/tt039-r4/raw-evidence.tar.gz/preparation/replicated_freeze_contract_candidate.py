"""Real Git-record boundary for the next collector; move to canonical slow lane."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest

PROGRAM=Path('experiments/tt039/collect_r4.py').resolve()
spec=importlib.util.spec_from_file_location('r4_freeze_collector',PROGRAM)
collector=importlib.util.module_from_spec(spec);spec.loader.exec_module(collector)


def frozen_fixture(base,*,qualification_exit=0):
    repo=base/'repo';root=base/'out';repo.mkdir();root.mkdir()
    write=lambda path,value:path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
    sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
    def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True,stderr=subprocess.STDOUT).strip()
    def commit():
        git('add','.');git('-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','-q','-m','Freeze fixture')
        return git('rev-parse','HEAD')
    sources=['experiments/tt039/'+n for n in ('collect.py','collect_r3.py','collect_r4.py','contract-r4.json')]
    sources+=['benchmarks/scheduler-simulator/'+n for n in
              ('model.py','reference.py','revised.py','trajectory.py','replicated.py','protocol-r4.md')]
    for name in sources:
        path=repo/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('pinned '+name)
    source_ids={name:sha(repo/name) for name in sources}
    (root/'runtime').mkdir();(root/'runtime/PoolTrace.dll').write_bytes(b'pinned fixture bytes; never executed')
    for name in ('contract.json','image.json','training-provenance.json'):write(root/name,{'fixture':name})
    write(root/'source-identity.json',source_ids)
    write(root/'runtime-identity.json',{'PoolTrace.dll':sha(root/'runtime/PoolTrace.dll')})
    write(root/'qualification.json',dict(exitCode=qualification_exit,processGroupStopped=True,deadlineExceeded=False))
    (root/'history.json').write_text('historical input')
    common=['contract.json','source-identity.json','runtime-identity.json','image.json','training-provenance.json','qualification.json']
    collection=dict(sourceFiles=source_ids,files={n:sha(root/n) for n in common+['history.json']})
    collection_path=repo/'experiments/tt039/collection-r4-binding.json';write(collection_path,collection)
    git('init','-q');source_commit=commit()
    write(root/'collection-freeze.json',collection|dict(sourceCommit=source_commit))
    write(root/'fit.json',dict(trainingFiles={'history.json':sha(root/'history.json')}))
    write(root/'forecast.json',{'frozen':True})
    forecast=dict(sourceFiles=source_ids,files={n:sha(root/n) for n in common+['history.json','fit.json','forecast.json','collection-freeze.json']})
    forecast_path=repo/'benchmarks/scheduler-simulator/forecast-r4-binding.json';write(forecast_path,forecast)
    forecast_commit=commit();write(root/'forecast-freeze.json',forecast|dict(checkpoint=forecast_commit))
    return repo,root,forecast,forecast_path,write,commit


class CommittedFreezeContract(unittest.TestCase):
    def test_valid_records_reject_changed_forecast_missing_pin_and_runtime_drift(self):
        with tempfile.TemporaryDirectory() as temp:
            repo,root,frozen,path,write,commit=frozen_fixture(Path(temp))
            collector.check_freeze(root,repo=repo)
            original=(root/'forecast.json').read_bytes();(root/'forecast.json').write_text('changed')
            with self.assertRaisesRegex(ValueError,'FreezeData.*forecast.json'):collector.check_freeze(root,repo=repo)
            (root/'forecast.json').write_bytes(original)
            (root/'runtime/PoolTrace.dll').write_bytes(b'changed runtime')
            with self.assertRaisesRegex(ValueError,'NativeIdentity'):collector.check_freeze(root,repo=repo)
            (root/'runtime/PoolTrace.dll').write_bytes(b'pinned fixture bytes; never executed')
            del frozen['files']['forecast.json'];write(path,frozen)
            write(root/'forecast-freeze.json',frozen|dict(checkpoint=commit()))
            with self.assertRaisesRegex(ValueError,'FreezeInputs.*forecast.json'):collector.check_freeze(root,repo=repo)

    def test_a_failed_native_qualification_receipt_cannot_be_a_collection_freeze(self):
        with tempfile.TemporaryDirectory() as temp:
            repo,root,*_=frozen_fixture(Path(temp),qualification_exit=1)
            with self.assertRaisesRegex(ValueError,'FreezeQualification'):collector.check_freeze(root,repo=repo)
