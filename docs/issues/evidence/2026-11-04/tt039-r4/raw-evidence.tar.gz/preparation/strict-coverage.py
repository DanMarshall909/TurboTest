"""One-off line attribution around the canonical unittest loader/runner."""
from pathlib import Path
import hashlib
import json
import sys
import trace
import unittest

repo=Path.cwd();output=Path(__file__).parent
label=sys.argv[1] if len(sys.argv)>1 else 'complete'
directory=sys.argv[2] if len(sys.argv)>2 else 'benchmarks/scheduler-simulator'
pattern=sys.argv[3] if len(sys.argv)>3 else 'test_replicated.py'
paths=sorted((repo/'benchmarks/scheduler-simulator').glob('*.py'))
paths+=list((repo/'benchmarks/scheduler-simulator').glob('protocol*.md'))
paths+=list((repo/'experiments/tt039').glob('*.py'))
paths+=list((repo/directory).glob(pattern))
identity=lambda:{p.relative_to(repo).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=identity()
tracer=trace.Trace(count=True,trace=False,ignoredirs=['/usr'])
suite=tracer.runfunc(unittest.defaultTestLoader.discover,directory,pattern=pattern)
result=tracer.runfunc(unittest.TextTestRunner(verbosity=2).run,suite)
tracer.results().write_results(show_missing=True,summary=True,coverdir=str(output/(label+'-coverage')))
after=identity()
(output/(label+'-coverage-identity.json')).write_text(json.dumps(dict(source=before,sourceUnchanged=before==after,
    testsRun=result.testsRun,failures=len(result.failures),errors=len(result.errors),successful=result.wasSuccessful()),indent=2,sort_keys=True)+'\n')
if before!=after:raise RuntimeError('CoverageSource: inputs changed while tracing')
sys.exit(0 if result.wasSuccessful() else 1)
