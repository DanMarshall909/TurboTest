import importlib.util
import copy
import hashlib
import io
import json
from pathlib import Path
import tempfile
import tarfile
import unittest

PROGRAM=Path('experiments/tt039/collect_r4.py').resolve()
spec=importlib.util.spec_from_file_location('r4_collector',PROGRAM)
collector=importlib.util.module_from_spec(spec);spec.loader.exec_module(collector)


class FixedCollectionContract(unittest.TestCase):
    def test_budget_expiry_leaves_incomplete_cohort_without_launching_more_cases(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            cases=[dict(name=f'case-{n}',mode='awaited',waitMilliseconds=0) for n in range(3)]
            class Driver:
                calls=[]
                def run_case(self,*args):self.calls.append(args[0]);return {'predictiveGate':False}
            driver=Driver();times=iter([0,0,7300,7300])
            with self.assertRaisesRegex(TimeoutError,'CollectionBudget'):
                collector.collect_cases(root,cases,driver,clock=lambda:next(times))
            self.assertEqual(['case-0'],driver.calls)
            state=json.loads((root/'collection-progress.json').read_text())
            self.assertFalse(state['complete'])
            self.assertEqual(['case-0'],state['completed'])
            self.assertEqual(3,state['expected'])

    def test_fixed_cohort_finishes_despite_prediction_misses_and_rejects_existing_cases(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            cases=[dict(name=f'case-{n}',mode='background',waitMilliseconds=25) for n in range(3)]
            class Driver:
                calls=[]
                def run_case(self,*args):
                    self.calls.append(args[0]);(root/args[0]).mkdir()
                    return {'predictiveGate':False}
            driver=Driver()
            collector.collect_cases(root,cases,driver,clock=lambda:0)
            state=json.loads((root/'collection-progress.json').read_text())
            self.assertTrue(state['complete']);self.assertEqual(3,len(driver.calls))
            with self.assertRaisesRegex(FileExistsError,'CollectionExisting'):
                collector.collect_cases(root,cases,driver,clock=lambda:0)
            self.assertEqual(3,len(driver.calls))


class TrainingArchiveContract(unittest.TestCase):
    def test_a_hash_valid_parent_path_cannot_write_outside_the_training_directory(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);archive=root/'source.tar.gz';payload=b'{"escape":"blocked"}';name='../escape.json'
            with tarfile.open(archive,'w:gz') as out:
                member=tarfile.TarInfo(name);member.size=len(payload);out.addfile(member,io.BytesIO(payload))
            sha=lambda data:hashlib.sha256(data).hexdigest()
            manifest=dict(archiveSha256=sha(archive.read_bytes()),sourceFreeze='source',forecastFreeze='forecast',
                          modelInputs=[name],files={name:sha(payload)})
            with self.assertRaisesRegex(ValueError,'TrainingArchive.*relative JSON input'):
                collector.extract_training(root/'target',archive,manifest)
            self.assertFalse((root/'target/escape.json').exists())
            self.assertFalse((root/'target/training').exists())

    def test_hashes_and_original_roles_survive_extraction_and_bad_inputs_write_nothing(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);archive=root/'source.tar.gz'
            contents={'contract.json':b'{"cases":[{"name":"r5","split":"validation"}]}',
                      'r5/report.json':b'{"measured":"unchanged"}'}
            with tarfile.open(archive,'w:gz') as out:
                for name,data in contents.items():
                    member=tarfile.TarInfo(name);member.size=len(data);out.addfile(member,io.BytesIO(data))
            sha=lambda data:hashlib.sha256(data).hexdigest()
            manifest=dict(archiveSha256=sha(archive.read_bytes()),sourceFreeze='source',forecastFreeze='forecast',
                          modelInputs=list(contents),files={name:sha(data) for name,data in contents.items()})
            provenance=collector.extract_training(root/'valid',archive,manifest)
            self.assertEqual(2,len(provenance['files']))
            self.assertEqual(manifest['files'],provenance['files'])
            self.assertEqual(contents['contract.json'],(root/'valid/training/contract.json').read_bytes())
            altered=copy.deepcopy(manifest);altered['files']['r5/report.json']='wrong'
            with self.assertRaisesRegex(ValueError,'TrainingArchive.*r5/report.json'):
                collector.extract_training(root/'bad-member',archive,altered)
            self.assertFalse((root/'bad-member/training').exists())
            altered=manifest|dict(archiveSha256='wrong')
            with self.assertRaisesRegex(ValueError,'TrainingArchive.*archive'):
                collector.extract_training(root/'bad-archive',archive,altered)
            self.assertFalse((root/'bad-archive/training').exists())
